server "frontend-only-direct.snpdev.ru", :app

set :user, "frontend-only"
set :group, "frontend-only"
set :keep_releases, 2
set :repository, 'dist'
