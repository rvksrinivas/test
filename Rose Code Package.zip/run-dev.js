const path = require('path');
const webpack = require('webpack');
const express = require('express');
const devMiddleware = require('webpack-dev-middleware');
const hotMiddleware = require('webpack-hot-middleware');
const webpackConfig = require('./webpack/dev')();
const DashboardPlugin = require('webpack-dashboard/plugin');

const app = express();
const compiler = webpack(webpackConfig);
const port = 9000;

compiler.apply(new DashboardPlugin());

app.use(devMiddleware(compiler, {
  publicPath: webpackConfig.output.publicPath,
  historyApiFallback: true,
}));

app.use(hotMiddleware(compiler));

app.use('*', (req, res, next) => {
  const filename = path.join(compiler.outputPath, 'index.html');
  compiler.outputFileSystem.readFile(filename, (err, result) => {
    if (err) {
      return next(err);
    }
    res.set('content-type', 'text/html');
    res.send(result);
    res.end();
  });
});

app.listen(port, err => {
  if (err) {
    return console.error(err);
  }
  console.log(`Listening at http://localhost:${port}/`);
});
