const webpack = require('webpack');
const path = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const VENDOR_PATHS = /node_modules/;
const APP_PATH = path.join(__dirname, '../app');
const CSS_LOADER_PARAMS = 'sourceMap&modules&importLoaders=2&localIdentName=[name]__[local]__[hash:base64:5]';

const doConfig = opts => {
  if (opts === null) {
    opts = {};
  }
  const BUILD_MODE = opts.BUILD_MODE;
  const IS_DEV = Boolean(opts.IS_DEV);
  return {
    context: APP_PATH,
    entry: {
      app: [
        'babel-polyfill',
        './scripts/app.jsx',
      ],
    },
    resolve: {
      extensions: [
        '',
        '.js',
        '.jsx',
        '.coffee',
      ],
      modulesDirectoriess: ['node_modules'],
      alias: require('./_aliases'),
    },
    resolveLoader: {
      modulesDirectories: ['node_modules'],
    },
    // output is definded in build an dev configs

    module: {
      preLoaders: [
        {
          test: /\.jsx?$/,
          loader: 'xo',
          exclude: VENDOR_PATHS,
        },
      ],
      loaders: [
        {
          test: /\.md$/,
          loader: 'markdown-with-front-matter',
        },
        {
          test: /\.jsx?$/,
          exclude: VENDOR_PATHS,
          include: APP_PATH,
          loader: 'babel',
        },
        {
          test: /\.coffee$/,
          loader: 'coffee',
        },
        {
          test: /\.jade$/,
          loader: 'jade?pretty=true',
        },
        {
          test: /\.sass$/,
          loader: ExtractTextPlugin.extract('style', `css?${CSS_LOADER_PARAMS}!postcss?pack=sass!sass`),
        },
        {
          test: /\.css$/,
          loader: ExtractTextPlugin.extract('style', 'css'),
          exclude: APP_PATH,
          include: VENDOR_PATHS,
        },
        {
          test: /\.css$/,
          loader: ExtractTextPlugin.extract('style', `css?${CSS_LOADER_PARAMS}!postcss`),
          exclude: VENDOR_PATHS,
          include: APP_PATH,
        },
        {
          test: /\.(png|jpe?g|ico)$/,
          loader: 'file?name=images/[name].[ext]',
        },
        {
          test: /images\/.*?\.(svg)$/,
          loader: 'file?name=images/[name].[ext]',
        },
        {
          test: /\.woff2?$/,
          loader: 'file?limit=10000&name=fonts/[name].[ext]',
        },
        {
          test: /\.([ot]tf|eot)$/,
          loader: 'file?name=fonts/[name].[ext]',
        },
        {
          test: /fonts\/.*?\.(svg)$/,
          loader: 'file?name=fonts/[name].[ext]',
        },
        {
        // custom file types
          test: /\.(pdf|zip|mp3)$/,
          loader: 'file?name=files/[name].[ext]',
        },
        {
          test: /\/bootstrap\/dist\/js\/bootstrap\.js/,
          loader: 'imports?jQuery=jquery',
        },
        {
          test: /\.json/,
          loader: 'json',
        },
      ],
      noParse: [
        /jquery\/dist\/jquery\.js/,
      ],
    },
    postcss: require('./_postcss'),
    plugins: [
      new (webpack.DefinePlugin)({'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV)}),
      new (webpack.ContextReplacementPlugin)(/node_modules\/moment\//, /ru/),
      new (HtmlWebpackPlugin)({
        filename: 'index.html',
        template: 'html/index.jade',
        minify: false
      }),
      new ExtractTextPlugin('styles.css', {
        allChunks: true,
        disable: IS_DEV,
      }),
    ],

    sassLoader: {
      indentedSyntax: true,
      includePaths: [path.resolve(__dirname, 'app/styles')],
    },

    xo: {esnext: true},
  };
};

module.exports = doConfig;
