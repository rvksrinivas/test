const path = require('path');

const getDefaultPlugins = webpack => [
  require('postcss-size'),
  require('postcss-svgo'),
  require('postcss-cssnext'),
];

const config = webpack => {
  const defaultPlugins = getDefaultPlugins(webpack);
  return {
    defaults: [
      require('stylelint')({configFile: '.stylelintrc'}),
    ].concat(defaultPlugins),

    sass: defaultPlugins,
  };
};
module.exports = config;
