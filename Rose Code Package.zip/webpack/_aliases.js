const path = require('path');

module.exports = {
  constants: path.join(__dirname, '../app/constants'),
  styles: path.join(__dirname, '../app/styles'),
  images: path.join(__dirname, '../app/images'),
  files: path.join(__dirname, '../app/files'),
  stubs: path.join(__dirname, '../app/stubs'),
  api: path.join(__dirname, '../app/scripts/api'),
  utils: path.join(__dirname, '../app/scripts/utils'),
  helpers: path.join(__dirname, '../app/scripts/helpers'),
  packages: path.join(__dirname, '../app/scripts/packages'),
  common: path.join(__dirname, '../app/scripts/common'),
  store: path.join(__dirname, '../app/scripts/store'),
  actions: path.join(__dirname, '../app/scripts/actions'),
  reducers: path.join(__dirname, '../app/scripts/reducers'),
  pages: path.join(__dirname, '../app/scripts/pages'),
  modals: path.join(__dirname, '../app/scripts/modals'),
  components: path.join(__dirname, '../app/scripts/components'),
  containers: path.join(__dirname, '../app/scripts/containers'),
  selectors: path.join(__dirname, '../app/scripts/selectors'),
};
