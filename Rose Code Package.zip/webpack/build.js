const makeConfig = require('./_config');
const webpack = require('webpack');
const ModernizrWebpackPlugin = require('modernizr-webpack-plugin');

module.exports = opts => {
  if (!opts) {
    opts = {};
  }
  const config = makeConfig(opts);
  return config;
};
