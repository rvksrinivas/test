/* STATUS TYPES
no-drag - no drag process, list isEmpty
uploading - show progress bar animation
in-empty-drag - drag when list is empty
in-fulf-drag - drag when list is full
*/

export const UPLOAD = 'upload';
export const NO_DRAG_EMPTY = 'no-drag-empty';
export const NO_DRAG_FULL = 'no-drag-full';
export const UPLOADING = 'uploading';
export const DRAG_IN_EMPTY = 'in-empty-drag';
export const DRAG_IN_FULL = 'in-fulf-drag';
