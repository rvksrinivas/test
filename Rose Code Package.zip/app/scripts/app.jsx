import React from 'react';
import {AppContainer} from 'react-hot-loader';
import ReactDOM from 'react-dom';
import {hashHistory} from 'react-router';
import {syncHistoryWithStore} from 'react-router-redux';
import configureStore from 'store/configureStore';
import 'helpers/routerWarningFix';
import 'styles/common.js';
import 'styles/common.css';

const store = configureStore();
const history = syncHistoryWithStore(hashHistory, store);

const renderApp = () => {
  const Root = require('containers/Root');
  ReactDOM.render(
    <AppContainer>
      <Root store={store} history={history} />
    </AppContainer>,
    document.getElementById('app')
  );
};

if (module.hot) {
  module.hot.accept('containers/Root', () => {
    renderApp();
  });
}

renderApp();
