import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './Enteties.css';
import {connect} from 'react-redux';
import {entetiets, search} from './entitiets.js';
import {indexOf, remove, forEach} from 'lodash';
import {setModal} from 'actions';

import Popup from 'components/Popup';
import Column from 'components/Column';

import entetIcon from 'images/svg/icons/entet-icon.svg';

export const header = {
  title: "Examining Entities",
  height: '120px',
  titleLeft: '9px',
  searchLeft: '11px',
  searchRight: '9px',
  paddingTop: '30px',
  marginTop: '15px',
  hasSearch: true,
  placeholder: 'LOB Name',
};

@CSSModules(styles)
class Enteties extends Component {
  constructor(props) {
    super(props);
    this.state = {
      entetiets: {...entetiets},
      currentRegion: null,
      currentCountry: null,
      currentEntetie: null,
      currentLeader: null,
      addedRegion: [],
      addedCountry: [],
      addedEntetie: [],
      addedLeader: [],
    };
    this.onClick = this.onClick.bind(this);
    this.onDeleteClick = this.onDeleteClick.bind(this);
  }

  onDeleteClick(val) {
    if (val.length === 1) {
      this.onClick(val, 'Region');
    } else if (val.length === 2) {
      this.onClick(val, 'Country');
    } else if (val.length === 3) {
      this.onClick(val, 'Entetie');
    } else if (val.length === 4) {
      this.onClick(val, 'Leader');
    }
  }

  onClick(val, type) {
    const list = this.state[`added${type}`];
    const oldVal = this.inList(val, list);
    const newList = list.slice();
    const newVal = val;
    if (oldVal) {
      this.clearInfo(val, type);
    } else {
      newList.push(val);
      this.setState({[`current${type}`]: newVal, [`added${type}`]: newList});
    }
  }

  clearInfo(val, type) {
    const {addedRegion, addedCountry, addedEntetie, addedLeader} = this.state;
    if (type === 'Region') {
      this.setState({
        currentRegion: null,
        currentCountry: null,
        currentEntetie: null,
        currentLeader: null,
        addedRegion: this.clearInList(addedRegion, val),
        addedCountry: this.clearInList(addedCountry, val),
        addedEntetie: this.clearInList(addedEntetie, val),
        addedLeader: this.clearInList(addedLeader, val),
      });
    } else if (type === 'Country') {
      this.setState({
        currentCountry: null,
        currentEntetie: null,
        currentLeader: null,
        addedCountry: this.clearInList(addedCountry, val),
        addedEntetie: this.clearInList(addedEntetie, val),
        addedLeader: this.clearInList(addedLeader, val),
      });
    } else if (type === 'Entetie') {
      this.setState({
        currentEntetie: null,
        currentLeader: null,
        addedEntetie: this.clearInList(addedEntetie, val),
        addedLeader: this.clearInList(addedLeader, val),
      });
    } else if (type === 'Leader') {
      this.setState({
        currentLeader: null,
        addedLeader: this.clearInList(addedLeader, val),
      });
    }
  }

  clearInList(list, val) {
    const newList = list.slice();
    remove(newList, item => {
      return item.substr(0, val.length) === val;
    });
    return newList;
  }

  inList(val, list) {
    const inList = indexOf(list, val);
    return (inList !== -1);
  }

  getFooterData(breadCrums) {
    const count = breadCrums.length;
    return {
      card: 'examingFilled',
      onDeleteClick: this.onDeleteClick,
      title: `Show All Examining Entities (${count})`,
      breadCrums,
      listTitle: 'SELECTED EXAMINING ENTITIES',
    };
  }

  getCountries() {
    const {currentRegion, entetiets} = this.state;
    let list = [];
    if (currentRegion) {
      const newList = entetiets.regions[currentRegion].countries;
      if (newList) {
        list = newList;
      }
    }
    return list;
  }

  getExamEnteties() {
    const {currentRegion, currentCountry, entetiets} = this.state;
    let list = [];
    if (currentRegion) {
      const contries = entetiets.regions[currentRegion].countries;
      if (contries && currentCountry) {
        const country = Number(currentCountry.charAt(1));
        const newList = entetiets.regions[currentRegion].countries[country].entetities;
        if (newList) {
          list = newList;
        }
      }
    }
    return list;
  }

  getLeaders() {
    const {currentRegion, currentCountry, currentEntetie, entetiets} = this.state;
    let list = [];
    if (currentRegion) {
      const contries = entetiets.regions[currentRegion].countries;
      if (contries && currentCountry) {
        const country = Number(currentCountry.charAt(1));
        const entetities = entetiets.regions[currentRegion].countries[country].entetities;
        if (entetities && currentEntetie) {
          const entetie = Number(currentEntetie.charAt(2));
          const newList = entetiets.regions[currentRegion].countries[country].entetities[entetie].leaders;
          if (newList) {
            list = newList;
          }
        }
      }
    }
    return list;
  }

  getList(list1, list2, list3, list4) {
    const all1 = list1.concat(list2);
    const all2 = list3.concat(list4);
    const all = all1.concat(all2);
    const newList1 = [];
    const newList2 = [];
    const newList3 = [];
    const newList4 = [];
    forEach(all, item => {
      if (item.length === 1) {
        newList1.push(item);
      } else if (item.length === 2) {
        newList2.push(item);
      } else if (item.length === 3) {
        newList3.push(item);
      } else if (item.length === 4) {
        newList4.push(item);
      }
    });
    forEach(newList2, target => {
      remove(newList1, item => {
        return item === target.substr(0, item.length);
      });
    });
    forEach(newList3, target => {
      remove(newList2, item => {
        return item === target.substr(0, item.length);
      });
    });
    forEach(newList4, target => {
      remove(newList3, item => {
        return item === target.substr(0, item.length);
      });
    });
    const newAll1 = newList1.concat(newList2);
    const newAll2 = newList3.concat(newList4);
    return newAll1.concat(newAll2);
  }

  createBreadCrumbs(list) {
    const {entetiets} = this.state;
    const array = [];
    forEach(list, item => {
      const path = item.split('');
      const newArray = [];
      let first;
      if (item.length > 0) {
        first = Number(path[0]);
        newArray.push(item);
        newArray.push(entetiets.regions[first].title);
      }
      if (item.length > 1) {
        const sec = Number(path[1]);
        newArray.push(entetiets.regions[first].countries[sec].title);
      }
      if (item.length > 2) {
        const sec = Number(path[1]);
        const third = Number(path[2]);
        newArray.push(entetiets.regions[first].countries[sec].entetities[third].title);
      }
      if (item.length > 3) {
        const sec = Number(path[1]);
        const third = Number(path[2]);
        const fourth = Number(path[3]);
        newArray.push(entetiets.regions[first].countries[sec].entetities[third].leaders[fourth].title);
      }
      array.push(newArray);
    });
    return array;
  }

  render() {
    const {entetiets, currentRegion, currentCountry, currentEntetie, addedRegion, addedCountry, addedEntetie, addedLeader} = this.state;
    const countries = this.getCountries();
    const examEnteties = this.getExamEnteties();
    const leaders = this.getLeaders();
    const wholeList = this.getList(addedRegion, addedCountry, addedEntetie, addedLeader);
    const breadCrumbs = this.createBreadCrumbs(wholeList);
    const footer = this.getFooterData(breadCrumbs);
    return (
      <div className={this.props.className} styleName="root">
        <Popup title="Add Location" header={header} footer={footer} search={search}>
          <Column title="EXAMINER REGION" items={entetiets.regions} activeId={currentRegion} activeItems={addedRegion} width="25%" onClick={val => {
            this.onClick(val, 'Region');
          }}/>
          <Column title="EXAMINER COUNTRY" scrollable="true" items={countries} activeId={currentCountry} activeItems={addedCountry} currentId={currentRegion} width="25%" onClick={val => {
            this.onClick(val, 'Country');
          }}/>
          <Column title="EXAMINING ENTITIES" scrollable="true" items={examEnteties} activeId={currentEntetie} activeItems={addedEntetie} currentId={`${currentCountry}`} type="descr" width="25%" onClick={val => {
            this.onClick(val, 'Entetie');
          }}/>
          <Column title="LEAD EXAMINERS (OPTIONAL)" scrollable="true" items={leaders} activeItems={addedLeader} currentId={`${currentEntetie}`} width="25%" type="last" onClick={val => {
            this.onClick(val, 'Leader');
          }}/>
        </Popup>
        <div styleName="new-entetie" onClick={this.props.onSetModal}>
          <img src={entetIcon} />
          <span>Request New Entity</span>
        </div>
      </div>
    );
  }
}

Enteties.propTypes = {
  className: PropTypes.string,
};

const mapDispatchToProps = dispatch => ({
  onSetModal() {
    dispatch(setModal('request'));
  },
});

export default connect(null, mapDispatchToProps)(Enteties);
