import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Request.css';

import Popup from 'components/Popup';
import Toggle from 'components/Toggle';
import Column from 'components/Column';
import Field from 'components/Field';

export const header = {
  title: "Request New Entity",
  height: '40px',
  paddingTop: '10px',
  paddingLeft: '2px',
  hasSearch: false,
};

export const requests = [
  {
    title: 'YES',
    value: 'yes',
    width: '130px',
  },
  {
    title: 'NO',
    value: 'no',
    width: '130px',
  },
];

export const isIdo = [
  {
    title: 'YES',
    value: 'yesIdo',
    width: '130px',
  },
  {
    title: 'NO',
    value: 'noIdo',
    width: '130px',
  },
];

export const isExamin = [
  {
    title: 'YES',
    value: 'yesExam',
    width: '130px',
  },
  {
    title: 'NO',
    value: 'noExam',
    width: '130px',
  },
];

const onToggleClick = () => {

};

class Request extends Component {
  render() {
    return (
      <div className={this.props.className} styleName="root">
        <Popup title="Request New Entity" header={header} footerText="Submit" >
          <div styleName="exist-wrap">
            <span>Is Examining Entity existing? </span>
            <div styleName="exist-toggle">
              <Toggle activated="true" current="no" size="big" items={requests} name="exist" type="joined" onClick={onToggleClick} />
            </div>
          </div>
          <div styleName="columns-wrap">
            <Column title="BASIC INFORMATION OF EXAMINING ENTITY" width="900px" items={[]} filled="true">
              <div styleName="column" style={{width: "300px"}}>
                <div styleName="field">
                  <span>
                    Short Name
                  </span>
                  <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                </div>
                <div styleName="field">
                  <span>
                    Region
                  </span>
                  <Field type="select" placeholder="Type here" borderColor="#D7D7D7" color="request"/>
                </div>
                <div styleName="field">
                  <span>
                    JPMC Contact
                  </span>
                  <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                </div>
                <div styleName="field">
                  <span>
                    Website
                  </span>
                  <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                </div>
                <div styleName="field">
                  <span>
                    Mailing Address
                  </span>
                  <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                </div>
                <div styleName="field">
                  <span>
                    Zip Code
                  </span>
                  <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                </div>
              </div>
              <div style={{display: "inline-block"}}>
                <div styleName="column" style={{width: "300px"}}>
                  <div styleName="field">
                    <span>
                      Full Name
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      Country
                    </span>
                    <Field type="select" placeholder="Type here" borderColor="#D7D7D7" color="request"/>
                  </div>
                  <div styleName="field">
                    <span>
                      JPMC Contact is Primary
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      Compliance ID
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      City
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>

                </div>
                <div styleName="column" style={{width: "300px"}}>
                  <div styleName="field">
                    <span>
                      Category
                    </span>
                    <Field type="select" placeholder="Type here" borderColor="#D7D7D7" color="request"/>
                  </div>
                  <div styleName="field">
                    <span style={{paddingLeft: "13px"}}>
                      Is LDO Indicator?
                    </span>
                    <div style={{marginTop: "6px", marginBottom: "35px"}}>
                      <Toggle size="big" items={isIdo} name="ido" type="joined" onClick={onToggleClick} />
                    </div>
                  </div>
                  <div styleName="field">
                    <span>
                      JPMC Contact Requiring Pre-briefing
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      Regulator Escalation Timing
                    </span>
                    <Field type="select" placeholder="Type here" borderColor="#D7D7D7" color="request"/>
                  </div>
                  <div styleName="field">
                    <span>
                      State
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                </div>
                <div style={{paddingLeft: "20px", paddingRight: "25px"}}>
                  <div styleName="field">
                    <span>
                      Comments
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                </div>
              </div>
            </Column>
            <Column title="EXAMINER CONTACT INFORMATION" width="300px" items={[]} titleLeft="10px" filled="true">
              <div styleName="column" style={{width: "300px"}}>
                <div styleName="field">
                    <span>
                      Last Name
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      First Name
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      Email Address
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      Phone
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span>
                      Phone
                    </span>
                    <Field type="text" placeholder="Type here" borderColor="#D7D7D7" />
                  </div>
                  <div styleName="field">
                    <span style={{paddingLeft: "13px"}}>
                      Is Examiner Contact Primary?
                    </span>
                    <div style={{marginTop: "6px", marginBottom: "35px"}}>
                      <Toggle size="big" items={isExamin} name="isExamin" type="joined" onClick={onToggleClick} />
                    </div>
                  </div>
              </div>
            </Column>
          </div>
        </Popup>
      </div>
    );
  }
}

Request.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Request, styles);
