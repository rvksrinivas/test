export const header = {
  title: "Add Location",
  height: '121px',
  hasSearch: true,
  placeholder: 'Location Name',
};

export const search = {
  title: 'United',
  loadLeft: '232px',
  items: [
    {
      title: 'Suggested Results',
      items: [
        {
          title: '<b>United</b> States',
          type: 'search',
        },
        {
          title: '<b>United</b> Republic of Tanzania',
          type: 'search',
        },
        {
          title: '<b>United</b> Arab Emirates',
          type: 'search',
        },
      ],
    },
    {
      title: 'Frequently Used',
      items: [
        {
          title: 'United States',
          index: '15684',
          type: 'time',
        },
        {
          title: 'United Kingdom',
          type: 'time',
          index: '15684',
        },
        {
          title: 'United States Minor Outlying Islands',
          type: 'time',
          index: '15684',
        },
      ],
    },
  ],
};

export const regions = [
  {
    title: 'North America',
    countries: [
      {
        title: 'Canada',
      },
      {
        title: 'United States',
      },
      {
        title: 'Country 3',
      },
      {
        title: 'Country 4',
      },
      {
        title: 'Country 5',
      },
      {
        title: 'Country 6',
      },
      {
        title: 'Country 7',
      },
      {
        title: 'Country 8',
      },
      {
        title: 'Country 9',
      },
    ],
  },
  {
    title: `Europe, Middle East and&nbsp;Africa`,
    countries: [
      {
        title: 'United Kingdom',
      },
      {
        title: 'Country 2',
      },
      {
        title: 'Country 3',
      },
      {
        title: 'Country 4',
      },
      {
        title: 'Country 5',
      },
      {
        title: 'Country 6',
      },
      {
        title: 'Country 7',
      },
      {
        title: 'Country 8',
      },
      {
        title: 'Country 9',
      },
    ],
  },
  {
    title: 'Latin America and the&nbsp;Caribbean',
    countries: [
      {
        title: 'Country 1',
      },
      {
        title: 'Country 2',
      },
      {
        title: 'Country 3',
      },
      {
        title: 'Country 4',
      },
      {
        title: 'Country 5',
      },
      {
        title: 'Country 6',
      },
      {
        title: 'Country 7',
      },
      {
        title: 'Country 8',
      },
      {
        title: 'Country 9',
      },
    ],
  },
  {
    title: 'Asia Pacific',
    countries: [
      {
        title: 'Country 1',
      },
      {
        title: 'Country 2',
      },
      {
        title: 'Country 3',
      },
      {
        title: 'Country 4',
      },
      {
        title: 'Country 5',
      },
      {
        title: 'Country 6',
      },
      {
        title: 'Country 7',
      },
      {
        title: 'Country 8',
      },
      {
        title: 'Country 9',
      },
    ],
  },
];
