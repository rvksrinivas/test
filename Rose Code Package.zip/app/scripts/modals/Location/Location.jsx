import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Location.css';
import {header, regions, search} from './location.js';
import {indexOf, remove, forEach} from 'lodash';

import Popup from 'components/Popup';
import Column from 'components/Column';

class Location extends Component {
  constructor(props) {
    super(props);
    this.state = {
      regions: [...regions],
      currentRegion: null,
      currentCountry: null,
      addedRegion: [],
      addedCountry: [],
    };
    this.onClick = this.onClick.bind(this);
    this.onDeleteClick = this.onDeleteClick.bind(this);
  }

  onClick(val, type) {
    const list = this.state[`added${type}`];
    const oldVal = this.inList(val, list);
    const newList = list.slice();
    const newVal = val;
    if (oldVal) {
      this.clearInfo(val, type);
    } else {
      newList.push(val);
      this.setState({[`current${type}`]: newVal, [`added${type}`]: newList});
    }
  }

  onDeleteClick(val) {
    if (val.length > 1) {
      this.onClick(val, 'Country');
    } else {
      this.onClick(val, 'Region');
    }
  }

  getFooterData(breadCrums) {
    const count = breadCrums.length;
    return {
      card: 'primafyInfoFilled',
      onDeleteClick: this.onDeleteClick,
      title: `Show All Locations selected (${count})`,
      listTitle: 'SELECTED LOCATION(S)',
      breadCrums,
    };
  }

  clearInfo(val, type) {
    const {addedRegion, addedCountry} = this.state;
    if (type === 'Region') {
      this.setState({
        currentRegion: null,
        currentCountry: null,
        addedRegion: this.clearInList(addedRegion, val),
        addedCountry: this.clearInList(addedCountry, val),
      });
    } else if (type === 'Country') {
      this.setState({
        currentCountry: null,
        addedCountry: this.clearInList(addedCountry, val),
      });
    }
  }

  clearInList(list, val) {
    const newList = list.slice();
    remove(newList, item => {
      return item.substr(0, val.length) === val;
    });
    return newList;
  }

  inList(val, list) {
    const inList = indexOf(list, val);
    return (inList !== -1);
  }

  getCountries() {
    const {currentRegion, regions} = this.state;
    let list = [];
    if (currentRegion) {
      const newList = regions[currentRegion].countries;
      if (newList) {
        list = newList;
      }
    }
    return list;
  }

  getList(list1, list2) {
    const all = list1.concat(list2);
    const newList1 = [];
    const newList2 = [];
    forEach(all, item => {
      if (item.length === 1) {
        newList1.push(item);
      } else {
        newList2.push(item);
      }
    });
    forEach(newList2, target => {
      remove(newList1, item => {
        return item === target.substr(0, item.length);
      });
    });
    return newList1.concat(newList2);
  }

  createBreadCrumbs(list) {
    const {regions} = this.state;
    const array = [];
    forEach(list, item => {
      const path = item.split('');
      const newArray = [];
      let first;
      if (item.length > 0) {
        first = Number(path[0]);
        newArray.push(item);
        newArray.push(regions[first].title);
      }
      if (item.length > 1) {
        const sec = Number(path[1]);
        newArray.push(regions[first].countries[sec].title);
      }
      array.push(newArray);
    });
    return array;
  }

  render() {
    const {regions, currentRegion, currentCountry, addedRegion, addedCountry} = this.state;
    const countries = this.getCountries();
    const wholeList = this.getList(addedRegion, addedCountry);
    const breadCrumbs = this.createBreadCrumbs(wholeList);
    const footer = this.getFooterData(breadCrumbs);
    return (
      <div className={this.props.className} styleName="root">
        <Popup title="Add Location" header={header} footer={footer} search={search} >
          <Column title="region" items={regions} innerCounter={addedCountry} activeItems={addedRegion} activeId={currentRegion} width="50%" onClick={val => {
            this.onClick(val, 'Region');
          }}/>
          <Column title="country" items={countries} currentId={currentRegion} activeItems={addedCountry} type="last" width="50%" onClick={val => {
            this.onClick(val, 'Country');
          }}/>
        </Popup>
      </div>
    );
  }
}

Location.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Location, styles);
