import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Legal.css';
import {legals, search} from './legals.js';
import {indexOf, remove, forEach} from 'lodash';

import Popup from 'components/Popup';
import Toggle from 'components/Toggle';
import Checkbox from 'components/Checkbox';

export const header = {
  title: "Add Legal Entities",
  height: '121px',
  paddingTop: '31px',
  hasSearch: true,
  placeholder: 'Legal Entity',
};

export const requests = [
  {
    title: 'LOB Material Legal Entities',
    value: '0',
    width: '290px',
  },
  {
    title: 'All Prioritized Legal Entities',
    value: '1',
    width: '290px',
  },
];

class Legal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      legals: {...legals},
      type: '0',
      addedLegals: [],
      currentLegal: null,
    };
    this.onToggleClick = this.onToggleClick.bind(this);
    this.onDeleteClick = this.onDeleteClick.bind(this);
    this.onCheckboxClick = this.onCheckboxClick.bind(this);
  }

  onDeleteClick(val) {
    this.onCheckboxClick(val);
  }

  onToggleClick(type) {
    this.setState({type});
  }

  onCheckboxClick(val) {
    const list = this.state.addedLegals;
    const oldVal = this.inList(val, list);
    const newList = list.slice();
    const newVal = val;
    if (oldVal) {
      this.clearInfo(val);
    } else {
      newList.push(val);
      this.setState({currentLegal: newVal, addedLegals: newList});
    }
  }

  clearInfo(val) {
    const {addedLegals} = this.state;
    this.setState({
      currentLegal: null,
      addedLegals: this.clearInList(addedLegals, val),
    });
  }

  inList(val, list) {
    const inList = indexOf(list, val);
    return (inList !== -1);
  }

  clearInList(list, val) {
    const newList = list.slice();
    remove(newList, item => {
      return item.substr(0, val.length) === val;
    });
    return newList;
  }

  getFooterData(breadCrums) {
    const count = breadCrums.length;
    return {
      card: 'legalFilled',
      onDeleteClick: this.onDeleteClick,
      title: `No Prioritized Legal Entities`,
      breadCrums,
      titleStyle: 'no-priorize',
      width: '200px',
      crumsType: 'line',
      listTitle: 'SELECTED LEGAL ENTITIES',
    };
  }

  getList() {
    const {type, legals, addedLegals} = this.state;
    const items = legals[type];
    const list = items.map((item, i) => {
      let isCheked = false;
      if (addedLegals) {
        forEach(addedLegals, item => {
          if (item === `${type}${i}`) {
            isCheked = true;
          }
        });
      }
      return <Checkbox key={`${type}${i}`} onClick={this.onCheckboxClick} text={item.title}
              value={`${type}${i}`} type="square" id={`${type}${i}`} checked={isCheked}
              category="popup" size="full"/>;
    });
    return list;
  }

  createBreadCrumbs() {
    const {legals, addedLegals} = this.state;
    const array = [];
    forEach(addedLegals, item => {
      const path = item.split('');
      const newArray = [];
      let first;
      if (item.length > 0) {
        first = Number(path[0]);
        newArray.push(item);
        newArray.push(first === 0 ? 'LOB Material Legal Entities' : 'All Prioritized Legal Entities');
      }
      if (item.length > 1) {
        const sec = Number(path[1]);
        newArray.push(legals[first][sec].title);
      }
      array.push(newArray);
    });
    return array;
  }

  render() {
    const {type} = this.state;
    const list = this.getList();
    const breadCrumbs = this.createBreadCrumbs();
    const footer = this.getFooterData(breadCrumbs);
    return (
      <div className={this.props.className} styleName="root">
        <Popup title="Add LOBs" header={header} footer={footer} search={search}>
          <div styleName="toggle-wrap">
            <Toggle activated="true" onClick={this.onToggleClick} current={type} items={requests} name="legal" size="medium" type="joined" category="modal" />
          </div>
          <div styleName="respond">
            {
              list
            }
          </div>
        </Popup>
      </div>
    );
  }
}

Legal.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Legal, styles);
