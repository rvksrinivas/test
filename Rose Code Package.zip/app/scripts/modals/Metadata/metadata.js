export const ranges = [
  {
    title: 'ID',
    width: '101px',
    paddingLeft: '30px',
  },
  {
    title: 'Doc. Name',
    width: '151px',
    paddingLeft: '9px',
  },
  {
    title: 'Uploaded by',
    width: '131px',
    paddingLeft: '20px',
  },
  {
    title: 'Timestamp of Attachment',
    width: '191px',
    paddingLeft: '15px',
  },
  {
    title: 'Last Modified by',
    width: '141px',
    paddingLeft: '15px',
  },
  {
    title: 'Last Modified Date',
    width: '184px',
    paddingLeft: '14px',
  },
];
