import {SET_EXAM_NAME, SET_CARD_STATE, CLEAR_FILLED_DATA} from 'actions';

const initialState = {
  examName: '',
  basicInfoFilled: false,
  primafyInfoFilled: false,
  lobsInfoFilled: false,
  legalFilled: false,
  examingFilled: false,
  teamFilled: false,
  themeFilled: false,
  metadaFilled: false,
  legalNoPriorize: false,
};

const filledData = (state = initialState, action) => {
  const {type, payload} = action;

  switch (type) {
    case SET_EXAM_NAME:
      return {
        ...state,
        examName: payload,
      };
    case SET_CARD_STATE:
      return {
        ...state,
        [payload.card]: payload.state,
      };
    case CLEAR_FILLED_DATA:
      return initialState;

    default:
      return state;
  }
};

export default filledData;
