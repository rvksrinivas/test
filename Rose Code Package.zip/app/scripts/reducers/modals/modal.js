import {SET_MODAL, TOGGLE_MODAL} from 'actions';

const initialState = {
  opened: false,
  name: '',
};

const modal = (state = initialState, action) => {
  const {type, payload} = action;

  switch (type) {
    case SET_MODAL:
      return {
        ...state,
        name: payload,
      };

    case TOGGLE_MODAL:
      return {
        ...state,
        opened: !state.opened,
      };

    default:
      return state;
  }
};

export default modal;
