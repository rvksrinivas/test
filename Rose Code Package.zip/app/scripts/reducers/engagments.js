import {
  SET_ENGAGMENTS_TYPE,
  SET_ENGAGMENTS_CATEGORY,
  UPDATE_ENGAGMENTS_PHASE,
  DELETE_ENGAGMENTS_PHASE,
  ADD_EXAM,
} from 'actions';

import {exams} from 'stubs/exams.js';
import {remove, filter, findIndex} from 'lodash';

const initialState = {
  type: 'all',
  category: 'all',
  phases: ["Preparatory", "Active", "FieldWork", "Pending Planning", "Response Pending", "Post Closeout", "Suspended"],
  exams,
};

const newExam = {
  type: 'Exam',
  id: '0123456789',
  name: 'Exam NameTest #2 OCC ROSE',
  stage: 'Pend. Planning',
  state: 'Pending Planning',
  manager: 'Ane Aranburu',
  update: 'Today',
  category: 'my',
};

const updatePhase = (phases, phase) => {
  let newPhases = phases.slice();
  const index = findIndex(phases, item => {
    return phase === item;
  });
  if (index === -1) {
    newPhases.push(phase);
  } else {
    newPhases = remove(newPhases, item => {
      return phase !== item;
    });
  }
  return newPhases;
};

const addExam = exams => {
  const newList = exams.slice();
  newList.unshift(newExam);
  return newList;
};

const engagments = (state = initialState, action) => {
  const {type, payload} = action;

  switch (type) {
    case SET_ENGAGMENTS_TYPE:
      return {
        ...state,
        type: payload,

      };

    case SET_ENGAGMENTS_CATEGORY:
      return {
        ...state,
        category: payload,
      };

    case UPDATE_ENGAGMENTS_PHASE:
      return {
        ...state,
        phases: updatePhase(state.phases, payload),
      };

    case ADD_EXAM:
      return {
        ...state,
        exams: addExam(state.exams),
      };

    default:
      return state;
  }
};

export default engagments;

export const getType = state => state.type;
