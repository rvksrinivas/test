import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Column.css';
import {forEach} from 'lodash';
import classnames from 'classnames';

import ReactScrollbar from 'react-scrollbar-js';

import ColumnItem from 'components/ColumnItem';

const sumCounter = (innerCounter, id, i) => {
  let count = 0;
  forEach(innerCounter, item => {
    const itemName = String(item);
    if (id === itemName.substr(0, id.length)) {
      count++;
    }
  });
  return count;
};

const Column = props => {
  const {title, width, items, id, innerCounter, activeItems} = props;
  let list = '';
  if (items) {
    list = items.map((item, i) => {
      const newTitle = title.replace(" ", '');
      const newId = props.currentId ? props.currentId : '';
      const activeId = props.activeId;
      const isActive = String(activeId === `${newId}${i}`);
      const counter = sumCounter(innerCounter, `${newId}${i}`, i);
      const fullDescr = props.complex ? item.description : '';
      let isCheked = false;
      if (activeItems) {
        forEach(activeItems, item => {
          if (item === `${newId}${i}`) {
            isCheked = true;
          }
        });
      }
      return <ColumnItem type={props.type} counter={counter} onClick={props.onClick}
              key={`${newTitle}${newId}-${i}`} isActive={isActive}
              innerId={i} value={`${newId}${i}`} id={`${newTitle}${newId}-${i}`}
              title={item.title} end={item.end} complex={props.complex} descr={item.descr}
              fullDescr={fullDescr} checked={isCheked} />;
    });
  }
  const isEmpty = items.length > 0 || props.filled ? '' : 'empty';
  const classes = classnames(props.className, styles[`status-${isEmpty}`]);
  const myScrollbar = {
    height: 459,
  };
  const isScrollable = props.scrollable;
  return (
    <div className={classes} styleName="root" style={{width}}>
      <div styleName="title" style={{paddingLeft: props.titleLeft}}>
        {props.title}
        {
          props.subtitle &&
          <span styleName="subtitle">{props.subtitle}</span>
        }
      </div>
      {
        (isScrollable && !isEmpty) ? (
        <ReactScrollbar style={myScrollbar}>
          <div styleName="content">
            {
              list
            }
            {
              props.children
            }
          </div>
        </ReactScrollbar>
        ) : (
          <div styleName="content">
            {
              list
            }
            {
              props.children
            }
          </div>
        )
      }
    </div>
  );
};

Column.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Column, styles);
