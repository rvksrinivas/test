import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Content.css';

const Content = props => {
  const {item, children} = props;
  return (
    <div className={props.className} styleName="root" style={{height: `calc(100% - ${props.padding} - 50px)`}}>
      {children}
    </div>
  );
};

Content.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Content, styles);
