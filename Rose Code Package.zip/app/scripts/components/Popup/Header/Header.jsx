import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Header.css';

import SearchField from 'components/SearchField';

const Header = props => {
  const {item} = props;
  const placeholder = item.isSearch ? 'Search by' : 'Type here';
  return (
    <header className={props.className} styleName="root" style={{height: item.height, paddingTop: item.paddingTop, paddingLeft: item.paddingLeft, paddingRight: item.paddingRight}}>
      <div styleName="title" style={{paddingLeft: item.titleLeft, left: item.titlePosLeft}}>{item.title}</div>
      {
        item.hasSearch &&
          <div styleName="search" style={{paddingLeft: item.searchLeft, width: item.searchWidth, paddingRight: item.searchRight, marginTop: item.marginTop}}>
            <SearchField action={placeholder} placeholder={item.placeholder} search={props.search} onSearchClick={props.onSearchClick} />
          </div>
      }
    </header>
  );
};

Header.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Header, styles);
