import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Popup.css';

import Header from './Header';
import Content from './Content';
import Footer from './Footer';

const Popup = props => {
  return (
    <div className={props.className} styleName="root">
      <Header item={props.header} search={props.search} onSearchClick={props.onSearchClick} />
      <Content padding={props.header.height}>{props.children}</Content>
      <Footer item={props.footer} text={props.footerText}/>
    </div>
  );
};

Popup.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Popup, styles);
