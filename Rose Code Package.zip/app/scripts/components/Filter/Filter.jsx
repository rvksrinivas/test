import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Filter.css';
import modsClasses from 'utils/modsClasses.js';

import FilterItem from 'components/FilterItem';

const MODS = ['category'];

const Filter = props => {
  const items = props.items;
  const classes = modsClasses(MODS, props, styles);
  return (
    <div className={classes} styleName="root" style={{paddingBottom: props.paddingBottom}}>
      <div styleName="title">{props.title}</div>
      {
        props.type === "text" ? (
          <div styleName="items-type-text"><label>{items[0].text}</label><input type="text" placeholder="MM/DD/YYYY" /></div>
        ) : (
          <div styleName="items">
          {items.map((item, i) => {
            return <FilterItem onClick={props.onClick} onSubtitleClick={props.onSubtitleClick} text={item.text} subtitles={item.subtitles} value={item.value} key={item.text} type={props.type} name={props.name} id={i} category={props.category ? props.category : ''}/>;
          }
          )}
          </div>
        )
      }
    </div>
  );
};

Filter.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Filter, styles);
