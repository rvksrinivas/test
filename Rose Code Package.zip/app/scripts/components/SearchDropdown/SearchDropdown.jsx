import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './SearchDropdown.css';

import Button from 'components/Button';

import loupe from 'images/svg/icons/loupe-gray.svg';
import star from 'images/svg/icons/search-star.svg';
import deleteImg from 'images/svg/icons/search-delete.svg';
import recentImg from 'images/svg/icons/recent-icon.svg';

const SearchDropdown = props => {
  const {item} = props;
  const list = item.items.map((item, i) => {
    return (
      <div key={`items${i}`} styleName="item">
        <div styleName="title">
          {item.title}
          <div styleName="clear">Clear All</div>
        </div>
          {
            item.items.map((name, y) => {
              return (
                <div key={`item${y}`} styleName="item-name" onClick={props.onItemClick} style={{height: name.size === 'big' ? '60px' : null}}>
                  <div styleName={name.type}>
                    {
                      ((name.type === 'search' || name.type === 'search-place' || name.type === 'search-name') && !name.isTime) ? (
                        <div styleName="loupe"></div>
                      ) : (
                        <img styleName="recent" style={{verticalAlign: name.separate ? 'top' : null, top: name.separate ? '2px' : null}} src={recentImg} />
                      )
                    }
                    {
                      (name.type === 'time' && name.separate) &&
                        <span styleName="recent-index-separator">{name.index}</span>
                    }
                    {
                      (name.type === 'time' && !name.separate) &&
                        <span styleName="recent-index">{name.index}</span>
                    }
                    {
                      (name.type === 'search-place' || name.type === 'search-name') ? (
                        <div style={{display: "inline-block", verticalAlign: 'top'}}>
                         {
                          name.title.map((title, s) => {
                            if (s !== name.title.length - 1) {
                              return <div key={`search-place-${s}`} styleName="recent-place-text-wrap"><span styleName="recent-place-text" dangerouslySetInnerHTML={{__html: title}}></span><div styleName={name.decorate ? name.decorate : "separator"} ></div></div>;
                            }
                            return <div key={`search-place-${s}`} styleName="recent-place-text-wrap" style={{width: name.size === 'big' ? '300px' : null}}><span styleName="recent-place-text" dangerouslySetInnerHTML={{__html: title}}></span></div>;
                          })
                        }
                        </div>
                      ) : (
                        <span styleName="recent-text" dangerouslySetInnerHTML={{__html: name.title}}></span>
                      )
                    }
                  </div>
                  {
                    name.contact &&
                    <div styleName="contact">{name.contact}</div>
                  }
                </div>
              );
            })
          }
      </div>
    );
  });
  return (
    <div className={props.className} style={{height: item.height, width: item.width}} styleName="root">
      <div styleName="field" >
        <img src={loupe} />
        <span>{item.title}</span>
        <div styleName="controls" >
          <img src={star} />
          <img src={deleteImg} styleName="delete" onClick={props.onCloseClick}/>
        </div>
      </div>
      <div styleName="items">
        {list}
      </div>
      <div styleName="loadButton">
        <Button width="100%" type="load-more-search" paddingLeft={item.loadLeft} >Load More</Button>
      </div>
    </div>
  );
};

SearchDropdown.propTypes = {
  className: PropTypes.string,
};

export default cssModules(SearchDropdown, styles);
