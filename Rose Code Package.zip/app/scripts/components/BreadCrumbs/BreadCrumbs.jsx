import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './BreadCrumbs.css';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['type', 'error'];

const BreadCrumbs = props => {
  const classes = modsClasses(MODS, props, styles);
  const {items} = props;
  const id = items[0];
  const newList = items.slice(1, items.length);
  const list = newList.map((item, i) => {
    const isLast = (i === newList.length - 1) ? 'is-last' : '';
    return (
      <span key={i} styleName={isLast} dangerouslySetInnerHTML={{__html: item}}></span>
    );
  });
  return (
    <div className={classes} styleName="root">
      <div styleName="crum-wrap">
        {
          (props.type && props.type === 'role') &&
            <span styleName="index">012345</span>
        }
        {list}
        <div styleName="delete" onClick={() => {
          props.onClick(id);
        }}></div>
      </div>
    </div>
  );
};

BreadCrumbs.propTypes = {
  className: PropTypes.string,
};

export default cssModules(BreadCrumbs, styles);
