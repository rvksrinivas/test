import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './Warning.css';

import icon from 'images/svg/icons/icon-warning.svg';
import close from 'images/svg/icons/warn-close.svg';

class Warning extends Component {
  render() {
    const {className, onClose, warn} = this.props;
    return (
      <div className={className} styleName="root" style={{display: warn ? 'block' : 'none'}} >
        <img src={icon} styleName="sign" />
        <div styleName="incomplete">Incomplete</div>
        <div styleName="text">Please, select a level 2 theme to continue</div>
        <div styleName="delete" onClick={onClose}>
          <span>Dismiss</span>
          <img src={close} />
        </div>
      </div>
    );
  }
}

Warning.propTypes = {
  className: PropTypes.string,
};

export default CSSModules(Warning, styles);
