import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './DateField.css';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['size'];

const DateField = props => {
  const classes = modsClasses(MODS, props, styles);
  return (
    <div className={classes} styleName="root">
      <input styleName="input" type="text" placeholder="MM/DD/YYYY" value={props.text}/>
    </div>
  );
};

DateField.propTypes = {
  className: PropTypes.string,
};

export default cssModules(DateField, styles);
