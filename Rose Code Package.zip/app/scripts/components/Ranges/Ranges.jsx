import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Ranges.css';

import RangeItem from 'components/RangeItem';

const Ranges = props => {
  return (
    <div className={props.className} styleName="root">
      <div styleName="range-container">
        {
          props.ranges.map(item => {
            return <RangeItem key={item.title} width={item.width} title={item.title} paddingLeft={item.paddingLeft} type={item.centered ? "text-centered" : ""} borderTop={props.borderTop}/>;
          })
        }
      </div>
    </div>
  );
};

Ranges.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Ranges, styles);
