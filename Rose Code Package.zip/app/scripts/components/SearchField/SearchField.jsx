import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './SearchField.css';

import SearchDropdown from 'components/SearchDropdown';

class SearchField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      opened: false,
    };
    this.onCLick = this.onCLick.bind(this);
    this.onCloseClick = this.onCloseClick.bind(this);
    this.onItemClick = this.onItemClick.bind(this);
  }

  onCLick() {
    this.setState({opened: true});
  }

  onItemClick() {
    const {onSearchClick} = this.props;
    if (onSearchClick) {
      onSearchClick();
    }
    this.setState({opened: false});
  }

  onCloseClick() {
    this.setState({opened: false});
  }

  render() {
    const {opened} = this.state;
    return (
      <div className={this.props.className} styleName="root">
        <input type="text" styleName="searchinput" onClick={this.onCLick}/>
        <span styleName="placeholder" >{this.props.action} <b>{this.props.placeholder}</b></span>
        <div style={{display: opened ? "block" : "none"}}>
          <SearchDropdown item={this.props.search} onCloseClick={this.onCloseClick} onItemClick={this.onItemClick} />
        </div>
      </div>
    );
  }
}

SearchField.propTypes = {
  className: PropTypes.string,
};

export default cssModules(SearchField, styles);
