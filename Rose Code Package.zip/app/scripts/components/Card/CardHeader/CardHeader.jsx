import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './CardHeader.css';
import Button from 'components/Button';
import modsClasses from 'utils/modsClasses.js';

import {
  NO_DRAG_FULL,
  DRAG_IN_EMPTY,
} from 'constants/card.js';

const MODS = ['status'];

const isStatus = (name, action) => {
  return action === name ? "block" : "none";
};

const uploadState = status => {
  if (status === DRAG_IN_EMPTY) {
    return "on-upload";
  } else if (status === NO_DRAG_FULL) {
    return "on-upload-full";
  }
  return "upload";
};

class CardHeader extends Component {
  constructor(props) {
    super(props);
    this.onButtonClick = this.onButtonClick.bind(this);
  }

  onButtonClick() {
    this.props.statusChanged();
  }

  onAddButtonClick() {
    this.props.statusChanged();
  }

  getAddClass() {
    const addClass = 'add';
    return this.props.type ? `${addClass}-${this.props.type}` : addClass;
  }

  render() {
    const {status, action, title} = this.props;
    const classes = modsClasses(MODS, this.props, styles);
    const addClass = this.getAddClass();
    return (
      <header className={classes} styleName="root">
        <div styleName="title">{title}</div>
        <div styleName="control">
          <Button display={isStatus("add", action)} type={addClass} onClick={this.onButtonClick}>Add</Button>
          <Button display={isStatus("collapse", action)} type="collapse" onClick={this.onButtonClick}>Collapse</Button>
          <Button display={isStatus("edit", action)} type="edit" onClick={this.onButtonClick}>Edit</Button>
          <div styleName="upload-wrap">
            <Button display={isStatus("upload", action)} type={uploadState(status)} onClick={this.onButtonClick}>
              <div>
                <span>Select</span> or <span>drag</span> file to upload
              </div>
            </Button>
          </div>
        </div>
      </header>
    );
  }
}

CardHeader.propTypes = {
  className: PropTypes.string,
};

export default cssModules(CardHeader, styles);
