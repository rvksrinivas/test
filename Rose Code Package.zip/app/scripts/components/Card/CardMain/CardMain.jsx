import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './CardMain.css';

const CardMain = props => {
  const {isEmpty} = props;
  const showList = isEmpty ? "none" : "block";
  return (
    <main className={props.className} styleName="root" style={{display: showList}}>
      <div styleName="mainContainer">
        {props.children}
      </div>
    </main>
  );
};

CardMain.propTypes = {
  className: PropTypes.string,
};

export default cssModules(CardMain, styles);
