import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './CardAttach.css';
import CardHeader from 'components/Card/CardHeader';
import ProgressBar from 'components/ProgressBar';
import CardMain from 'components/Card/CardMain';
import classnames from 'classnames';

import {
  UPLOAD,
  NO_DRAG_EMPTY,
  NO_DRAG_FULL,
  UPLOADING,
  DRAG_IN_EMPTY,
  DRAG_IN_FULL,
} from 'constants/card.js';

class CardAttach extends Component {
  constructor() {
    super();
    this.state = {
      actionType: UPLOAD,
      filled: false,
      isDragged: false,
      status: NO_DRAG_EMPTY,
      listEmpty: true,
    };
    this.tempStatus = '';
    this.counter = 0;
  }

  onDragOver() {
    const isDragged = this.state.isDragged;
    if (isDragged) {
      return;
    }
    const isEmpty = this.state.listEmpty;
    this.tempStatus = this.state.status;
    const status = (isEmpty) ? DRAG_IN_EMPTY : DRAG_IN_FULL;
    this.setState({status, isDragged: true});
    setTimeout(this.showProgress.bind(this), 2000);
  }

  showProgress() {
    this.setState({status: UPLOADING});
    setTimeout(this.showFullList.bind(this), 2000);
  }

  showFullList() {
    this.setState({status: NO_DRAG_FULL, listEmpty: false, isDragged: false});
  }

  onButtonClick() {
  }

  render() {
    const state = this.state.status;
    const classes = classnames(this.props.className, styles[`status-${this.state.status}`]);
    const inProgress = (state === UPLOADING) ? "block" : "none";
    const inDragOver = (state === DRAG_IN_EMPTY || state === DRAG_IN_FULL) ? "block" : "none";
    if (inProgress === 'none' && inDragOver === 'none') {
      this.counter++;
    }
    const showMore = this.counter > 2;
    return (
      <div className={classes} styleName="root" onDragOver={this.onDragOver.bind(this)} >
        <CardHeader status={state} action={this.state.actionType} title= {this.props.title} />
        <div styleName="dropCanvas" style={{display: inDragOver}}>
          <div styleName="selectordrag">
            <div>
              <span>Select</span> or <span>drag</span> file to upload
            </div>
          </div>
        </div>
        <ProgressBar style={{display: inProgress}}/>
        <CardMain isEmpty={this.state.listEmpty}>
          <this.props.children state={showMore} />
        </CardMain>
      </div>
    );
  }
}

CardAttach.propTypes = {
  className: PropTypes.string,
};

export default cssModules(CardAttach, styles);
