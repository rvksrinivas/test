import React, {Component} from 'react';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
import Modal from './Modal';
import CSSModules from 'react-css-modules';
import styles from './Layout.css';
import {connect} from 'react-redux';

@CSSModules(styles)
class Layout extends Component {
  render() {
    const {modal, children} = this.props;
    return (
      <div styleName="layout" style={{overflow: modal.opened ? "hidden" : "auto"}}>
        <Header />
        <Content>{children}</Content>
        <Footer />
        <Modal />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  modal: state.modal,
});

export default connect(mapStateToProps, null)(Layout);
