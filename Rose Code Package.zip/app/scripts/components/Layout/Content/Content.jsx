import React, {Component} from 'react';
import CSSModules from 'react-css-modules';
import {connect} from 'react-redux';
import styles from './Content.css';

@CSSModules(styles)

class Content extends Component {
  render() {
    const {className, children, modal} = this.props;
    return (
      <div className={className} styleName="content-layout" style={{overflow: modal.opened ? "hidden" : "auto"}}>
        {children}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  modal: state.modal,
});

export default connect(mapStateToProps, null)(Content);
