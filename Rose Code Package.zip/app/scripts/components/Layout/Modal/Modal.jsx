import React, {PropTypes, Component} from 'react';
import {connect} from 'react-redux';
import CSSModules from 'react-css-modules';
import {toggleModal} from 'actions';
import styles from './Modal.css';

import PopupContainer from 'containers/PopupContainer';

@CSSModules(styles)

class Modal extends Component {
  render() {
    const {modal, className, onCloseModal} = this.props;
    return (
      <div className={className} styleName="modal-layout" style={{display: modal.opened ? 'block' : 'none'}}>
        <div styleName="backdrop" onClick={onCloseModal}></div>
        <PopupContainer />
      </div>
    );
  }
}

Modal.propTypes = {
  className: PropTypes.string,
};

const mapDispatchToProps = dispatch => ({
  onCloseModal() {
    dispatch(toggleModal());
  },
});

const mapStateToProps = state => ({
  modal: state.modal,
});

export default connect(mapStateToProps, mapDispatchToProps)(Modal);
