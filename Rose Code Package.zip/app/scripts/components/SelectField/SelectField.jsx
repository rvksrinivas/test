import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './SelectField.css';
import Select from 'react-select';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['type'];

class SelectField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: props.value,
    };
    this.onChange = this.onChange.bind(this);
  }

  onChange(data) {
    this.setState({value: data.value});
  }

  render() {
    const props = this.props;
    let {value} = this.state;
    const classes = modsClasses(MODS, props, styles);
    value = value ? value : '';
    return (
      <div className={classes} styleName="root">
        <Select placeholder={props.placeholder}
          onChange={this.onChange}
          className={'select'} value={value} options={props.options} />
      </div>
    );
  }
}

SelectField.propTypes = {
  className: PropTypes.string,
};

export default cssModules(SelectField, styles);
