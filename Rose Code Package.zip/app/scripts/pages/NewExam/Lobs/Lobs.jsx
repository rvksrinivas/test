import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Lobs.css';
import Ranges from 'components/Ranges';
import {ranges, lobs} from './lobs.js';
import LobItem from './LobItem';

const Lobs = props => {
  const {status, showAll, defaultCount} = props;
  const showInfo = (status === "edit") ? 'block' : 'none';
  const list = showAll ? lobs : lobs.slice(0, Number(defaultCount));
  return (
    <div className={props.className} styleName="root" style={{display: showInfo}} >
      <Ranges ranges={ranges} />
      {
        list.map((item, i) => {
          return <LobItem key={i} item={item} id={`lobs-${i}`}/>;
        })
      }
    </div>
  );
};

Lobs.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Lobs, styles);
