import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Attachments.css';
import Ranges from 'components/Ranges';
import {ranges, items} from './attachments.js';
import AttachmentItem from './AttachmentItem';

const Attachments = props => {
  const {state} = props;
  let newItems = [...items];
  if (!state) {
    newItems = newItems.slice(0, 1);
  }

  return (
    <div className={props.className} styleName="root">
      <Ranges ranges={ranges} />
      {
        newItems.map((item, i) => {
          return <AttachmentItem key={i} item={item} id={`attachment-${i}`}/>;
        })
      }
    </div>
  );
};

Attachments.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Attachments, styles);
