import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './EntetieItem.css';
import Checkbox from 'components/Checkbox';

class EntetieItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checked: false,
    };
    this.onClick = this.onClick.bind(this);
  }

  onClick() {
    const {checked} = this.state;
    this.setState({checked: !checked});
  }

  render() {
    const props = this.props;
    const {checked} = this.state;
    const {location} = props.item;
    const locations = location.map((item, i) => {
      if (i !== location.length - 1) {
        return (
          <div key={i}>
            <span>{item}</span>
            <div styleName="separator"></div>
          </div>
        );
      }
      return (
        <div key={i}>
          <span>{item}</span>
        </div>
      );
    });
    return (
      <div className={props.className} styleName="root">
        <div styleName="title">{props.item.title}</div>
        <div styleName="location">{locations}</div>
        <div styleName="primary">
          <Checkbox type="square" id={props.id} checked={checked} onClick={this.onClick} />
        </div>
        <div styleName="leader">{props.item.leader}</div>
        <div styleName="delete">
          <div styleName="delete-icon"></div>
        </div>
      </div>
    );
  }
}

EntetieItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(EntetieItem, styles);
