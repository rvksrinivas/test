export const ranges = [
  {
    title: 'Examining Entities',
    width: '401px',
  },
  {
    title: 'Examiner Location',
    width: '220px',
  },
  {
    title: 'Primary',
    width: '100px',
  },
  {
    title: 'Lead Examiner(s)',
    width: '178px',
  },
  {
    title: 'Delete',
    width: '99px',
    centered: true,
  },
];

export const enteties = [
  {
    title: 'Australian Prudential Regulation (AU.APRA)',
    location: ['APAC', 'Australia'],
    leader: 'Chirola, Peter',
  },
  {
    title: 'Australian Securities and Investments Commission (AU.ASIC)',
    location: ['APAC', 'Australia'],
    leader: '',
  },
  {
    title: 'Australian Securities and Investments Commission (AU.ASIC)',
    location: ['APAC', 'Australia'],
    leader: '',
  },
  {
    title: 'Australian Securities and Investments Commission (AU.ASIC)',
    location: ['APAC', 'Australia'],
    leader: '',
  },
  {
    title: 'Australian Securities and Investments Commission (AU.ASIC)',
    location: ['APAC', 'Australia'],
    leader: '',
  },
];
