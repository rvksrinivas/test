export const ranges = [
  {
    title: 'Region',
    width: '239px',
  },
  {
    title: 'Country',
    width: '270px',
  },
  {
    title: 'Primary',
    width: '110px',
  },
  {
    title: 'Involvement',
    width: '280px',
  },
  {
    title: 'Delete',
    width: '99px',
    centered: true,
  },
];

export const primaries = [
  {
    region: 'North America',
    country: 'United States',
  },
  {
    region: 'North America',
    country: 'Canada',
  },
  {
    region: 'Asia Pacific',
    country: 'All',
  },
];
