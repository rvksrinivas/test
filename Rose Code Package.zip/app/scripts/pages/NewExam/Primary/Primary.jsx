import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Primary.css';
import Ranges from 'components/Ranges';
import PrimaryItem from './PrimaryItem';
import {ranges, primaries} from './primary.js';

const Primary = props => {
  const {status, showAll, defaultCount} = props;
  const showInfo = (status === "edit") ? 'block' : 'none';
  const list = showAll ? primaries : primaries.slice(0, Number(defaultCount));
  return (
    <div className={props.className} styleName="root" style={{display: showInfo}} >
      <Ranges ranges={ranges} />
      {
        list.map((item, i) => {
          return <PrimaryItem key={i} item={item}/>;
        })
      }
    </div>
  );
};

Primary.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Primary, styles);
