import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './LegalItem.css';
import Toggle from 'components/Toggle';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['type'];

const toggleItems = [
  {
    title: 'RESPONSIBLE',
    value: 'resposible',
    width: '120px',
  },
  {
    title: 'INFORMED',
    value: 'informed',
    width: '120px',
  },
];

const LegalItem = props => {
  const classes = modsClasses(MODS, props, styles);
  return (
    <div className={classes} styleName="root">
      <div styleName="title">{props.title}</div>
      <div styleName="involvement">
        <Toggle items={toggleItems} name={props.id} category={props.id} size="medium" type="joined" />
      </div>
      <div styleName="delete"><div styleName="delete-icon"></div></div>
    </div>
  );
};

LegalItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(LegalItem, styles);
