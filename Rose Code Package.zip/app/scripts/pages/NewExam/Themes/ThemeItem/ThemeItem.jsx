import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './ThemeItem.css';
import Tooltip from 'components/Tooltip';

const ThemeItem = props => {
  const {item} = props;
  return (
    <div className={props.className} styleName="root">
      <div styleName="name">{item.name}</div>
      <div styleName="descr">
        <span>
          {item.descr}
        </span>
        <Tooltip title="Description" descr={item.descr} style={{paddingLeft: "7px", top: "-2px"}}/>
      </div>
      <div styleName="l1">{item.l1}</div>
      <div styleName="l2">{item.l2}</div>
      <div styleName="delete"><div styleName="delete-icon"></div></div>
    </div>
  );
};

ThemeItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(ThemeItem, styles);
