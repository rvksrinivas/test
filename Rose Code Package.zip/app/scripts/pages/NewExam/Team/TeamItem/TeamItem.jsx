import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './TeamItem.css';

const TeamItem = props => {
  return (
    <div className={props.className} styleName="root" style={{width: props.width}}>
      {
        props.items.map((item, i) => {
          return (
            <div styleName="person" key={i}>
              {item}
              <div styleName="delete" style={{right: props.right}} onClick={() => {
                props.onClick(i, props.order);
              }}></div>
            </div>
          );
        })
      }
    </div>
  );
};

TeamItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(TeamItem, styles);
