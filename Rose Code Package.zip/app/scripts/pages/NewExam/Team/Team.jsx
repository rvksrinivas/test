import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Team.css';
import {ranges, roles} from './team.js';
import Ranges from 'components/Ranges';
import TeamItem from './TeamItem';
import {forEach} from 'lodash';

class Team extends Component {
  constructor(props) {
    super(props);
    this.state = {
      allRoles: [...roles],
      popupOpened: false,
    };
    this.currentCoordinate = {};
    this.onDeleteClick = this.onDeleteClick.bind(this);
    this.onCancelClick = this.onCancelClick.bind(this);
    this.onTeamClick = this.onTeamClick.bind(this);
  }

  onCancelClick() {
    this.setState({popupOpened: false});
  }

  onDeleteClick() {
    const newRoles = [...this.state.allRoles];
    const coord = this.currentCoordinate;
    newRoles[coord.order].items.splice(coord.val, 1);
    this.setState({allRoles: newRoles, popupOpened: false});
  }

  onTeamClick(val, order) {
    this.currentCoordinate = {
      val,
      order,
    };
    if (this.state.popupOpened) {
      return;
    }
    this.setState({popupOpened: true});
  }

  filterRoles(list, showAll) {
    const tempList = list.slice();
    let newList = [];
    if (showAll) {
      newList = tempList;
    } else {
      forEach(tempList, item => {
        const data = {
          width: item.width,
          items: item.items.slice(0, 1),
        };
        newList.push(data);
      });
    }
    return newList;
  }

  render() {
    const props = this.props;
    const {status, showAll, defaultCount} = props;
    const {allRoles, popupOpened} = this.state;
    const showInfo = (status === "edit") ? 'block' : 'none';
    const filtered = this.filterRoles(allRoles, showAll);
    return (
      <div className={props.className} styleName="root" style={{display: showInfo}} >
        <Ranges ranges={ranges} />
        <div styleName="team-container">
          {
            filtered.map((item, i) => {
              return <TeamItem key={i} items={item.items} id={`team-${i}`} order={i} width={item.width} right={item.right} onClick={this.onTeamClick}/>;
            })
          }
        </div>
        <div styleName="delete-popup" style={{display: popupOpened ? 'block' : 'none'}}>
          <div styleName="delete-title">Are you sure you want to delete this individual?</div>
          <div styleName="delete-button" onClick={this.onDeleteClick}>
            DELETE
          </div>
          <div styleName="delete-button" onClick={this.onCancelClick}>
            CANCEL
          </div>
        </div>
      </div>
    );
  }
}

Team.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Team, styles);
