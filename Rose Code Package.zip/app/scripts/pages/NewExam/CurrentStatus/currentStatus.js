export const trends = [
  {
    title: 'Green',
    value: 'green',
    width: '150px',
    color: 'green',
  },
  {
    title: 'Amber',
    value: 'amber',
    width: '150px',
    color: 'amber',
  },
  {
    title: 'Red',
    value: 'red',
    width: '150px',
    color: 'red',
  },
];

export const options = [
  {
    value: 'weekly',
    label: 'Weekly',
  },
  {
    value: 'yearly',
    label: 'Yearly',
  },
];

export const ranges = [
  {
    title: 'Last Updated',
    width: '101px',
    paddingLeft: '8px',
  },
  {
    title: 'Frequency',
    width: '80px',
    paddingLeft: '10px',
  },
  {
    title: 'Key Message',
    width: '319px',
    paddingLeft: '17px',
  },
  {
    title: 'Current Status',
    width: '426px',
  },
  {
    title: 'Rate',
    width: '72px',
    paddingLeft: '14px',
  },
];

export const statuses = [
  {
    date: '02/15/2017',
    frequent: 'Weekly',
    message: 'There should be an key message that Lorem…',
    status: 'The current status is a long sentence Lorem ipsum dolor sit …',
    rate: 'Green',
  },
];
