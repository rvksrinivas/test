import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './StatusItem.css';
import Tooltip from 'components/Tooltip';

const StatusItem = props => {
  const {item} = props;
  return (
    <div className={props.className} styleName="root">
      <div styleName="date">{item.date}</div>
      <div styleName="frequency">{item.frequent}</div>
      <div styleName="message">
        <span>
          {item.message}
        </span>
        <Tooltip title="Key Message" descr={item.message} style={{paddingLeft: "4px", top: "-2px"}}/>
      </div>
      <div styleName="status">
        <span>
          {item.status}
        </span>
        <Tooltip title="Current Status" descr={item.status} style={{paddingLeft: "9px", top: "-2px"}}/>
      </div>
      <div styleName={`rate-${item.rate.toLowerCase()}`}>{item.rate}</div>
    </div>
  );
};

StatusItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(StatusItem, styles);
