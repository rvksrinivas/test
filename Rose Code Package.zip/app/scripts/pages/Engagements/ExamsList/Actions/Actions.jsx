import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import {Link} from 'react-router';
import styles from './Actions.css';

import Button from 'components/Button';

const Actions = props => {
  return (
    <div className={props.className} styleName="root">
      <div styleName="title" >CPAC - 1</div>
      <div styleName="controls" >
        <div styleName="upload">Upload Bulk Utility</div>
        <Link to="/new_exam">
          <Button styleName="button" hover="orange" width="150px" type="add-exam">
            <span>Create New Exam</span>
          </Button>
        </Link>
        <Button styleName="button" hover="orange" width="180px" type="add-exam">
          <span>Create New Non Exam</span>
        </Button>
      </div>
    </div>
  );
};

Actions.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Actions, styles);
