import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import CSSModules from 'react-css-modules';
import styles from './ExamsList.css';
import Exams from './Exams';
import Search from './Search';
import Ranges from './Ranges';
import Actions from './Actions';
import Dropdown from './Dropdown';
import Button from 'components/Button';
import {filter, forEach} from 'lodash';

@CSSModules(styles)
class ExamsList extends Component {

  constructor(props) {
    super(props);
    this.state = {
      dropDownOpened: false,
    };
  }

  closeDropdown = () => {
    this.setState({dropDownOpened: false});
  }

  openDropdown = () => {
    this.setState({dropDownOpened: true});
  }

  render() {
    const {exams} = this.props;
    const state = this.state.dropDownOpened ? 'block' : 'none';
    const hasMore = exams.length === 14 ? 'block' : 'none';
    return (
      <div className={this.props.className} styleName="root">
        <Actions />
        <Search />
        <Ranges onFilterClick={this.openDropdown}/>
        <Exams exams={exams}/>
        <div styleName="loadButton" style={{display: hasMore}}>
          <Button width="960px" type="load-exam">Load More</Button>
        </div>
        <Dropdown styleName="dropdown" state={state} onCloseClick={this.closeDropdown} />
      </div>
    );
  }
}

const typeFilter = data => {
  let list = data.exams;
  list = filter(list, item => {
    switch (data.type) {
      case 'exams':
        return item.type !== 'Non Exam';
      case 'non-exams':
        return item.type === 'Non Exam';
      default:
        return item;
    }
  });
  return list;
};

const categoryFilter = (category, list) => {
  list = filter(list, item => {
    if (category === 'all') {
      return item;
    }
    return item.category === category;
  });
  return list;
};

const phaseFilter = (phases, list) => {
  list = filter(list, item => {
    let hasState = false;
    forEach(phases, phase => {
      if (phase === item.state) {
        hasState = true;
      }
    });
    return hasState;
  });
  return list;
};

const getFilteredExam = data => {
  let list = typeFilter(data);
  list = categoryFilter(data.category, list);
  if (data.type === 'exams') {
    list = phaseFilter(data.phases, list);
  }
  return (list.length > 14) ? list.slice(0, 14) : list;
};

const mapStateToProps = state => ({
  exams: getFilteredExam(state.engagments),
});

ExamsList.propTypes = {
  className: PropTypes.string,
};

export default connect(mapStateToProps)(ExamsList);
