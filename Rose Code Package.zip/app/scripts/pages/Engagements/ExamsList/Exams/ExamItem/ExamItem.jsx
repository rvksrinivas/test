import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './ExamItem.css';
import modsClasses from 'utils/modsClasses.js';
import examArrow from 'images/svg/icons/exam-arrow.svg';

const MODS = ['state'];

const ExamItem = props => {
  const {item} = props;
  const classes = modsClasses(MODS, props, styles);
  return (
    <div className={classes} styleName="root">
      <div styleName="type">{item.type}</div>
      <div styleName="id">{item.id}</div>
      <div styleName="name">{item.name}</div>
      <div styleName="stage"><div styleName="state">{item.stage}</div></div>
      <div styleName="manager">{item.manager}</div>
      <div styleName="update">{item.update}</div>
      <div styleName="arrow"><img src={examArrow} /></div>
    </div>
  );
};

ExamItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(ExamItem, styles);
