import React, {Component, PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Search.css';

class Search extends Component {
  constructor(props) {
    super(props);

    this.state = {
      searchText: '',
      visible: true,
    };
    this.onFocus = this.onFocus.bind(this);
    this.onBlur = this.onBlur.bind(this);
  }

  onFocus() {
    this.setState({visible: false});
  }

  onBlur(e) {
    const value = e.target.value;
    if (!value.trim()) {
      this.setState({visible: true});
    }
  }

  render() {
    const {visible} = this.state;
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="searchfield">
          <input type="text" styleName="searchinput" onFocus={this.onFocus} onBlur={this.onBlur} />
          <span style={{display: visible ? 'block' : 'none'}} styleName="placeholder">Enter <b>Exam Name</b> or <b>Exam ID number</b></span>
        </div>
      </div>
    );
  }
}

Search.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Search, styles);
