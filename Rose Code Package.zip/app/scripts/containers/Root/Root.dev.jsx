import React from 'react';
import {Provider} from 'react-redux';
import AppRouter from 'containers/AppRouter';
import DevTools from 'containers/DevTools';

const Root = ({store, history}) => (
  <Provider store={store}>
    <div>
      <AppRouter history={history} />
      <DevTools />
    </div>
  </Provider>
);

export default Root;
