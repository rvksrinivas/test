import React, {PropTypes, Component} from 'react';
import {connect} from 'react-redux';

import Lobs from 'modals/Lobs';
import Team from 'modals/Team';
import Legal from 'modals/Legal';
import Theme from 'modals/Theme';
import Request from 'modals/Request';
import Location from 'modals/Location';
import Enteties from 'modals/Enteties';
import Metadata from 'modals/Metadata';

import Popup from 'components/Popup';

class PopupContainer extends Component {

  getModal() {
    const {modal} = this.props;

    switch (modal.name) {
      case 'location':
        return <Location />;
      case 'lobs':
        return <Lobs />;
      case 'legal':
        return <Legal />;
      case 'examing':
        return <Enteties />;
      case 'request':
        return <Request />;
      case 'team':
        return <Team />;
      case 'theme':
        return <Theme />;
      case 'metadata':
        return <Metadata />;
      default:
        return <Location />;
    }
  }
  render() {
    const popup = this.getModal();
    return (
      <div className={this.props.className} style={{width: '100%', height: '100%'}}>
        {popup}
      </div>
    );
  }
}

PopupContainer.propTypes = {
  className: PropTypes.string,
};

const mapStateToProps = state => ({
  modal: state.modal,
});

export default connect(mapStateToProps)(PopupContainer);
