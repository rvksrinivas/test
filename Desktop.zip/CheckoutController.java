package com.aukhar.yogasangeeta.controller;

import com.aukhar.yogasangeeta.common.AnonymousDTO;
import com.aukhar.yogasangeeta.common.Cart;
import com.aukhar.yogasangeeta.common.CommonOperations;
import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Result;
import com.braintreegateway.Transaction;
import com.braintreegateway.Transaction.Status;
import com.braintreegateway.TransactionRequest;
import com.braintreegateway.Customer;
import com.braintreegateway.ValidationError;
import com.braintreegateway.Subscription;
import com.braintreegateway.SubscriptionRequest;
import com.braintreegateway.CreditCard;
import com.braintreegateway.PaymentMethod;
import com.braintreegateway.PaymentMethodRequest;
import com.braintreegateway.*;
import com.braintreegateway.exceptions.NotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.util.Arrays;

import com.aukhar.yogasangeeta.common.Constants;
import com.aukhar.yogasangeeta.common.Mail;
import com.aukhar.yogasangeeta.common.SubscriptionDTO;
import com.aukhar.yogasangeeta.db.User;
import com.aukhar.yogasangeeta.model.AccountManager;
import com.aukhar.yogasangeeta.model.PaymentManager;
import com.aukhar.yogasangeeta.model.SubscriptionManager;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CheckoutController {
    
@Autowired
private PaymentManager paymentManager;
    
@Autowired
private AccountManager accountManager;

@Autowired
private SubscriptionManager subscriptionManager;

private final BraintreeGateway gateway = new BraintreeGateway(
                                   Constants.btEnvironment,
                                   Constants.btMerchantId,
                                   Constants.btPublicKey,
                                   Constants.btPrivateKey
                                );

// Get Customer ID -- parameter customer email 
// Usage: <url>/custid?emailid=
@RequestMapping(value = "/custid")
@ResponseBody
String getName(@RequestParam("emailid") String emailId){
     CustomerSearchRequest request = new CustomerSearchRequest()
                      .email().is(emailId);
                    ResourceCollection<Customer> collection = gateway.customer().search(request);
                    collection.getIds().toString();
                    System.out.println("Cust Id output " + collection.getIds().toString());
  return collection.getIds().toString();
}

// Create new Customer ID -- parameters customer firstName, lastName, email and phone
// Usage: <url>/newCust?firstName=&lastName=&email=&phone=  
@RequestMapping(value = "/newCust")
@ResponseBody
public String postCustForm(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName, 
            @RequestParam("email") String email, @RequestParam("phone") String phone) {

    CustomerSearchRequest request = new CustomerSearchRequest()
                      .email().is(email);
    ResourceCollection<Customer> collection = gateway.customer().search(request);

    System.out.println("Customer Id is" + collection.getIds().toString());

    if (collection.getIds().toString().equals("") || "[]".equals(collection.getIds().toString())) {
        CustomerRequest newCust = new CustomerRequest()
        .firstName(firstName)
        .lastName(lastName)
        .email(email)
        .phone(phone);
        Result<Customer> custResult = gateway.customer().create(newCust);

        if (custResult.isSuccess()) {
            // true
            return custResult.getTarget().getId();
            // e.g. 594019
        } else {
            return custResult.getErrors().toString();
        }
    } else {
            String custId = collection.getIds().toString();
            return  custId + " - Customer already exists.";
    }                                
}

// New customer transaction GET method
@RequestMapping(value = "/newCustTrans", method = RequestMethod.GET)
public String custTrans(Model model) {
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);

    return "checkouts/newCustTrans";
}

@RequestMapping(value = "/newCustTrans", method = RequestMethod.POST)
@ResponseBody
public String postNewCustTransForm(@RequestParam("amount") String amount,@RequestParam("customerId") String customerId,  
@RequestParam("payment_method_nonce") String nonce, Model model, final RedirectAttributes redirectAttributes) {
    return postNewCustTransForm(amount, customerId, nonce, model, redirectAttributes, null);
}


public String postNewCustTransForm(@RequestParam("amount") String amount,@RequestParam("customerId") String customerId,  
@RequestParam("payment_method_nonce") String nonce, Model model, final RedirectAttributes redirectAttributes, String currency) {

        //String custId = findCustId(email);		
        BigDecimal decimalAmount;
    try {
        decimalAmount = new BigDecimal(amount);
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Amount is an invalid format.");
        return "redirect:checkouts/newCustTrans";
    }
    //String payTkn = "7s7zfs";
    TransactionRequest request = new TransactionRequest()
                      .amount(decimalAmount)
                      .paymentMethodNonce(nonce)
                      .customerId(customerId)
                      .options()
                        .storeInVaultOnSuccess(true)
                        .submitForSettlement(true)
                        .done(); 
     if(currency != null && currency.equals("INR")) {
        request.merchantAccountId("YSMerchantAccount_INR");
    }
     Result<Transaction> result = gateway.transaction().sale(request);
             //System.out.println("Result is = " + result.getTarget());
             //System.out.println("Payment type is = " + result.getTarget().getPaymentInstrumentType());

             String custPayDtls = null;
             if(result.getTarget() != null) {
    switch (result.getTarget().getPaymentInstrumentType()) {
        case "credit_card":
            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
                    ",paymentMethod:" + result.getTarget().getCreditCard().getToken() +
                    ",cardType:" + result.getTarget().getCreditCard().getCardType();
//                    ",cardLast4:" + result.getTarget().getCreditCard().getLast4() +
//                    ",expMonth:" + result.getTarget().getCreditCard().getExpirationMonth() +
//                    ",expYear:" + result.getTarget().getCreditCard().getExpirationYear();
            break;
        case "paypal_account":
            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
                    ",paymentMethod:" + result.getTarget().getPayPalDetails().getToken() +
                    ",payerId:" +result.getTarget().getPayPalDetails().getPayerId() +
                    ",paymentId:" + result.getTarget().getPayPalDetails().getPaymentId() +
                    ",payerEmail:" +result.getTarget().getPayPalDetails().getPayerEmail();
            break;
        case "apple_pay_card":
            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
                    ",paymentMethod:" + result.getTarget().getApplePayDetails().getToken() +
                    ",paymentName:" + result.getTarget().getApplePayDetails().getPaymentInstrumentName() +
                    ",cardType:" + result.getTarget().getApplePayDetails().getCardType();
//                    ",cardLast4:" + result.getTarget().getApplePayDetails().getLast4() +
//                    ",expMonth:" + result.getTarget().getApplePayDetails().getExpirationMonth() +
//                    ",expYear:" + result.getTarget().getApplePayDetails().getExpirationMonth();
            break;
        case "venmo_account":
            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
                    ",paymentMethod:" + result.getTarget().getVenmoAccountDetails().getToken() +
                    ",userId:" + result.getTarget().getVenmoAccountDetails().getVenmoUserId()  +
                    ",userName:" + result.getTarget().getVenmoAccountDetails().getUsername();
            break;
        default:
            break;
    }
             }
             
    if (result.isSuccess()) {
        Transaction transaction = result.getTarget();
        System.out.println("Transaction is = " + transaction.getId());
        String output = "customerId:" + customerId + custPayDtls +  
            ",transactionId:" + transaction.getId() + ",transactionType:" + transaction.getType()  + 
            ",transactionAmount:" + transaction.getAmount() + ",transactionStatus:" + transaction.getStatus();
        return output;
    } else {
        return result.getMessage();
    }
}

//TRANSACTIONS for existing customer with Payment Method in BT Vault 
@RequestMapping(value = "/custTrans")
@ResponseBody
public String postCustTransForm(@RequestParam("amount") String amount,@RequestParam("customerId") String customerId,  
@RequestParam("payTkn") String payTkn, Model model, final RedirectAttributes redirectAttributes) {
        
    //String custId = findCustId(email);		
    BigDecimal decimalAmount;
    try {
        decimalAmount = new BigDecimal(amount);
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Amount is an invalid format.");
        return "redirect:checkouts/custTrans";
    }

    TransactionRequest request = new TransactionRequest()
                      .amount(decimalAmount)
                      .paymentMethodToken(payTkn)
                      //.paymentMethodNonce(nonce)
                      //.customerId(custId)
                      .options()
                        //.storeInVaultOnSuccess(true)
                        .submitForSettlement(true)
                        .done();
     Result<Transaction> result = gateway.transaction().sale(request);
             System.out.println("Result is = " + result.getTarget());

//    String custPayDtls = "";
//    switch (result.getTarget().getPaymentInstrumentType()) {
//        case "credit_card":
//            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
//                    ",paymentMethod:" + findPayMethods(custId) +
//                    ",cardType:" + result.getTarget().getCreditCard().getCardType() +
//                    ",cardLast4Digits:" + result.getTarget().getCreditCard().getLast4() +
//                    ",expMonth:" + result.getTarget().getCreditCard().getExpirationMonth() +
//                    ",expYear:" + result.getTarget().getCreditCard().getExpirationYear();
//            break;
//        case "paypal_account":
//            System.out.println("Inside Paypal_account");
//            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
//                    ",paymentMethod:" + findPayMethods(custId) +
//                    ",payerId:" +result.getTarget().getPayPalDetails().getPayerId() +
//                    ",paymentId:" + result.getTarget().getPayPalDetails().getPaymentId() +
//                    ",payerEmail:" +result.getTarget().getPayPalDetails().getPayerEmail();
//            System.out.println("Customer Pay details is: " + custPayDtls);
//            break;
//        case "apple_pay_card":
//            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
//                    ",paymentMethod:" + findPayMethods(custId) +
//                    ",paymentName:" + result.getTarget().getApplePayDetails().getPaymentInstrumentName() +
//                    ",cardType:" + result.getTarget().getApplePayDetails().getCardType() +
//                    ",cardLast4:" + result.getTarget().getApplePayDetails().getLast4() +
//                    ",expMonth:" + result.getTarget().getApplePayDetails().getExpirationMonth() +
//                    ",expYear:" + result.getTarget().getApplePayDetails().getExpirationMonth();
//            break;
//        case "venmo_account":
//            custPayDtls = ",paymentType:" + result.getTarget().getPaymentInstrumentType() +
//                    ",paymentMethod:" + findPayMethods(custId) +
//                    ",userId:" + result.getTarget().getVenmoAccountDetails().getVenmoUserId()  +
//                    ",userName:" + result.getTarget().getVenmoAccountDetails().getUsername();
//            break;
//        default:
//            break;
//    }

    if (result.isSuccess()) {
        Transaction transaction = result.getTarget();
        System.out.println("Transaction is = " + transaction.getId());
        String custPayDtls = ",Using existing payment method";
        String output = "customerId:" + customerId  + ",transactionId:" + transaction.getId() + 
        ",transactionType:" + transaction.getType()  + ",transactionAmount:" + transaction.getAmount() +
        ",transactionStatus:" + transaction.getStatus();
        return output + custPayDtls;
    } else {
        return result.getMessage();
    }
}

public String newSub(String customerId, String planId, String payTkn, String nonce, Model model, final RedirectAttributes redirectAttributes) {

    Customer customer;
    try {
        customer = gateway.customer().find(customerId);
        System.out.println("Customer ID  is " + customer.getId());
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Customer Id  is invalid.");
        return "redirect:subscriptions";
    }

    Result<Subscription> subsResult = null;
    String custPayDtls = null;
    if (payTkn.equals("") || "".equals(payTkn)) {
        System.out.println("Inside Payment token is null");
        PaymentMethodRequest payRequest = new PaymentMethodRequest()
                .customerId(customerId)
                .paymentMethodNonce(nonce);
        Result<? extends PaymentMethod> payResult = gateway.paymentMethod().create(payRequest);
        System.out.println("Token is = " + payResult.getTarget().getToken());

        SubscriptionRequest subsRequest = new SubscriptionRequest()
                .paymentMethodToken(payResult.getTarget().getToken())
                .planId(planId);
        subsResult = gateway.subscription().create(subsRequest);
        System.out.println("Subscription created with new payment method");
        Transaction subTrans = subsResult.getTarget().getTransactions().get(0);
        if (subTrans.getPaymentInstrumentType().equals("credit_card")) {
            custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                    + ",paymentMethod:" + subTrans.getCreditCard().getToken()
                    + ",cardType:" + subTrans.getCreditCard().getCardType()
                    + ",cardLast4:" + subTrans.getCreditCard().getLast4()
                    + ",expMonth:" + subTrans.getCreditCard().getExpirationMonth()
                    + ",expYear:" + subTrans.getCreditCard().getExpirationYear();
        } else if (subTrans.getPaymentInstrumentType().equals("paypal_account")) {
            System.out.println("Inside Paypal_account");
            custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                    + ",paymentMethod:" + subTrans.getPayPalDetails().getToken()
                    + ",payerId:" + subTrans.getPayPalDetails().getPayerId()
                    + ",paymentId:" + subTrans.getPayPalDetails().getPaymentId()
                    + ",payerEmail:" + subTrans.getPayPalDetails().getPayerEmail();
            System.out.println("Customer Pay details is: " + custPayDtls);
        } else if (subTrans.getPaymentInstrumentType().equals("apple_pay_card")) {
            custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                    + ",paymentMethod:" + subTrans.getApplePayDetails().getToken()
                    + ",paymentName:" + subTrans.getApplePayDetails().getPaymentInstrumentName()
                    + ",cardType:" + subTrans.getApplePayDetails().getCardType()
                    + ",cardLast4:" + subTrans.getApplePayDetails().getLast4()
                    + ",expMonth:" + subTrans.getApplePayDetails().getExpirationMonth()
                    + ",expYear:" + subTrans.getApplePayDetails().getExpirationMonth();
        } else if (subTrans.getPaymentInstrumentType().equals("venmo_account")) {
            custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                    + ",paymentMethod:" + subTrans.getVenmoAccountDetails().getToken()
                    + ",userId:" + subTrans.getVenmoAccountDetails().getVenmoUserId()
                    + ",userName:" + subTrans.getVenmoAccountDetails().getUsername();
        }
    } else if (!payTkn.equals("") || payTkn == "") {
        System.out.println("Inside Payment token is NOT null");
        SubscriptionRequest subsRequest = new SubscriptionRequest()
                .paymentMethodToken(payTkn)
                .planId(planId);
        subsResult = gateway.subscription().create(subsRequest);
        custPayDtls = ",Using existing payment method";
        System.out.println("Subscription created with existing payment method");
    }

    if (subsResult.isSuccess()) {
        Subscription subscription = subsResult.getTarget();
        String transDetails = "transactionId:" + subsResult.getTarget().getTransactions().get(0).getId()
                + ",transactionType:" + subsResult.getTarget().getTransactions().get(0).getType()
                + ",transactionAmount:" + subsResult.getTarget().getTransactions().get(0).getAmount().toString()
                + ",transactionStatus:" + subsResult.getTarget().getTransactions().get(0).getStatus().toString()
                + custPayDtls;
        //return "redirect:subscriptions/" + subscription.getId();
        System.out.println("Subscription status =" + subsResult.getTarget().getStatus().toString());
        return "subscriptionId:" + subscription.getId() + ",subscriptionStatus:" + subscription.getStatus().toString()
                + ",subscriptionBalance:" + subscription.getBalance() + "," + transDetails;
    } else {
        return subsResult.getMessage();
    }
}

@RequestMapping(value = "/overrideSubs")
@ResponseBody
public String overrideSubs(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId,
        @RequestParam("price") String price, @RequestParam("numBillCycles") Integer numBillCycles, @RequestParam("payTkn") String payTkn,
        @RequestParam("firstBillingCycle") String firstBillingCycle, Model model, final RedirectAttributes redirectAttributes)
        throws ParseException, java.text.ParseException {

    return overrideSub(customerId, planId, payTkn, null, price, numBillCycles, firstBillingCycle, model, redirectAttributes);
}

@RequestMapping(value = "/newPayOverSubs", method = RequestMethod.GET)
public String newPayOverSubs(Model model) {
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);

    return "subscriptions/upd";
}

@RequestMapping(value = "/newPayOverSubs", method = RequestMethod.POST)
@ResponseBody
public String newPayOverSubs(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId,
        @RequestParam("price") String price, @RequestParam("numBillCycles") Integer numBillCycles,
        @RequestParam("payment_method_nonce") String nonce, @RequestParam("firstBillingCycle") String firstBillingCycle,
        Model model, final RedirectAttributes redirectAttributes)
        throws ParseException, java.text.ParseException {

    return overrideSub(customerId, planId, "", nonce, price, numBillCycles, firstBillingCycle, model, redirectAttributes);
} 


public String overrideSub(String customerId, String planId, String payTkn, String nonce, String price, Integer numBillCycles,
        String firstBillingCycle, Model model, final RedirectAttributes redirectAttributes) throws java.text.ParseException {

    Customer customer;
    //String custToken;
    try {
        customer = gateway.customer().find(customerId);
        System.out.println("Customer ID  is " + customer.getId());
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Customer Id  is invalid.");
        return "redirect:subscriptions";
    }

    Result<Subscription> ovrSubsResult = null;
    String custPayDtls = null;

    if (payTkn.equals("") || payTkn == "") {
        System.out.println("Inside Payment token is null");
        PaymentMethodRequest payRequest = new PaymentMethodRequest()
                .customerId(customerId)
                .paymentMethodNonce(nonce);
        Result<? extends PaymentMethod> ovrPayResult = gateway.paymentMethod().create(payRequest);
        System.out.println("Token is = " + ovrPayResult.getTarget().getToken());

        System.out.println("Price is " + price);
        System.out.println("numBillCycles is " + numBillCycles);
        System.out.println("firstBillingCycle is " + firstBillingCycle);

        Double amount = Double.parseDouble(price);

        SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
        Date dateObj = curFormater.parse(firstBillingCycle);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateObj);

        SubscriptionRequest ovrSubsRequest = new SubscriptionRequest()
                .paymentMethodToken(ovrPayResult.getTarget().getToken())
                .planId(planId)
                .price(new BigDecimal(amount).setScale(2, 2))
                .numberOfBillingCycles(numBillCycles)
                .firstBillingDate(calendar);
       

        ovrSubsResult = gateway.subscription().create(ovrSubsRequest);

        System.out.println("Subscription created with new payment method");

        Transaction subTrans = ovrSubsResult.getTarget().getTransactions().get(0);
        switch (subTrans.getPaymentInstrumentType()) {
            case "credit_card":
                custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                        + ",paymentMethod:" + subTrans.getCreditCard().getToken()
                        + ",cardType:" + subTrans.getCreditCard().getCardType()
                        + ",cardLast4:" + subTrans.getCreditCard().getLast4()
                        + ",expMonth:" + subTrans.getCreditCard().getExpirationMonth()
                        + ",expYear:" + subTrans.getCreditCard().getExpirationYear();
                break;
            case "paypal_account":
                System.out.println("Inside Paypal_account");
                custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                        + ",paymentMethod:" + subTrans.getPayPalDetails().getToken()
                        + ",payerId:" + subTrans.getPayPalDetails().getPayerId()
                        + ",paymentId:" + subTrans.getPayPalDetails().getPaymentId()
                        + ",payerEmail:" + subTrans.getPayPalDetails().getPayerEmail();
                System.out.println("Customer Pay details is: " + custPayDtls);
                break;
            case "apple_pay_card":
                custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                        + ",paymentMethod:" + subTrans.getApplePayDetails().getToken()
                        + ",paymentName:" + subTrans.getApplePayDetails().getPaymentInstrumentName()
                        + ",cardType:" + subTrans.getApplePayDetails().getCardType()
                        + ",cardLast4:" + subTrans.getApplePayDetails().getLast4()
                        + ",expMonth:" + subTrans.getApplePayDetails().getExpirationMonth()
                        + ",expYear:" + subTrans.getApplePayDetails().getExpirationMonth();
                break;
            case "venmo_account":
                custPayDtls = ",paymentType:" + subTrans.getPaymentInstrumentType()
                        + ",paymentMethod:" + subTrans.getVenmoAccountDetails().getToken()
                        + ",userId:" + subTrans.getVenmoAccountDetails().getVenmoUserId()
                        + ",userName:" + subTrans.getVenmoAccountDetails().getUsername();
                break;
            default:
                break;
        }
    } else if (!payTkn.equals("") || payTkn == "") {
        System.out.println("Inside Payment token is NOT null");
        System.out.println("Price is " + price);
        System.out.println("numBillCycles is " + numBillCycles);
        System.out.println("firstBillingCycle is " + firstBillingCycle);

        Double amount = Double.parseDouble(price);

        SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
        Date dateObj = curFormater.parse(firstBillingCycle);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateObj);

        SubscriptionRequest ovrSubsRequest = new SubscriptionRequest()
                .paymentMethodToken(payTkn)
                .planId(planId)
                .price(new BigDecimal(amount).setScale(2, 2))
                .numberOfBillingCycles(numBillCycles)
                .firstBillingDate(calendar);

        ovrSubsResult = gateway.subscription().create(ovrSubsRequest);
        custPayDtls = ",Using existing payment method";
        System.out.println("Subscription created with existing payment method");
    }

    if (ovrSubsResult.isSuccess()) {
        Subscription subscription = ovrSubsResult.getTarget();
        //return "redirect:subscriptions/" + subscription.getId();
        System.out.println(" Inside Subscription success status1");
        String transDetails = "";
        if (ovrSubsResult.getTarget().getTransactions().size() > 0) {
            transDetails = "transactionId:" + ovrSubsResult.getTarget().getTransactions().get(0).getId()
                    + ",transactionType:" + ovrSubsResult.getTarget().getTransactions().get(0).getType()
                    + ",transactionAmount:" + ovrSubsResult.getTarget().getTransactions().get(0).getAmount().toString()
                    + ",transactionStatus:" + ovrSubsResult.getTarget().getTransactions().get(0).getStatus().toString();
        } else {
            transDetails = "PENDING TRANSACTION";
        }

        return "subscriptionId:" + subscription.getId() + ",subscriptionStatus:" + subscription.getStatus().toString() + ",subscriptionBalance:" + subscription.getBalance() + "," + transDetails + "," + custPayDtls;
    } else {
        return ovrSubsResult.getMessage();
        //return ovrSubsResult.getTarget().getId() + "," +  ovrSubsResult.getTarget().getStatus().toString();
    }
}

@RequestMapping(value = "/newPaySub", method = RequestMethod.GET)
public String newSubscriptions(Model model) {
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);
    return "subscriptions/new";
}

@RequestMapping(value = "/newPaySub", method = RequestMethod.POST)
@ResponseBody
public String postNewPaySubsForm(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId,
        @RequestParam("payment_method_nonce") String nonce, Model model, final RedirectAttributes redirectAttributes) {

    return newSub(customerId, planId, "", nonce, model, redirectAttributes);
}

@RequestMapping(value = "/newSub")
@ResponseBody
public String postNewSubsForm(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId,
        @RequestParam("payTkn") String payTkn, Model model, final RedirectAttributes redirectAttributes) {

    return newSub(customerId, planId, payTkn, null, model, redirectAttributes);
}

@RequestMapping(value = "/updSubNewPayMtd")
 @ResponseBody
 public String postupdSubNewPayForm(@RequestParam("subsId") String subsId, @RequestParam("planId") String planId,
     @RequestParam("payTkn") String payTkn, Model model, final RedirectAttributes redirectAttributes) {
	 
	 try {
		 SubscriptionRequest request = new SubscriptionRequest()
				  .id(subsId)
				  .paymentMethodToken(payTkn)
				  .planId(planId);

				Result<Subscription> result = gateway.subscription().update(subsId,request);
				if (result.isSuccess())
					return "SubscriptionId: " + subsId +  " updated with new payment token: " + payTkn;
				else 
					return result.getMessage();
	 } catch (NotFoundException e) {
		 return "SubscriptionId: " + subsId + " or Payment method not found: " + payTkn;
	 }
 }
 
 @RequestMapping(value = "/crtPayMtd", method = RequestMethod.GET)
 public String crtPayMethod(Model model) {
     String clientToken = gateway.clientToken().generate();
     System.out.println("Client Token is: " + clientToken);
 model.addAttribute("clientToken", clientToken);

 return "checkouts/crtPayMtd";
     }

 // Create new payment method
 @RequestMapping(value = "/crtPayMtd", method = RequestMethod.POST)
 @ResponseBody
 public String postcrtPayMethodForm(@RequestParam("customerId") String customerId, @RequestParam("payment_method_nonce") String nonce) {

	 
	 //String newPayTkn = newPayMtd(customerId,nonce);

	 //CreditCard creditCard = gateway.creditCard().find(newPayTkn);
	 
 //String custId = findCustId(email);
 PaymentMethodRequest crtPayMethodRequest = new PaymentMethodRequest()
         .customerId(customerId)
         .paymentMethodNonce(nonce)
         .options()
         	.verifyCard(true)
         	.makeDefault(true)
         .done();
 
 Result<? extends PaymentMethod> crtPayMethodResult = gateway.paymentMethod().create(crtPayMethodRequest);

 String custPayToken = crtPayMethodResult.getTarget().getToken();
 System.out.println("Customer Payment token is" + custPayToken);
 
 PaymentMethod findPayMtd = gateway.paymentMethod().find(custPayToken);

 System.out.println("Payment Class type is" + findPayMtd.getClass());
 System.out.println("Payment Class simple type is" + findPayMtd.getClass().getSimpleName());
 
 String custPayDtls = "";
 switch (findPayMtd.getClass().getSimpleName()) {
 case "CreditCard":
	 CreditCard card = (CreditCard) findPayMtd;
     custPayDtls = "paymentType:" + findPayMtd.getClass().getSimpleName()
             + ",paymentMethod:" + custPayToken
             + ",cardType:" + card.getCardType()
             + ",cardLast4:" + card.getLast4()
             + ",expMonth:" + card.getExpirationMonth()
             + ",expYear:" + card.getExpirationYear();
     break;
 case "PayPalAccount":
     System.out.println("Inside Paypal_account");
     PayPalAccount paypal = (PayPalAccount) findPayMtd;
     custPayDtls = "paymentType:" + findPayMtd.getClass().getSimpleName()
             + ",paymentMethod:" + custPayToken
             + ",payerEmail:" + paypal.getEmail()
             + ",payerId:" + paypal.getPayerId();
     
     System.out.println("Customer Pay details is: " + custPayDtls);
     break;
 case "ApplePayCard":
	 ApplePayCard applePay = (ApplePayCard) findPayMtd;
     custPayDtls = "paymentType:" + findPayMtd.getClass().getSimpleName()
             + ",paymentMethod:" + custPayToken
             + ",paymentName:" + applePay.getPaymentInstrumentName()
             + ",cardType:" + applePay.getCardType()
             + ",cardLast4:" + applePay.getLast4()
             + ",expMonth:" + applePay.getExpirationMonth()
             + ",expYear:" + applePay.getExpirationMonth();
     break;
 case "AndroidPayCard":
	 AndroidPayCard andriodPay = (AndroidPayCard) findPayMtd;
     custPayDtls = "paymentType:" + findPayMtd.getClass().getSimpleName()
             + ",paymentMethod:" + custPayToken
             //+ ",paymentName:" + andriodPay.get
             + ",cardType:" + andriodPay.getCardType()
             + ",cardLast4:" + andriodPay.getLast4()
             + ",expMonth:" + andriodPay.getExpirationMonth()
             + ",expYear:" + andriodPay.getExpirationMonth();
     break;    
 case "VenmoAccount":
	 VenmoAccount venmoAct = (VenmoAccount) findPayMtd;
     custPayDtls = "paymentType:" + findPayMtd.getClass().getSimpleName()
             + ",paymentMethod:" + custPayToken
             + ",userId:" + venmoAct.getVenmoUserId()
             + ",userName:" + venmoAct.getUsername();
     break;
 default:
     break;
}
 

 if (crtPayMethodResult.isSuccess()) {
     return custPayDtls;
 } else {
     return crtPayMethodResult.getMessage() + " CreditCard save to Braintree vault failed";
     }

 }

 @RequestMapping(value = "/findPayMtdSubs")
 @ResponseBody
 public String postFindPayMtdForm(@RequestParam("payTkn") String payTkn) {
	 String custSubs = "";
	 try {
		 PaymentMethod payM = gateway.paymentMethod().find(payTkn);
		 for (int x = 0; x < payM.getSubscriptions().size(); x++) {
		     System.out.println("Subs status " + payM.getSubscriptions().get(x).getStatus());
		     if (! payM.getSubscriptions().get(x).getStatus().toString().equals("Canceled") ) 
		    	 	if (payM.getSubscriptions().size()-1 == x)
		    	 		custSubs += "SubscriptionId:" + payM.getSubscriptions().get(x).getId();
		    	 	else 
		    	 		custSubs += "SubscriptionId:" + payM.getSubscriptions().get(x).getId() + ",";
		     		System.out.println("Subs Id for cusotmer is " + payM.getSubscriptions().get(x).getId());
		     }
		 if (custSubs.equals("")) 
		 		custSubs = "No active subscriptions found for this payment method: " + payTkn;
		 return custSubs;
	 } catch (NotFoundException e)
	 {
		 return "Payment method not found: " + payTkn;
	 }
 }
 
 @RequestMapping(value = "/deletePayMtd")
 @ResponseBody
 public String postdeletePayMtdForm(@RequestParam("payTkn") String payTkn) {
	 
	 try { 
		 	Result<? extends PaymentMethod> delPayMtdresult = gateway.paymentMethod().delete(payTkn); 
			 if (delPayMtdresult.isSuccess())
				 return "Payment method deleted: " + payTkn;
			 else 
				 return delPayMtdresult.getMessage();	 
		 }
	 catch (NotFoundException e) { 
		 	return "Payment method not found: " + payTkn; 
		 }
 }

@RequestMapping(value = "/cancelSubscriptions")
@ResponseBody
public String postDeleteSubsForm(@RequestParam("subsId") String subsId) {
    String subId;
    try {
        Subscription findSub = gateway.subscription().find(subsId);
        if (!"Canceled".equals(findSub.getStatus().toString())) {
            subId = findSub.getId();
            Result<Subscription> cancelResult = gateway.subscription().cancel(subId);
            System.out.println("Canceled subscription id: " + cancelResult.getTarget().getId());
        } else {
            return subsId + " : is already canceled";
        }
    } catch (NotFoundException e1) {
        System.out.print(e1.getMessage());
        return subsId + " : is not found";
    }
    /*		   try {
                   Result<Subscription> cancelResult = gateway.subscription().cancel(subsId);
                   System.out.println("Cancelled subscription id: " + cancelResult.getTarget().getId());
           } catch (NotFoundException e) {
                   System.out.print(e.getMessage());
                   return subsId + " : is NOT Found";
           }*/

    return subsId + " : is canceled";
}

@RequestMapping(value = "/findSubscriptions")
@ResponseBody
public String postFindSubsForm(@RequestParam("emailId") String emailId) {

    CustomerSearchRequest searchRequest = new CustomerSearchRequest().email().is(emailId);
    ResourceCollection<Customer> collection = gateway.customer().search(searchRequest);
    System.out.println("Cust Id output " + collection.getFirst().getId());
    Customer customer;
    try {
        customer = gateway.customer().find(collection.getFirst().getId());
        System.out.println("printing customer details");
        System.out.println("Cusotmer details " + customer.getPaymentMethods().listIterator().toString());

    } catch (NotFoundException nf) {
        System.out.print(nf.getMessage());
        return collection.getIds().toString() + " : is not found";
    }

    List<? extends PaymentMethod> getPayM = customer.getPaymentMethods();
    String custSubs = "";
    for (int i = 0; i < getPayM.size(); i++) {
        String custToken = getPayM.get(i).getToken();
        System.out.println("Token is " + getPayM.get(i).getToken());
        PaymentMethod payM = gateway.paymentMethod().find(custToken);
        for (int x = 0; x < payM.getSubscriptions().size(); x++) {
            System.out.println("Subs status " + payM.getSubscriptions().get(x).getStatus());
            custSubs += payM.getSubscriptions().get(x).getId() + ":" + payM.getSubscriptions().get(x).getStatus().toString() + ",\n";
            System.out.println("Subs Id for cusotmer is " + payM.getSubscriptions().get(x).getId());
        }
    }
    return custSubs;
}

public String findCustId(String email) {
    CustomerSearchRequest request = new CustomerSearchRequest().email().is(email);
    ResourceCollection<Customer> collection = gateway.customer().search(request);
    collection.getIds().toString();
    System.out.println("Cust Id output " + collection.getFirst().getId());
    if (!"".equals(collection.getFirst().getId())) {
        return collection.getFirst().getId();
    } else {
        return "Customer Not Found";
    }
}

public String findPayMethods(String custId) {
    Customer customer;
    try {
        customer = gateway.customer().find(custId);
        System.out.println("printing customer details");
        System.out.println("Cusotmer details " + customer.getPaymentMethods().listIterator().toString());

    } catch (NotFoundException nf) {
        System.out.print(nf.getMessage());
        return findCustId(custId) + " : is not found";
    }

    List<? extends PaymentMethod> getPayM = customer.getPaymentMethods();

    System.out.println("geting  customer token...");
    String custPayToken = getPayM.get(0).getToken();
    System.out.println("Customer token is" + custPayToken);


    /*CreditCard creditCard = gateway.creditCard().find(custPayToken);

        String creditCardDtls = ",cardType:" + creditCard.getCardType() + ",cardLast4Digits:" + creditCard.getLast4() + 
                        ",cardExpMonth:" + creditCard.getExpirationMonth() + ",cardExpYear:" + creditCard.getExpirationYear();

        System.out.println("Customer Credit Card details is" + creditCardDtls);

        for (int i=0; i < getPayM.size(); i++ )  {
                String custToken = getPayM.get(i).getToken();
                System.out.println("Token is "+ getPayM.get(i).getToken());
                custPayToken += getPayM.get(i).getToken() + ",";
                PaymentMethod payM = gateway.paymentMethod().find(custToken);
                for (int x=0; x < payM.getSubscriptions().size(); x++) {
                         System.out.println("Subs status "+payM.getSubscriptions().get(x).getStatus());
                         custSubs +=  payM.getSubscriptions().get(x).getId() +":" + payM.getSubscriptions().get(x).getStatus().toString() + ",\n";
                         System.out.println("Subs Id for cusotmer is "+payM.getSubscriptions().get(x).getId());
                }
        }*/
    return custPayToken;
}

public String newCustId(String email, String firstName, String lastName, String phone) {
    CustomerRequest newCust = new CustomerRequest()
            .firstName(firstName)
            .lastName(lastName)
            .email(email)
            .phone(phone);
    Result<Customer> custResult = gateway.customer().create(newCust);

    if (custResult.isSuccess()) {
        // true
        return custResult.getTarget().getId();
    } else {
        return custResult.getErrors().toString();
    }
}

private Status[] TRANSACTION_SUCCESS_STATUSES = new Status[]{
    Transaction.Status.AUTHORIZED,
    Transaction.Status.AUTHORIZING,
    Transaction.Status.SETTLED,
    Transaction.Status.SETTLEMENT_CONFIRMED,
    Transaction.Status.SETTLEMENT_PENDING,
    Transaction.Status.SETTLING,
    Transaction.Status.SUBMITTED_FOR_SETTLEMENT
};

// Checkouts - GET client token
@RequestMapping(value = "/checkouts", method = RequestMethod.GET)
public String checkout(Model model) {
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);
    return "checkouts/new";
}

@RequestMapping(value = "/webcheckout", method = RequestMethod.GET)
public String webcheckout(HttpServletRequest request, ModelMap model, @RequestParam(defaultValue = "0") String type, 
        @RequestParam(defaultValue = "online") String payMode, 
        @RequestParam(defaultValue = "0") double price) {    
    Cart cart = (Cart) request.getSession().getAttribute("cart");
    AnonymousDTO user = cart.getAnonymous();
    if(cart != null){
        double cartPrice = cart.getPrice();
        if(cartPrice > 0) 
            price = cartPrice;
    }    
    User regUser = (User)CommonOperations.getUser(request);
    if(regUser == null) {
        regUser = new User();
        regUser.setFirstName(user.getName().split(" ", 0)[0]);
        regUser.setLastName(user.getName().split(" ", 0)[1]);
        regUser.setPhone(user.getPhone());
        regUser.setEmail(user.getEmail());
    }
    System.out.println("type = " + type + ", payMode= " + payMode + ", price=" + price);
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);
    model.addAttribute("user", regUser);
    model.addAttribute("price", price);
    model.addAttribute("purpose", cart.getDonationTypeText()?null:cart.getAnonymous().getPurposeFor());
//    return "braintree/payment";
    return CommonOperations.page("braintree/payment", model, 1, "braintree/payment");
}

 @RequestMapping(value = "/registrationPayment", method = RequestMethod.POST)
    public String registrationPayment(//@RequestParam("centerId") String centerId, 
            @RequestParam("firstName") String firstName,
            @RequestParam("lastName") String lastName, //@RequestParam("studentNames") String studentNames,
            @RequestParam("email") String email, 
            @RequestParam("phone") String phone, @RequestParam("amount") String amount, 
            @RequestParam("purpose") String purposeFor,
            @RequestParam("currency") String currency,
            @RequestParam("onetime") String onetime, @RequestParam(required = false) String frequency, 
            @RequestParam(required = false) String duration, @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String nbrOfPayments, @RequestParam("planId") String planId,
            @RequestParam("payment_method_nonce") String nonce, Model model,HttpServletRequest httpRequest, ModelMap map, final RedirectAttributes redirectAttributes) {
            
//         if (!accountManager.verifyReCaptcha(httpRequest.getParameter("g-recaptcha-response"))) {
//            map.addAttribute("error", "Invalid captcha");
//            ServiceResponse sResponse = new ServiceResponse();
//            //sResponse.setResponse(Response.FAILURE);
//            //sResponse.setMessage("reCaptcha check failed....Please try again!");
//            //map.addAttribute("centerList", centerManager.getCenterList(null, false));
//            //map.addAttribute("sitekey", Constants.SITE_KEY);
//            return "redirect:donate";
//          }
        String custId = "";
        Boolean error = false;
        String errorMessage;
        BigDecimal decimalAmount;
        Boolean custExists;
        String tranMsg = null;
        String paymentToken;
        planId = frequency;
        if("".equals(nbrOfPayments)) {
            nbrOfPayments = "0";
        }
        try {
            decimalAmount = new BigDecimal(amount);
        } catch (NumberFormatException e) {
            error = true;
            errorMessage = "amount invalid format";
            redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Amount is an invalid format.");
            return "redirect:donate";
        }
        
        CustomerSearchRequest request = new CustomerSearchRequest()
                .email().is(email);
        ResourceCollection<Customer> collection = gateway.customer().search(request);

        System.out.println("Customer Id is: " + collection.getIds().toString());
    
         if (collection.getIds().toString().equals("") || "[]".equals(collection.getIds().toString())) {
            CustomerRequest newCust = new CustomerRequest()
                    .firstName(firstName)
                    .lastName(lastName)
                    .email(email)
                    .phone(phone);
            Result<Customer> custResult = gateway.customer().create(newCust);

            if (custResult.isSuccess()) {
                custId = custResult.getTarget().getId();
            } else {
                error = true;
                errorMessage = custResult.getErrors().toString();
            }
        } else {
             custId = collection.getIds().get(0);
         }
        
        System.out.println("Customer Id is: " + custId);
        String transId = "";
        if(!"".equals(custId) && "onetime".equals(onetime)) {
            tranMsg = postNewCustTransForm(amount, custId, nonce, model, redirectAttributes, currency);
            transId = (tranMsg.split(",")[7]);
        } else if("recurring".equals(onetime)) {
//            tranMsg = newSub(custId, planId, "", nonce, model, redirectAttributes);

        try {
            tranMsg = postupdSubsForm(custId, planId, nonce, amount, Integer.parseInt(nbrOfPayments), startDate, model, redirectAttributes);
            transId = "Subscription ID: " + tranMsg.split(",")[0];
            
            User regUser = (User)CommonOperations.getUser(httpRequest);
//            SubscriptionDTO subscriptionDto = new SubscriptionDTO();
//            subscriptionDto.set
//            subscriptionManager.saveSubscription(subscriptionDto, regUser.getId());
//            tranMsg = overrideSub(custId, planId, "", nonce, amount, Integer.parseInt(nbrOfPayments), startDate, model, redirectAttributes);
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
                    
            if(tranMsg == null || tranMsg.startsWith("F")) {
                error = true;
                errorMessage = tranMsg;
            }
        
 System.out.println("tranMsg: " + tranMsg);
        if (!error) {
            AnonymousDTO anonymous = new AnonymousDTO();
            anonymous.setAmount(Double.parseDouble(amount));
            anonymous.setEmail(email);
            anonymous.setName(firstName + ", " + lastName);
            anonymous.setPhone(phone);
            anonymous.setPurposeFor(purposeFor);
            anonymous.setSendUpdates(false);
            paymentManager.saveAnonymousDetails(anonymous, "online", tranMsg, null, null, null);
            
            model.addAttribute("transId", transId);
            
            Mail.sendPaymentSuccessMail(firstName + ", " + lastName, email, amount, purposeFor, transId);
            return CommonOperations.page("braintree/success", map, 1, "braintree/success");
        } else {
            Mail.sendPaymentFailedMail(firstName + ", " + lastName, email, amount, purposeFor, transId);
            return CommonOperations.page("braintree/failure", map, 1, "braintree/failure");
        }

    }

// TRANSACTIONS - checkouts - to be decommissioned
@RequestMapping(value = "/checkouts", method = RequestMethod.POST)
public String postForm(@RequestParam("amount") String amount, @RequestParam("payment_method_nonce") String nonce, Model model, final RedirectAttributes redirectAttributes) {
    BigDecimal decimalAmount;
    try {
        decimalAmount = new BigDecimal(amount);
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Amount is an invalid format.");
        return "redirect:checkouts";
    }

    TransactionRequest request = new TransactionRequest()
            .amount(decimalAmount)
            //.paymentMethodToken(payResult.getTarget().getToken())
            .paymentMethodNonce(nonce)
            .options()
            .submitForSettlement(true)
            .done();

    Result<Transaction> result = gateway.transaction().sale(request);

    if (result.isSuccess()) {
        Transaction transaction = result.getTarget();
        System.out.println("Transaction is = " + transaction.getId());
        return "redirect:checkouts/" + transaction.getId();
    } else if (result.getTransaction() != null) {
        Transaction transaction = result.getTransaction();
        return "redirect:checkouts/" + transaction.getId();
    } else {
        return result.getMessage();
    }
}

//TRANSACTIONS checkouts result
@RequestMapping(value = "/checkouts/{transactionId}")
public String getTransaction(@PathVariable String transactionId, Model model) {
    Transaction transaction;
    CreditCard creditCard;
    Customer customer;

    try {
        transaction = gateway.transaction().find(transactionId);
        creditCard = transaction.getCreditCard();
        customer = transaction.getCustomer();
    } catch (Exception e) {
        System.out.println("Exception: " + e);
        return "redirect:/checkouts";
    }

    model.addAttribute("isSuccess", Arrays.asList(TRANSACTION_SUCCESS_STATUSES).contains(transaction.getStatus()));
    model.addAttribute("transaction", transaction);
    model.addAttribute("creditCard", creditCard);
    model.addAttribute("customer", customer);

    return "checkouts/show";
}

@RequestMapping(value = "/subscriptions", method = RequestMethod.GET)
public String subscriptions(Model model) {
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);
    return "subscriptions/new";
}

@RequestMapping(value = "/subscriptions", method = RequestMethod.POST)
@ResponseBody
public String postSubsForm(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId, @RequestParam("payment_method_nonce") String nonce, Model model, final RedirectAttributes redirectAttributes) {
    Customer customer;
    //String custToken;
    try {
        customer = gateway.customer().find(customerId);
        System.out.println("Customer ID  is " + customer.getId());
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Customer Id  is invalid.");
        return "redirect:subscriptions";
    }

    //PaymentMethodRequest payRequest;
    Result<? extends PaymentMethod> payResult;
    //SubscriptionRequest subsRequest;
    //Result<Subscription> subsResult = null;

    PaymentMethodRequest payRequest = new PaymentMethodRequest()
            .customerId(customerId)
            .paymentMethodNonce(nonce);

    payResult = gateway.paymentMethod().create(payRequest);

    System.out.println("Token is = " + payResult.getTarget().getToken());

    SubscriptionRequest subsRequest = new SubscriptionRequest()
            .paymentMethodToken(payResult.getTarget().getToken())
            .planId(planId);

    Result<Subscription> subsResult = gateway.subscription().create(subsRequest);

    //String transDetails = subsResult.getTransaction().getId() + subsResult.getTransaction().getAmount() + subsResult.getTransaction().getStatus();
    System.out.println("Subscription created");
    //System.out.println("Subscription result is = " + subsResult.getTarget().getPlanId());

    if (subsResult.isSuccess()) {
        Subscription subscription = subsResult.getTarget();
        String transDetails = subsResult.getTarget().getTransactions().get(0).getId()
                + "," + subsResult.getTarget().getTransactions().get(0).getType()
                + "," + subsResult.getTarget().getTransactions().get(0).getAmount().toString()
                + "," + subsResult.getTarget().getTransactions().get(0).getStatus().toString();
        //return "redirect:subscriptions/" + subscription.getId();
        System.out.println("Subscription status =" + subsResult.getTarget().getStatus().toString());
        return subscription.getId() + "," + subscription.getStatus().toString() + "," + subscription.getBalance() + "\n" + transDetails;
    } else if (subsResult.getSubscription() != null) {
        Subscription subscription = subsResult.getSubscription();
        //return "redirect:subscriptions/" + subscription.getId();
        return subscription.getId() + "," + subscription.getStatus().toString() + "," + subscription.getBalance() + "\n";
    } else {
        return subsResult.getMessage();
    }
}

@RequestMapping(value = "/subscriptions/{subscriptionId}")
public String getSubscription(@PathVariable String subscriptionId, Model model) {
    Subscription subscription;

    try {
        subscription = gateway.subscription().find(subscriptionId);
    } catch (Exception e) {
        System.out.println("Exception: " + e);
        return "redirect:/subscriptions";
    }

    model.addAttribute("isSuccess", Arrays.asList(TRANSACTION_SUCCESS_STATUSES).contains(subscription.getStatus()));
    model.addAttribute("subscription", subscription);

    //return "subscriptions/show";
    return subscription.getStatus().toString();
}

@RequestMapping(value = "/updSubscriptions", method = RequestMethod.GET)
public String updSubscriptions(Model model) {
    String clientToken = gateway.clientToken().generate();
    System.out.println("Client Token is: " + clientToken);
    model.addAttribute("clientToken", clientToken);

    return "updSubscriptions/new";
}


public String postupdSubsFormNew(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId,
        @RequestParam("payment_method_nonce") String nonce, @RequestParam("price") String price, @RequestParam("numBillCycles") Integer numBillCycles,
        @RequestParam("firstBillingCycle") String firstBillingCycle, String duration, Model model, final RedirectAttributes redirectAttributes)
        throws ParseException, java.text.ParseException {
    Customer customer;
    //String custToken;
    try {
        customer = gateway.customer().find(customerId);
        System.out.println("Customer ID  is " + customer.getId());
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Customer Id  is invalid.");
        return "redirect:subscriptions";
    }

    //PaymentMethodRequest payRequest;
    Result<? extends PaymentMethod> ovrPayResult;
    //SubscriptionRequest subsRequest;
    //Result<Subscription> subsResult = null;

    PaymentMethodRequest payRequest = new PaymentMethodRequest()
            .customerId(customerId)
            .paymentMethodNonce(nonce);

    ovrPayResult = gateway.paymentMethod().create(payRequest);

    System.out.println("About to get Token...");

    System.out.println("Token is = " + ovrPayResult.getTarget().getToken());

    System.out.println("Price is " + price);
    System.out.println("numBillCycles is " + numBillCycles);
    System.out.println("firstBillingCycle is " + firstBillingCycle);

    Double amount = Double.parseDouble(price);

    SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
    Date dateObj = curFormater.parse(firstBillingCycle);
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(dateObj);
    SubscriptionRequest ovrSubsRequest = null;
    
    if("indefinite".equals(duration)) {
            ovrSubsRequest = new SubscriptionRequest()
            .paymentMethodToken(ovrPayResult.getTarget().getToken())
            .planId(planId)
            .price(new BigDecimal(amount).setScale(2, 2))
            .neverExpires(Boolean.TRUE)
            .firstBillingDate(calendar);
    } else {
            ovrSubsRequest = new SubscriptionRequest()
            .paymentMethodToken(ovrPayResult.getTarget().getToken())
            .planId(planId)
            .price(new BigDecimal(amount).setScale(2, 2))
            .numberOfBillingCycles(numBillCycles)
            .firstBillingDate(calendar);
    }
    


    Result<Subscription> ovrSubsResult = gateway.subscription().create(ovrSubsRequest);

    System.out.println("Subscription created");

    if (ovrSubsResult.isSuccess()) {
        Subscription subscription = ovrSubsResult.getTarget();
        //return "redirect:subscriptions/" + subscription.getId();
        System.out.println(" Inside Subscription status success1");
        String transDetails = "";
        if (ovrSubsResult.getTarget().getTransactions().size() > 0) {
            transDetails = ovrSubsResult.getTarget().getTransactions().get(0).getId()
                    + "," + ovrSubsResult.getTarget().getTransactions().get(0).getType()
                    + "," + ovrSubsResult.getTarget().getTransactions().get(0).getAmount().toString()
                    + "," + ovrSubsResult.getTarget().getTransactions().get(0).getStatus().toString();
        } else {
            transDetails = "PENDING TRANSACTION";
        }

        return subscription.getId() + "," + subscription.getStatus().toString() + "," + subscription.getBalance() + "\n" + transDetails;
    } else if (ovrSubsResult.getSubscription() != null) {
        System.out.println(" Inside Subscription status not null");
        Subscription subscription = ovrSubsResult.getSubscription();
        //return "redirect:subscriptions/" + subscription.getId();
        return subscription.getId() + "," + subscription.getStatus().toString() + "," + subscription.getBalance().toString();
    } else {
        System.out.println(" Inside Subscription status error condition");
        String errorString = "";
        for (ValidationError error : ovrSubsResult.getErrors().getAllDeepValidationErrors()) {
            errorString += "Error: " + error.getCode() + ": " + error.getMessage() + "\n";
        }
        redirectAttributes.addFlashAttribute("errorDetails", errorString);
        //return "redirect:subscriptions";
        return errorString;
        //return ovrSubsResult.getTarget().getId() + "," +  ovrSubsResult.getTarget().getStatus().toString();
    }
}

@RequestMapping(value = "/updSubscriptions", method = RequestMethod.POST)
@ResponseBody
public String postupdSubsForm(@RequestParam("customerId") String customerId, @RequestParam("planId") String planId,
        @RequestParam("payment_method_nonce") String nonce, @RequestParam("price") String price, @RequestParam("numBillCycles") Integer numBillCycles,
        @RequestParam("firstBillingCycle") String firstBillingCycle, Model model, final RedirectAttributes redirectAttributes)
        throws ParseException, java.text.ParseException {
    Customer customer;
    //String custToken;
    try {
        customer = gateway.customer().find(customerId);
        System.out.println("Customer ID  is " + customer.getId());
    } catch (NumberFormatException e) {
        redirectAttributes.addFlashAttribute("errorDetails", "Error: 81503: Customer Id  is invalid.");
        return "redirect:subscriptions";
    }

    //PaymentMethodRequest payRequest;
    Result<? extends PaymentMethod> ovrPayResult;
    //SubscriptionRequest subsRequest;
    //Result<Subscription> subsResult = null;

    PaymentMethodRequest payRequest = new PaymentMethodRequest()
            .customerId(customerId)
            .paymentMethodNonce(nonce);

    ovrPayResult = gateway.paymentMethod().create(payRequest);

    System.out.println("About to get Token...");

    System.out.println("Token is = " + ovrPayResult.getTarget().getToken());

    System.out.println("Price is " + price);
    System.out.println("numBillCycles is " + numBillCycles);
    System.out.println("firstBillingCycle is " + firstBillingCycle);

    Double amount = Double.parseDouble(price);

    SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
    Date dateObj = curFormater.parse(firstBillingCycle);
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(dateObj);

    SubscriptionRequest ovrSubsRequest = new SubscriptionRequest()
            .paymentMethodToken(ovrPayResult.getTarget().getToken())
            .planId(planId)
            .price(new BigDecimal(amount).setScale(2, 2))
            .numberOfBillingCycles(numBillCycles)
            .firstBillingDate(calendar);

    Result<Subscription> ovrSubsResult = gateway.subscription().create(ovrSubsRequest);

    System.out.println("Subscription created");

    if (ovrSubsResult.isSuccess()) {
        Subscription subscription = ovrSubsResult.getTarget();
        //return "redirect:subscriptions/" + subscription.getId();
        System.out.println(" Inside Subscription status success1");
        String transDetails = "";
        if (ovrSubsResult.getTarget().getTransactions().size() > 0) {
            transDetails = ovrSubsResult.getTarget().getTransactions().get(0).getId()
                    + "," + ovrSubsResult.getTarget().getTransactions().get(0).getType()
                    + "," + ovrSubsResult.getTarget().getTransactions().get(0).getAmount().toString()
                    + "," + ovrSubsResult.getTarget().getTransactions().get(0).getStatus().toString();
        } else {
            transDetails = "PENDING TRANSACTION";
        }

        return subscription.getId() + "," + subscription.getStatus().toString() + "," + subscription.getBalance() + "\n" + transDetails;
    } else if (ovrSubsResult.getSubscription() != null) {
        System.out.println(" Inside Subscription status not null");
        Subscription subscription = ovrSubsResult.getSubscription();
        //return "redirect:subscriptions/" + subscription.getId();
        return subscription.getId() + "," + subscription.getStatus().toString() + "," + subscription.getBalance().toString();
    } else {
        System.out.println(" Inside Subscription status error condition");
        String errorString = "";
        for (ValidationError error : ovrSubsResult.getErrors().getAllDeepValidationErrors()) {
            errorString += "Error: " + error.getCode() + ": " + error.getMessage() + "\n";
        }
        redirectAttributes.addFlashAttribute("errorDetails", errorString);
        //return "redirect:subscriptions";
        return errorString;
        //return ovrSubsResult.getTarget().getId() + "," +  ovrSubsResult.getTarget().getStatus().toString();
    }
}
    /*    // Update existing card billing address
@RequestMapping(value = "/updBillingAddress")
@ResponseBody
public String postUpdBillAdresForm(@RequestParam("payTkn") String payTkn, @RequestParam("streetAdres") String streetAdres,@RequestParam("locality") String locality,  
@RequestParam("region") String region, @RequestParam("postalCode") String postalCode) {

                    PaymentMethodRequest updAdresRequest = new PaymentMethodRequest()
                                                    .billingAddress()
                                                            .streetAddress(streetAdres)
                                                            .locality(locality)
                                                            .region(region)
                                                            .postalCode(postalCode)
                                                    .done();

                    Result<? extends PaymentMethod> updBillResult = gateway.paymentMethod().update(payTkn, updAdresRequest);

                    if (updBillResult.isSuccess()) {
                            return "update successful";	
                    } else {
                            return updBillResult.getMessage() + " update failed";	
                    }

}*/
}
