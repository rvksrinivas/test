function checkLogin(goToPage) {
    if (authenticated) {
        location.href = "/" + goToPage + ".html";
    } else {
        location.href = "/signin.html?returnURL=/" + goToPage + ".html";
    }
}

function resendMail(ele) {
    showMessage("Please wait, while sending the email.");
    $.post("/resend-activation-mail.html", {email: $(ele).data('email')}, function (data) {
        showMessage(data);
    });
}

$(function () {
    $("#age").keyup(function () {
        var val = $("#age").val();
        if (!$.isNumeric(val) || val.indexOf(".") !== -1) {

        } else {
            if (parseInt(val) < 21) {

            }
        }
    });
});

 function isValidDate(s) {
       var bits = s.split('/');
       var d = new Date(bits[2], bits[0] - 1, bits[1]);
       return d && (d.getMonth() + 1) == bits[0] && d.getDate() == Number(bits[1]);
 }
    
    
    $(function () {
    $("#onetime").click(function () {
        var val = $("#age").val();
        if (!$.isNumeric(val) || val.indexOf(".") !== -1) {

        } else {
            if (parseInt(val) < 21) {

            }
        }
    });
});

$('input:radio[name="onetime"]').click(function(){
    if($(this).val() == 'recurring'){
       $("#recurringdetails").show();
//         $("input[type=radio][name=frequency]").attr('disabled', false);
//            $("input[type=radio][name=duration]").attr('disabled', false);
//            $("#nbrOfPayments").attr('readonly', false);
//            $("#startdate").attr('readonly', false);  
    }else{
        $("#recurringdetails").hide();
//         $("input[type=radio][name=frequency]").attr('disabled', 'disabled');
//            $("input[type=radio][name=duration]").attr('disabled', 'disabled');
//            $("#nbrOfPayments").attr('readonly', true);
//            $("#startdate").attr('readonly', true);   
    }
    
});
$('input:radio[name="duration"]').click(function(){
    if($(this).val() == 'duration'){
         $("#nbrOfPayments").attr('readonly', false);
    } else {
        $("#nbrOfPayments").attr('readonly', true);
    } 
    
});
    
function validatePaymentInfo() {
    if (validate("fname", "First Name") &&
            validate('lname', 'Last Name') &&
            validateEmail('email', 'Email') &&
            validateAmount('amount', 'Amount') && validateSelect('purpose', 'PurposeFor')) {
       // var flag = validateSelect('center', 'Center');
        //if (!flag)
          //  return false;
//           var $captcha = $('#recaptcha'),
//                    response = grecaptcha.getResponse();
//
//            if (response.length === 0) {
//                showMessage("Please check reCaptcha.");
//                return false;
//            }
        if($('input[type=radio][name=onetime]:checked').attr('value') == "recurring") {
            
            if($("#monthly").is(":checked") || $("#quartely").is(":checked") || $("#halfannually").is(":checked") || $("#anually").is(":checked")) {
                   if($("#indefinite").is(":checked") || $("#duration").is(":checked")) {
                       
                   } else {
                        showMessage("Please select duration");
                        return false;
                    }
            } else {
                showMessage("Please select interval");
                return false;
            }
            if($("#duration").is(":checked")) {
                validatePositiveNumber("nbrOfPayments", "nbrOfPayments");
                if($("#nbrOfPayments").val() == "" || $("#nbrOfPayments").val() == 0) {
                        showMessage("Please enter the number of payments");
                        return false;
                }   
            }
            
            startDate = $("#startdate").val();
            var dateMMDDYYYRegex = "^[0-9]{2}/[0-9]{2}/[0-9]{4}$";
            if(startDate.match(dateMMDDYYYRegex) && isValidDate(startDate)){
            
            }else{
                showMessage("Please enter the correct date format mm/dd/yyyy");
                return false;
            }
  
        } 
        if ($("#a").is(":checked")) {
//            if ($("#liabilityForm").is(":checked")) {
//                if(validate("initials", "First Name")) 
                    $("#paymentBtn").attr('disabled', 'disabled');
                    $(".loading").show();
                    return true;
//            } else {
//                showMessage("Please read and accept liability form");
//                return false;
//            }
        } else {
            showMessage("Please accept terms & conditions");
            return false;
        }
    }
    return false;
}

function validateSignupForm() {
    if (validate("fname", "First Name") &&
            validate('lname', 'Last Name') &&
            validateEmail('email', 'Email') &&
            validate('phone', 'Mobile')) {
        var flag = validate('pass1', 'Password', 5, 20) && validateMatch('pass1', 'pass2') && validate('city', 'City') &&
                validate('state', 'State') &&
                validateSelect('country', 'Country') && validateSelect('center', 'Center');
        if (!flag)
            return false;
        if ($("#a").is(":checked")) {
            var $captcha = $('#recaptcha'),
                    response = grecaptcha.getResponse();

            if (response.length === 0) {
                showMessage("Please check reCaptcha.");
                return false;
            } else {
                return  true;
            }
        } else {
            showMessage("Please accept terms & conditions");
        }
    }
    return false;
}
function uploadPhoto() {
    var data = new FormData();
    var inputEle = document.getElementById("profileImage");
    data.append('inputfile', inputEle.files[0]);
    $(".loading").show();
    var type = $("#profileImage").data('type');
    $.ajax({
        url: '/profile-image.save?type='+(type === "signup" ? 1 : 0),
        data: data,
        processData: false,
        type: 'POST',
        contentType: false,
        success: function (data) {
            if (data && data.message !== "") {
                if (data.message.indexOf("successfully") !== -1) {
                    $("#profileImageImg").attr("src", data.result.profileImage);
                    $("#profilePic").val(data.result.profileImage);
                } else {
                    showMessage(data.message);
                }
            }
            $(".loading").hide();
        },
        error: function (err) {
            alert(err);
            $(".loading").hide();
        }
    });
}


$(function () {

    $("#profileImage").change(function () {
        uploadPhoto();
    });

    $(".sign_in_fild input").each(function (i) {
        if ($(this).val().trim() !== "")
            $(this).parent(".sign_in_fild").find('label').addClass('test');
    });
    $(".sign_in_fild input").on('focus', function () {
        $(this).parent(".sign_in_fild").find('label').addClass('test');
    });
    $(".sign_in_fild input").on('blur', function () {
        if ($(this).val().trim() === "")
            $(this).parent(".sign_in_fild").find('label').removeClass('test');
    });
    $('#donationTab li a').click(function () {
        $('.active').removeClass('active');
        $(this).addClass("active");
    });
    $("#otherAmt").focus(function () {
        $('.active').removeClass('active');
    });
    $(".becom_s_life a").click(function () {
        $('.active').removeClass('active');
        $(this).addClass("active");
    });
    $(".bowl").click(function () {
        $("#audioDiv").empty();
        $('.active').removeClass('active');
        $(this).addClass("active");
        $("#1, #2, #3").hide();
        $("#" + $(this).data('id')).fadeIn(300);
        $(".tryhealing_cnt_box").hide();
        $(".tryhealing_cnt_box[data-id=" + $(this).data('id') + "]").show();
    });
    $("#2, #3").click(function () {
        $("#audio").prop("src", "");
    });
});
var loading = false, pageFlag = true;
$(document).ready(function () {
    if (viewPage === "myaccount") {
        $(".member_btns a").click(function () {
            if ($(this).data("id") === "payment")
                $(this).parent().parent().next().next().toggleClass("member_more_a");
            else if ($(this).data("id") === "upgrade") {
                $(".upgrade_pop").slideDown(200);
                $(".main_mask").fadeIn(200);
            } else if ($(this).data("id") === "cancel") {
                $("#cancelMembership").data("type", $(this).data("type"));
                $(".delete_pop").slideDown(200);
                $(".main_mask").fadeIn(200);
            }
        });
        $(".nocolo").click(function () {
            closeMemberPopup();
        });
        $(".editMembership").click(function () {
            $(".member_inner_left").find("i[id='" + $(this).data("id") + "_div']").hide();
            $(".member_inner_left").find("i[id='edit_" + $(this).data("id") + "_div']").show();
        });
        $(".close_edit_membership").click(function () {
            $(".member_inner_left").find("i[id='" + $(this).data("id") + "_div']").show();
            $(".member_inner_left").find("i[id='edit_" + $(this).data("id") + "_div']").hide();
        });
        $("#cancelMembership").click(function () {
            $(".loading").show();
            jQuery.post("/cancelMembership.save", {membershipType: $(this).data("type")}, function (data) {
                if (data.indexOf("successfully") !== -1) {
                    closeMemberPopup();
                    window.setTimeout("location.href = '/my-account.html';", 2000);
                }
                showMessage(data);
                $(".loading").hide();
            });
        });
    }
    if (viewPage === 'become-a-member') {
        if (memberType === 'PATRON') {
            $("#patronMembership").off("click").addClass("no_click").attr("title", "You are already a Patron Member");
            $("#dollarADayMembership").off("click").addClass("no_click").attr("title", "You are already a Patron Member");
            $("#continueDiv").hide();
        } else if (memberType === 'DOLLAR_A_DAY') {
            $("#dollarADayMembership").off("click").addClass("no_click").attr("title", "You are already a Dollar-a-Day Member");
        }
    }
    if (viewPage === "experiences") {
        $(window).scroll(function () {
            if (!loading && ($(window).scrollTop() > $(document).height() - $(window).height() - 10) && pageFlag) {
                loading = true;
                getExperienceList();
            }
        });
        $(".exp_content").each(function () {
            if ($(this).height() < 137) {
                $(this).parent().find(".show").hide();
            } else {
                $(this).parent().find(".show").show();
            }
        });

    }
    var images = [];
    if (viewPage === "articlereports" || viewPage === "news") {
        $("#prev").click(function () {
            $(".loading").show();
            var no = $("#next").data("no");
            if (no > 0) {
                no = no - 1;
                $("#next").data("no", no);
                $("#blogImage").attr("src", "/ys-static/articleImages/" + imgList[no]);
                check();
            }
            $("#blogImage").on('load', function () {
                $(".loading").hide();
            });
        });
        $("#next").click(function () {
            $(".loading").show();
            var no = $("#next").data("no");
            if (no < imgList.length - 2) {
                no = no + 1;
                $("#blogImage").attr("src", "/ys-static/articleImages/" + imgList[no]);
                $("#next").data("no", no);
                check();
            }
            $("#blogImage").on('load', function () {
                $(".loading").hide();
            });
        });
    }
});
$(document).ready(function () {
    $(".forg_text").click(function () {
        $("#forgotEmail").val("");
        $(".forgot_pasword").show();
    });
    $(".forgot_close").click(function () {
        $(".forgot_pasword").hide();
    });
    $("#submitForgot").click(function () {
        if (validateEmail("forgotEmail", "email")) {
            var type = $("#forgotEmail").data("type");
            jQuery.post((type === 0 ? "/admin/account/" : "/doctor/") + "forgotPassword.save", {email: $("#forgotEmail").val()}, function (data) {
                if (data && data !== "") {
                    showMessage(data);
                    $(".forgot_pasword").hide();
                }
            });
        }
    });
});
function check() {
    if ($("#next").data("no") < imgList.length - 2)
        $("#next").show();
    else
        $("#next").hide();
    if ($("#next").data("no") > 0)
        $("#prev").show();
    else
        $("#prev").hide();
}
function checkExperienceText() {
    $(".exp_content").each(function () {
        if ($(this).height() < 137) {
            $(this).parent().find(".showMoreExp").hide();
        } else {
            $(this).parent().find(".showMoreExp").show();
        }
    });
    applyClick();
}
function applyClick() {
    $(".showMoreExp").off("click").click(function () {
        $(this).parent().find("div[data-name='expContent']").toggleClass("expand");
        $(this).html($(this).html() === "show more..." ? "show less..." : "show more...");
    });
}
function forgetPassword() {
    if (validateEmail("fEmail")) {
        jQuery.post("/forgot-password.save", {email: $("#fEmail").val()}, function (data) {
            if (data && data.message.indexOf("successfully") !== -1) {
                showMessage("New Password was sent to your mail, Please login with the password provided.");
            } else
                showMessage(data.message);
            $(".mask").removeClass("mask_a");
            $(".register1").slideUp(300);
        });
    }
}
function getExperienceList() {
    $(".loading").show();
    jQuery.post("/experience-list.json", {pageNo: currentPage}, function (data) {
        if (data && data !== "") {
            var exp = data.experienceList;
            if (exp.length > 0) {
                var text = "";
                for (var e in exp) {
                    text += "<div class='exper_in'>";
                    text += "<div class='clear'></div>";
                    text += "<div class='exper_box'>";
                    text += "<span>" + exp[e].title + "</span>";
                    text += "<div class='exp_content' data-name='expContent' data-id=" + exp[e].id + ">" + exp[e].message + "</div>";
                    if (exp[e].imageName !== null && exp[e].imagename !== "")
                        text += "<a href='javascript:void(0)' onclick='video(\"" + exp[e].imageName + "\")' style='float:left;'>Play Video</a>";
                    text += "<small class='showMoreExp'>show more...</small>";
                    text += "<div class='clear'></div>";
                    text += "</div>";
                    text += "</div>";
                }
                $("#experiences").append(text);
                $("#expPage").show();
                var paginator = data.paginator;
                var no = paginator.totalRows / paginator.pageSize;
                no = paginator.totalRows % paginator.pageSize > 0 ? no + 1 : no;
                $("#expPageMsg").html('Showing 1 - ' + ((paginator.currentPage + 1) * paginator.pageSize > paginator.totalRows ? paginator.totalRows : (paginator.currentPage + 1) * paginator.pageSize) + ' of ' + paginator.totalRows + " experiences");
//                var options = {
//                    currentPage: paginator.currentPage + 1,
//                    totalPages: no,
//                    alignment: 'right',
//                    size: 'small',
//                    useBootstrapTooltip: false,
//                    itemContainerClass: function (type, page, current) {
//                        return (page === current) ? "active" : "pointer-cursor";
//                    },
//                    pageUrl: function (type, page, current) {
//                        return "javascript:getExperienceList()";
//                    }
//                };
//                $("#birdPaginator").bootstrapPaginator(options);
                currentPage = paginator.currentPage + 1;
                pageFlag = paginator.totalRows - (paginator.pageSize * (paginator.currentPage + 1)) > 0;
                checkExperienceText();
            } else {
                $("#expPage").hide();
            }
        }
        loading = false;
        $(".loading").hide();
    });
}
function donateAnonymous(type) {
    var price = "";
    var amt = "";
    var amount = 0;
    var chkForUpdates;
    amt = $("#otherAmt").val();
    if (amt === null || amt === "") {
        price = $('ul.tabs').find('li').find('a.active').data('price');
        if (price !== null && price !== undefined) {
            amount = price;
        } else {
            showMessage("Select Amount");
            return;
        }
    } else {
        amount = amt;
    }
    if (validate("fName", "first name") &&
            validate("lName", "last name") &&
            validateEmail("email", "email") &&
            validatePhone("phone", "contact no")) {
        if ($("#chkUpdate").is(':checked')) {
            chkForUpdates = true;
        }
        jQuery.post("/saveAnonymousDetails.save", {name: $("#fName").val() + " " + $("#lName").val(),
            email: $("#email").val(), phone: $("#phone").val(), sendUpdates: chkForUpdates,
            amount: amount, type: type, purposeFor: $("#purpose").val()
        },
                function (data) {
                    location.href = data;
                });
    }
}
function donate(a) {
    var price = $('ul.tabs').length > 0 ? $('ul.tabs').find('li').find('a.active').data('price') : 0;
    if (a === 9) {
        if (price === null || price === undefined || price === 0) {
            showMessage("Select Amount");
            return;
        }
    }
    var mode = $('input[name=mode]:checked').val();
    var url;
    if (mode === "offline" || mode === "WEBSITE_OFFLINE") {
        $(".loading").show();
        url = "/payment.save";
        var variables = {"mode": mode, type: a, autoRenewal: $("#autoRenewal").is(":checked"), autoDebit: $("#autoDebit").is(":checked"), upgradeToPatron: upgradeToPatron};
        $.ajax({
            url: url,
            data: variables,
            type: 'POST',
            success: function (data, textStatus, jqXHR) {
                if (data === "" || data === "preview") {
                    showMessage("Request failed");
                } else {
                    location.replace(encodeURIComponent(data));
                }
            },
            error: function (err) {
                showMessage(err);
            }
        });
    } else if (mode === "online" || mode === "WEBSITE_ONLINE") {
        processPayment(payType, a, price);
    } else
        showMessage("please select payment mode");
}

function processPayment(mode, type, price) {
    $(".loading").show();

//    if (type === 7) {
//        $("#patronButton").submit();
//    } else if (type === 8) {
//        $("#dollarADayButton").submit();
    if (type === 7 || type === 8) {
        var url = "/payForMembership.save";
        var variables = {type: type, payMode: mode, price: price};
        $.ajax({
            url: url,
            data: variables,
            type: 'POST',
            success: function (data, textStatus, jqXHR) {
                if (data === "" || data === "preview") {
                    showMessage("Request failed");
                } else {
                    location.replace(data);
                }
            },
            error: function (err) {
                showMessage(err);
            }
        });
    } else if (type === 9) {
        var url = "/payForBirdsFeedMembership.save";
        var variables = {payMode: mode, price: price};
        $.ajax({
            url: url,
            data: variables,
            type: 'POST',
            success: function (data, textStatus, jqXHR) {
                if (data === "" || data === "preview") {
                    showMessage("Request failed");
                } else {
                    location.replace(data);
                }
            },
            error: function (err) {
                showMessage(err);
            }
        });
    } else {
//        var url = "/payForDonation.save";
//        var url = "/webcheckout?type=" + type + "&payMode=" + mode + "&price=" + price
        location.replace("/webcheckout?type=" + type + "&payMode=" + mode + "&price=" + price);
//        var variables = {type: type};
//        $.ajax({
//            url: url,
//            data: variables,
//            type: 'POST',
//            success: function (data, textStatus, jqXHR) {
//                if (data === "" || data === "preview") {
//                    showMessage("Request failed");
//                } else {
//                    location.replace(data);
//                }
//            },
//            error: function (err) {
//                showMessage(err);
//            }
//        });
    }
}
function payForDonation(amount) {

}
function changePass() {
    if (validate('oldPass', 'old password'))
        if (validate('newPass1', 'new password', 5, 20))
            if (validateMatch('newPass1', 'newPass2')) {
                var oldPassword = $("#oldPass").val();
                var password1 = $("#newPass1").val();
                jQuery.post("/changePassword.save", {oldPassword: oldPassword, password: password1}, function (data) {
                    showMessage(data.message.indexOf("successfully") !== -1 ? "Your password is updated" : data.message);
                    if (data.message.indexOf("successfully") !== -1) {
                        $("#oldPass").val('');
                        $("#newPass1").val('');
                        $("#newPass2").val('');
                        $(".close_edit").click();
                    }
                });
            }
}
function profile() {
    if (validate("fn", "First Name")
            && validate("ln", "Last Name")
            && validate("mobile", "Mobile Name")) {

          var birthMonth = parseInt($("#mbirthMonth").val());
          var birthDate = parseInt($("#mbirthDate").val());
//        var age = $("#age").val();
//        if (!$.isNumeric(age) || age.indexOf(".") !== -1) {
//            showMessage("Please Enter Valid Age");
//            return false;
//        } else {
//            if (parseInt(age) < 21) {
//                var flag = validate("motherName", 'Mother Name') && validate("fatherName", 'Father Name');
//                if (!flag)
//                    return false;
//            }
//        }
        var flag = validate('mcity', 'City') &&
                validate('mstate', 'State') &&
                validate('mcountry', 'Country') && 
                validateSelect('mcenter', 'Center');
        if (!flag)
            return false;

        jQuery.post("/changeProfile.save",
                {
                    firstName: $("#fn").val().trim(),
                    lastName: $("#ln").val().trim(),
                    phone: $("#mobile").val().trim(),
                    city: $("#mcity").val().trim(),
                    state: $("#mstate").val().trim(),
                    country: $("#mcountry").val(),
                    centerId: $("#mcenter").val(),
                    birthMonth: birthMonth,
                    birthDate: birthDate,
                    profession: $("#profession").val().trim(),
                    fatherName: $("#fatherName").val().trim(),
                    motherName: $("#motherName").val().trim()
                }, function (data) {

            if (data && data.message.indexOf("successfully") !== -1) {
                showMessage("Your profile information is updated");
                window.setTimeout('location.reload()', '2000');
            } else {
                showMessage(data.message);
            }
        });
    }
}
function validateCaptcha(id) {
    var why = "";

    if ($('#' + id).val() === "") {
        why += " Security code should not be empty.\n";
    }
    if ($('#' + id).val() !== "") {
        if (ValidCaptcha($('#' + id).val()) === false) {
            why += " Security code did not match.\n";
        }
    }
    if (why !== "") {
        showMessage(why);
        return false;
    }
    return true;
}
function ValidCaptcha() {
    var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
    var str2 = removeSpaces(document.getElementById('txtInput').value);
    if (str1 === str2) {
        return true;
    } else {
        return false;
    }
}
function removeSpaces(string) {
    return string.split(' ').join('');
}
function generateCaptcha() {
    var a = Math.ceil(Math.random() * 9) + '';
    var b = Math.ceil(Math.random() * 9) + '';
    var c = Math.ceil(Math.random() * 9) + '';
    var d = Math.ceil(Math.random() * 9) + '';
    var e = Math.ceil(Math.random() * 9) + '';

    var code = a + b + c + d + e;
    document.getElementById("txtCaptcha").value = code;
    document.getElementById("txtCaptchaDiv").innerHTML = code;
}
function closeMemberPopup() {
    $("#cancelMembership").removeData("type");
    $(".upgrade_pop").slideUp(200);
    $(".delete_pop").slideUp(200);
    $(".main_mask").fadeOut(200);
}
function setAuto(id, type) {
    $(".loading").show();
    jQuery.post("/setMembershipAuto.save", {id: id, type: type, status: type === 1 ? $("#autoRenewal_" + id).is(":checked") : $("#autoDebit_" + id).is(":checked")}, function (data) {
        if (data && data.indexOf("successfully") !== -1) {
            window.setTimeout("location.href = '/my-account.html';", 2000);
        }
        showMessage(data);
        $(".loading").hide();
    });
}
function getDonationsList() {
    $(".loading").show();
    jQuery.post("/site/donationList.json", {pageSize: 5, pageNo: currentPage, siteFlag: true}, function (data) {
        if (data && data !== null) {
            var don = data.result;
            if (don.length > 0) {
                var text = "";
                for (var d in don) {
                    text += "<div class='member_wrapper'>";
                    text += "<div class='member_inner_left'>";
                    text += "<div style='color: #0996DC;' class='payment_details'><span>Donated For</span>" + don[d].donationTypeText + "</div>";
                    text += "<div style='color: #2252a4;' class='payment_details'><span>Total Amount</span>$ " + don[d].amount + "</div>";
                    if (don[d].paymentList.length > 1)
                        text += "<h1 style='font-size: 16px;margin: 10px 0px 5px 0px;border-bottom: 1px solid;'>Payment Details</h1>";
                    var payments = don[d].paymentList;
                    var pCount = 0;
                    for (var p in payments) {
                        if (payments.length > 1) {
                            pCount++;
                            text += "<span class='paymentHead'>Payment " + pCount + "</span>";
                            text += "<div class='clear'></div>"
                        }
                        text += "<div class='payment_details'><span>Amount</span>" + payments[p].amount + "</div>";
                        text += "<div class='payment_details'><span>Payment Mode</span>" + payments[p].paymentModeText.toUpperCase() + "</div>";
                        text += "<div class='payment_details'><span>Reference No</span>" + (payments[p].referenceNo !== null && payments[p].referenceNo !== "" ? payments[p].referenceNo : 'NA') + "</div>";
                        text += "<div class='payment_details'><span>Status</span>" + payments[p].statusText + "</div>";
                        text += "<div class='payment_details'><span>Transaction Date</span>" + payments[p].transactionDate + "</div>";
                    }
                    text += "</div>";
                    text += "<div class='member_inner_right'>";
                    text += "<div>" + don[d].transactionDate + "</div>";
                    text += "</div>";
                    text += "<div style='clear:both;'></div>";
                    text += "</div>";
                    text += "<div style='clear:both;'></div>";
                }
                $("#donations").append(text);
                var paginator = data.paginator;
                var no = paginator.totalRows / paginator.pageSize;
                no = paginator.totalRows % paginator.pageSize > 0 ? no + 1 : no;
                $("#donationsPaginator").html('Showing 1 to ' + ((paginator.currentPage + 1) * paginator.pageSize > paginator.totalRows ? paginator.totalRows : (paginator.currentPage + 1) * paginator.pageSize) + ' of ' + paginator.totalRows + " donations");
                currentPage = paginator.currentPage + 1;
                if (paginator.totalRows - (paginator.pageSize * (paginator.currentPage + 1)) < 0) {
                    $(".order_more_btn").hide();
                }
            }
        }
        $(".loading").hide();
    });
}