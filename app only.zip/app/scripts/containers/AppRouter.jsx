import React from 'react';
import {Router, IndexRoute, Route} from 'react-router';
import Layout from 'components/Layout';
import Engagements from 'pages/Engagements';
import NewExam from 'pages/NewExam';

const AppRouter = ({history}) => (
  <Router history={history}>
    <Route path="/" component={Layout}>
      <IndexRoute component={Engagements} />
      <Route path="new_exam" component={NewExam} />
    </Route>
  </Router>
);

export default AppRouter;
