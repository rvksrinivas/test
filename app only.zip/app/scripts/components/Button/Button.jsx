import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Button.css';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['hover', 'type', 'active'];

const Button = props => {
  const classes = modsClasses(MODS, props, styles);
  return (
    <button className={classes} styleName="root" style={{width: props.width, display: props.display, paddingLeft: props.paddingLeft}} onClick={props.onClick} >
      {props.children}
    </button>
  );
};

Button.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Button, styles);
