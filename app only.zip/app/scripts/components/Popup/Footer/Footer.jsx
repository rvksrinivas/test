import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import {connect} from 'react-redux';
import styles from './Footer.css';
import {toggleModal, setCardState} from 'actions';
import {forEach} from 'lodash';

import Button from 'components/Button';
import BreadCrumbs from 'components/BreadCrumbs';
import Warning from 'components/Warning';

@CSSModules(styles)
class Footer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      opened: false,
      warn: false,
    };
    this.onAddClick = this.onAddClick.bind(this);
    this.locationShow = this.locationShow.bind(this);
    this.onWarningClose = this.onWarningClose.bind(this);
  }

  locationShow() {
    const {item} = this.props;
    if (item && item.card === 'legalFilled') {
      this.props.onAddInfo('legalFilled');
      this.props.onAddInfo('legalNoPriorize');
      this.props.onCloseModal();
    } else {
      const {opened} = this.state;
      this.setState({opened: !opened});
    }
  }

  onAddClick(card) {
    const {item} = this.props;
    if (item && item.checker) {
      this.setState({warn: true, opened: true});
      if (!this.hasWarn()) {
        this.props.onAddInfo(card);
        this.props.onCloseModal();
      }
    } else {
      if (item && item.card === 'legalFilled') {
        this.props.onRemoveInfo('legalNoPriorize');
      }
      this.props.onAddInfo(card);
      this.props.onCloseModal();
    }
  }

  hasWarn() {
    const {item} = this.props;
    let isWarn = false;
    if (item.breadCrums) {
      forEach(item.breadCrums, crum => {
        if (crum.length < 3) {
          isWarn = true;
        }
      });
    }
    return isWarn;
  }

  onWarningClose() {
    this.setState({warn: false});
  }

  componentWillMount() {
    const {item} = this.props;
    if (item && item.card === "legalFilled") {
      this.setState({opened: true});
    }
  }

  render() {
    const {item, onDeleteClick, titleStyle, text} = this.props;
    const {opened, warn} = this.state;
    let breadCrums = '';
    let style = '';
    let width = '';
    let title = '';
    let listTitle = '';
    let count = 0;
    if (item) {
      if (item.breadCrums) {
        breadCrums = item.breadCrums.map((crum, i) => {
          let showError = false;
          if (warn && crum.length < 3) {
            showError = true;
          }
          return <BreadCrumbs key={i} items={crum} onClick={item.onDeleteClick} type={item.crumsType} error={showError} />;
        });
        count = item.breadCrums.length;
      }
      style = item.titleStyle ? item.titleStyle : 'show-all';
      width = item.width ? item.width : '240px';
      title = item.title ? item.title : '';
      listTitle = item.listTitle ? item.listTitle : '';
    }
    const textButton = text ? text : 'Add';
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="controls">
          <div>
            <Button width="114px" type="cancel" onClick={() => {
              this.props.onCloseModal();
            }}>Cancel</Button>
          </div>
          <div>
            <Button width="114px" active={item ? count > 0 : true} onClick={() => {
              if (!item) {
                this.props.onCloseModal();
              }
              if (count < 1) {
                return;
              }
              if (item && item.card) {
                this.onAddClick(item.card);
              } else {
                this.props.onCloseModal();
              }
            }} >{textButton}</Button>
          </div>
        </div>
        <div styleName="show-all-wrap" style={{display: ((item && item.card !== 'metadaFilled' && count > 0) || (item && item.card === 'legalFilled')) ? 'block' : 'none'}}>
          <Button width={width} type={style} onClick={this.locationShow}>{title}</Button>
        </div>
        <div styleName="selected-locations" style={{display: (opened && count > 0) ? 'block' : 'none'}}>
          <Warning onClose={this.onWarningClose} warn={warn} />
          <header styleName="selected-header">
            <div styleName="selected-title">{listTitle}</div>
          </header>
          <main styleName="selected-main">
            {breadCrums}
          </main>
        </div>
      </div>
    );
  }
}

Footer.propTypes = {
  className: PropTypes.string,
};

const mapDispatchToProps = dispatch => ({
  onCloseModal() {
    dispatch(toggleModal());
  },
  onAddInfo(card) {
    dispatch(setCardState(card, true));
  },
  onRemoveInfo(card) {
    dispatch(setCardState(card, false));
  },
});

export default connect(null, mapDispatchToProps)(Footer);
