import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Checkbox.css';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['type', 'category', 'order', 'active', 'size', 'end'];

const getSize = props => {
  if (props.descr) {
    return props.text.length > 25 ? {height: '80px'} : {height: '60px'};
  }
  if ((props.category && props.text && !props.size) && ((props.complex && props.text.length > 31) || (!props.complex && props.text.length > 29))) {
    return {height: '69px', paddingTop: '15px'};
  }
};

const Checkbox = props => {
  const classes = modsClasses(MODS, props, styles);
  const text = (props.counter && props.active === "false") ? `${props.text} (${props.counter})` : props.text;
  const descr = (props.descr) ? props.descr : '';
  const checked = props.checked ? 'checked' : 'not-checked';
  return (
    <div className={classes} styleName="root" style={getSize(props)}>
      <input name={props.id} type="checkbox" id={props.id} styleName={checked} />
      <label htmlFor={props.id} styleName="label" value={props.value}
        onClick={() => {
          props.onClick(props.value);
        }
      }>
        <span styleName="icon"></span>
        <div style={{display: 'inline-block'}}>
          <span styleName="descr">
            {descr}
          </span>
          <span styleName="text" dangerouslySetInnerHTML={{__html: text}} style={{width: props.fullDescr || (props.complex && props.text.length < 29) ? "200px" : null}} >
          </span>
          {
            props.fullDescr &&
            <span styleName="fullDescr">
              {props.fullDescr}
            </span>
          }
        </div>
      </label>
      <div styleName="signs"></div>
    </div>
  );
};

Checkbox.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Checkbox, styles);
