import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Radio.css';

const Radio = props => {
  return (
    <div className={props.className} styleName="root">
    </div>
  );
};

Radio.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Radio, styles);
