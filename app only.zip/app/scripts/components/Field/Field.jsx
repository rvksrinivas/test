import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Field.css';
import SelectField from 'components/SelectField';
import Textarea from 'react-textarea-autosize';

const Field = props => {
  let item;
  if (props.type === 'toggle') {
    item = props.children;
  } else if (props.type === 'textarea') {
    item = <textarea styleName="textarea" placeholder={props.placeholder}
        style={{paddingLeft: props.paddingLeft, height: props.height, paddingTop: props.paddingTop, paddingBottom: props.paddingBottom}}
        type={props.type} onChange={e => {
          props.onChange(props.name ? props.name : 'scope', e.target.value, e);
        }}/>;
  } else if (props.type === 'textarea-autosize') {
    item = <Textarea styleName="textarea" placeholder={props.placeholder} minRows={props.minRow}
        style={{paddingLeft: props.paddingLeft, height: props.height, paddingTop: props.paddingTop, paddingBottom: props.paddingBottom}}
        type={props.type} onChange={e => {
          props.onChange(props.name ? props.name : 'scope', e.target.value, e);
        }}/>;
  } else if (props.type === 'select') {
    item = <SelectField placeholder="Select" options={props.options} type={props.color ? props.color : "frequence"} style={{borderColor: props.borderColor}} />;
  } else {
    item = <input styleName="input"
      placeholder={props.placeholder}
      style={{borderColor: props.borderColor, paddingLeft: props.paddingLeft}}
      type={props.type} onChange={e => {
        props.onChange('name', e.target.value);
      }}/>;
  }

  return (
    <div className={props.className} styleName="root">
      <div styleName="title" style={{fontSize: props.textSize}}>
        {props.title}
        {
          props.descr &&
          <span styleName="descr" style={{paddingRight: props.paddRight, paddingLeft: props.paddLeft}}>{props.descr}</span>
        }
      </div>
      {
        item
      }
    </div>
  );
};

Field.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Field, styles);
