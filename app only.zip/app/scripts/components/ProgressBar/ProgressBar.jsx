import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './ProgressBar.css';

const ProgressBar = props => {
  return (
    <div className={props.className} styleName="root" style={props.style}>
      <div styleName="title">Uploading 2 documents</div>
      <div styleName="percentage">27%</div>
      <div styleName="cancel">Cancel</div>
      <div styleName="bar">
        <div styleName="bar-progress"></div>
      </div>
    </div>
  );
};

ProgressBar.propTypes = {
  className: PropTypes.string,
};

export default cssModules(ProgressBar, styles);
