import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './ColumnItem.css';

import Checkbox from 'components/Checkbox';

const ColumnItem = props => {
  return (
    <div className={props.className} styleName="root">
      <Checkbox order={props.type} counter={props.counter}
        active={props.isActive} text={props.title}
        descr={props.descr} category="popup"
        onClick={props.onClick} value={props.value}
        fullDescr={props.fullDescr} complex={props.complex}
        id={props.id} type="square" end={props.end}
        checked={props.checked}
        />
    </div>
  );
};

ColumnItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(ColumnItem, styles);
