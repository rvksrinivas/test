import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Tooltip.css';

const Tooltip = props => {
  return (
    <div className={props.className} styleName="root" style={props.style}>
      <div styleName="more-info"></div>
      <div styleName="tooltip">
        <div styleName="title">
          {props.title}
        </div>
        <div styleName="descr">
          {props.descr}
        </div>
      </div>
    </div>
  );
};

Tooltip.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Tooltip, styles);
