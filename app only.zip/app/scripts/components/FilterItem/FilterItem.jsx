import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './FilterItem.css';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['category'];

const FilterItem = props => {
  const classes = modsClasses(MODS, props, styles);
  const hasSub = props.subtitles !== undefined && props.subtitles.length > 0;
  const isSub = hasSub ? 'isSub' : '';
  let list;
  if (hasSub) {
    list = props.subtitles.map((item, i) => {
      return (
        <div styleName="subtitle" key={i}>
          <input type={props.type} name={`subtitle-${props.name}${props.id}`} key={`${item}${i}`} id={`subtitle-${props.name}${i}`} defaultChecked /><label htmlFor={`subtitle-${props.name}${i}`} value={item} onClick={() => props.onSubtitleClick(item)}><span></span>{item}</label>
        </div>
      );
    });
  }
  const isChekedDefault = (props.id === 0 && props.type === 'radio');
  return (
    <div className={classes} styleName="root">
      <input type={props.type} name={props.name} id={`${props.name}${props.id}`} defaultChecked={isChekedDefault} />
      <label htmlFor={`${props.name}${props.id}`} value={props.value} onClick={() => props.onClick(props.value)} styleName={isSub}><span></span>{props.text}</label>
      <div styleName="subtitles">
        {
          list
        }
      </div>
    </div>
  );
};

FilterItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(FilterItem, styles);
