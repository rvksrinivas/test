import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './Header.css';

import roseLogo from 'images/svg/icons/rose-logo.svg';
import loupe from 'images/svg/icons/loupe.svg';
import bell from 'images/svg/icons/bell.svg';
import arrowImg from 'images/svg/icons/arrow.svg';

const Header = ({className}) => (
  <header className={className} styleName="header-layout">
    <img src={roseLogo} styleName="rose-logo" />
    <nav styleName="link-container">
      <div styleName="link" style={{width: "58px"}}>Home</div>
      <div styleName="link" style={{width: "100px"}} className={"active link"}>Engagements</div>
      <div styleName="link" style={{width: "104px"}}>Deliverables</div>
      <div styleName="link" style={{width: "46px"}}>Reports</div>
      <div styleName="link" style={{width: "104px"}}>Area of Focus</div>
      <div styleName="link" style={{width: "56px"}}>Meetings</div>
      <div styleName="link" style={{width: "83px"}}>Work List</div>
      <div styleName="link" style={{width: "58px"}}>Inventory</div>
    </nav>
    <div styleName="controls">
      <div styleName="loupe"><img src={loupe}/></div>
      <div styleName="bell"><img src={bell}/></div>
      <div styleName="profile">
        <span>Malika Waughn</span>
        <img src={arrowImg} styleName="arrow"/>
      </div>
    </div>
  </header>
);

export default CSSModules(Header, styles);
