import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import {connect} from 'react-redux';
import styles from './CardForm.css';
import Button from 'components/Button';
import CardHeader from 'components/Card/CardHeader';
import classnames from 'classnames';
import {setCardState} from 'actions';

@CSSModules(styles)
class CardForm extends Component {
  constructor() {
    super();
    this.state = {
      status: 'add',
      filled: false,
    };
    this.filled = false;
    this.statusChanged = this.statusChanged.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  onChange(filled) {
    this.filled = filled;
  }

  statusChanged() {
    const {name} = this.props;
    const status = this.state.status;
    const filled = this.filled;
    if (status === "add") {
      this.setState({status: "collapse"});
    } else if (status === "collapse") {
      this.setState({status: filled ? "edit" : "add"});
      if (filled && name) {
        this.props.onAddInfo(name);
      }
    } else if (status === "edit") {
      this.setState({status: "collapse"});
    }
  }

  render() {
    const classes = classnames(this.props.className, styles[`status-${this.state.status}`]);
    return (
      <div className={classes} styleName="root">
        <div styleName="header-wrap">
          <CardHeader action={this.state.status} title= {this.props.title} statusChanged={this.statusChanged} type={this.props.type} />
        </div>
        <main styleName="main">
          <div styleName="main-container">
            <this.props.children status={this.state.status} onChange={this.onChange} />
          </div>
        </main>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => ({
  onAddInfo(card) {
    dispatch(setCardState(card, true));
  },
});

CardForm.propTypes = {
  className: PropTypes.string,
};

export default connect(null, mapDispatchToProps)(CardForm);
