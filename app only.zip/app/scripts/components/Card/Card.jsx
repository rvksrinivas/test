import React, {PropTypes, Component} from 'react';
import {connect} from 'react-redux';
import CSSModules from 'react-css-modules';
import styles from './Card.css';
import Button from 'components/Button';
import modsClasses from 'utils/modsClasses.js';
import CardHeader from 'components/Card/CardHeader';
import {setModal, toggleModal} from 'actions';

const MODS = ['type'];

@CSSModules(styles)
class Card extends Component {
  constructor() {
    super();
    this.state = {
      status: 'add',
      showAll: true,
    };
    this.hasFooter = true;
    this.toogleFooter = this.toogleFooter.bind(this);
    this.statusChanged = this.statusChanged.bind(this);
    this.onCollapseClick = this.onCollapseClick.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    const {filledData, modal} = nextProps;
    const {status} = this.state;

    if (filledData.legalFilled) {
      this.hasFooter = !(filledData.legalNoPriorize);
    }
    if (filledData[modal] && status === 'add') {
      this.setState({status: 'edit'});
    }
  }

  statusChanged() {
    const status = this.state.status;
    if (status === "add" || status === "edit") {
      this.props.onSetExamName(this.props.name);
    }
  }

  onCollapseClick() {
    const showlAllNew = !this.state.showAll;
    this.setState({showAll: showlAllNew});
  }

  toogleFooter(val) {
    this.hasFooter = val;
  }

  render() {
    const classes = modsClasses(MODS, this.props, styles);
    const {type, title, defaultCount, count, category, filledData} = this.props;
    const {showAll, status} = this.state;
    const isEdit = (status === "edit" && this.hasFooter) ? 'block' : 'none';
    const moreText = count === "All" ? '' : ' more';
    return (
      <div className={classes} styleName="root">
        <CardHeader action={this.state.status} title= {title} statusChanged={this.statusChanged} type={type} />
        <main styleName="main">
          <div styleName="main-container">
            <this.props.children status={status} showAll={showAll} defaultCount={defaultCount} toogleFooter={this.toogleFooter} />
          </div>
        </main>
        <footer styleName="footer" style={{display: isEdit}}>
          <div styleName="collapseButton" onClick={this.onCollapseClick}>
            <div style={{display: showAll ? "block" : 'none'}}>Collapse</div>
            <div style={{display: showAll ? "none" : 'block'}}>See <span styleName="category-text">{count}{moreText} {category}</span></div>
          </div>
        </footer>
      </div>
    );
  }
}

Card.propTypes = {
  className: PropTypes.string,
};

const mapStateToProps = state => ({
  filledData: state.filledData,
});

const mapDispatchToProps = dispatch => ({
  onSetExamName(name) {
    dispatch(setModal(name));
    dispatch(toggleModal());
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(Card);
