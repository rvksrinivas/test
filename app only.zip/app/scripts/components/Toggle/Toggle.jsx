import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Toggle.css';
import classnames from 'classnames';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['type', 'category'];

class Toggle extends Component {
  constructor() {
    super();
    this.state = {
      activated: false,
    };
    this.onClick = this.onClick.bind(this);
  }

  onClick = val => {
    if (this.props.onClick) {
      this.props.onClick(val);
    }
    this.setState({activated: true});
  }

  componentWillMount() {
    const {activated} = this.props;
    if (activated && activated === "true") {
      this.setState({activated: true});
    }
  }

  render() {
    const category = this.props.category ? this.props.category : "";
    const styleType = modsClasses(MODS, this.props, styles);
    const {current} = this.props;
    const list = this.props.items.map(item => {
      const color = classnames(this.props.className, styles[`color-${item.color}`]);
      const isCurrent = (current && current === item.value);
      return (
        <div className={styleType} styleName="item" key={item.value}>
          <input styleName="input" type="radio" name={this.props.name} id={`${item.value}${category}`} defaultChecked={isCurrent}/>
          <label htmlFor={`${item.value}${category}`} className={color} value={item.value} style={{width: item.width}} onClick={() => {
            this.onClick(item.value);
          }} styleName={this.props.size}>{item.title}</label>
        </div>
      );
    });
    const classes = classnames(this.props.className, styles[`active-${this.state.activated}`]);
    return (
      <div className={classes} styleName="root">{list}</div>
    );
  }
}

Toggle.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Toggle, styles);
