export const SET_ENGAGMENTS_TYPE = 'SET_ENGAGMENTS_TYPE';
export const SET_ENGAGMENTS_CATEGORY = 'SET_ENGAGMENTS_CATEGORY';
export const UPDATE_ENGAGMENTS_PHASE = 'UPDATE_ENGAGMENTS_PHASE';
export const DELETE_ENGAGMENTS_PHASE = 'DELETE_ENGAGMENTS_PHASE';

export const SET_EXAM_NAME = 'SET_EXAM_NAME';

export const SET_MODAL = 'SET_MODAL';
export const TOGGLE_MODAL = 'TOGGLE_MODAL';

export const SET_CARD_STATE = 'SET_CARD_STATE';

export const ADD_EXAM = 'ADD_EXAM';

export const CLEAR_FILLED_DATA = 'CLEAR_FILLED_DATA';

export const setEngagmnetsType = type => ({
  type: SET_ENGAGMENTS_TYPE,
  payload: type,
});

export const setEngagmnetsCategory = category => ({
  type: SET_ENGAGMENTS_CATEGORY,
  payload: category,
});

export const updateEngagmnetsPhases = phase => ({
  type: UPDATE_ENGAGMENTS_PHASE,
  payload: phase,
});

export const deleteEngagmnetsPhases = phase => ({
  type: DELETE_ENGAGMENTS_PHASE,
  payload: phase,
});

export const setExamName = name => ({
  type: SET_EXAM_NAME,
  payload: name,
});

export const setModal = name => ({
  type: SET_MODAL,
  payload: name,
});

export const toggleModal = () => ({
  type: TOGGLE_MODAL,
});

export const setCardState = (card, state) => ({
  type: SET_CARD_STATE,
  payload: {card, state},
});

export const addExam = () => ({
  type: ADD_EXAM,
});

export const clearFilledData = () => ({
  type: CLEAR_FILLED_DATA,
});
