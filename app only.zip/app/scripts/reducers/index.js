import {combineReducers} from 'redux';
import {routerReducer} from 'react-router-redux';
import engagments, * as fromEngagments from './engagments';
import filledData from './filledData';
import modal from './modals/modal.js';

const rootReducer = combineReducers({
  routing: routerReducer,
  engagments,
  filledData,
  modal,
});

export default rootReducer;

export const getEngagmnetType = state =>
  fromEngagments.getType(state.engagments);
