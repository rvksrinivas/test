import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Exams.css';

import ExamItem from './ExamItem';
import classCreator from 'utils/classCreator';

import {exams} from 'stubs/exams.js';

const Exams = props => {
  const list = props.exams.map((el, i) => {
    return <ExamItem key={`exams${i}`} state={classCreator(el.state)} item={el} />;
  });
  return (
    <div className={props.className} styleName="root">
      {list}
    </div>
  );
};

Exams.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Exams, styles);
