import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './RangeItem.css';
import modsClasses from 'utils/modsClasses.js';

const MODS = ['type'];

const RangeItem = props => {
  const classes = modsClasses(MODS, props, styles);
  return (
    <div className={classes} styleName="root" style={{width: props.width, paddingLeft: props.paddingLeft}} onClick={props.onFilterClick} >
      {props.children}
    </div>
  );
};

RangeItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(RangeItem, styles);
