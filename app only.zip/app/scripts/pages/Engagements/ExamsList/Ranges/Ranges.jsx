import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Ranges.css';

import RangeItem from './RangeItem';

import examSort from 'images/svg/icons/exam-sort.svg';

const Ranges = props => {
  return (
    <div className={props.className} styleName="root">
      <RangeItem width="131px" paddingLeft="49px" type="filter"><span style={{paddingRight: "8px"}}>Type</span></RangeItem>
      <RangeItem width="120px" paddingLeft="17px" type="filter"><span style={{paddingRight: "7px"}}>ID</span></RangeItem>
      <RangeItem width="250px" paddingLeft="8px" type="filter"><span style={{paddingRight: "11px"}}>Engagement Name</span></RangeItem>
      <RangeItem width="141px" paddingLeft="18px" type="filter"><span style={{paddingRight: "10px"}}>Stage</span></RangeItem>
      <RangeItem width="178px" paddingLeft="17px" type="filter"><span style={{paddingRight: "14px"}}>Engagem. Manager</span></RangeItem>
      <RangeItem width="121px" paddingLeft="19px" type="filter"><span style={{paddingRight: "10px"}}>Last Updated</span></RangeItem>
      <RangeItem width="59px" paddingLeft="22px" onFilterClick={props.onFilterClick}><img src={examSort}/></RangeItem>
    </div>
  );
};

Ranges.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Ranges, styles);
