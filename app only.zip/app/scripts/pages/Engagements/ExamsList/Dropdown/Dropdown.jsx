import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Dropdown.css';
import Filter from 'components/Filter';

import closeBtn from 'images/svg/icons/close-popup.svg';

const filter = [
  {
    text: "Stage",
  },
  {
    text: "Start Date",
  },
  {
    text: "ID",
  },
  {
    text: "Exam Name",
  },
  {
    text: "Exam Manager Name",
  },
  {
    text: "Updated by",
  },
  {
    text: "Option available 1",
  },
  {
    text: "Option available 2",
  },
  {
    text: "Option available 3",
  },
  {
    text: "Option available 4",
  },
];

const Dropdown = props => {
  return (
    <div className={props.className} styleName="root" style={{display: props.state}} >
      <header styleName="header">
        <div styleName="title">Choose columns content</div>
        <div styleName="demand">6 maximum</div>
        <img src={closeBtn} styleName="closeButton" onClick={props.onCloseClick}/>
      </header>
      <Filter items={filter} type="checkbox" name="filter" category="exams" />
    </div>
  );
};

Dropdown.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Dropdown, styles);
