export const items = [
  {
    text: "All Engagements",
    value: 'all',
  },
  {
    text: "Exams",
    value: 'exams',
  },
  {
    text: "Non Exams",
    value: 'non-exams',
  },
];

export const categoties = [
  {
    text: "All Exams",
    value: 'all',
  },
  {
    text: "My Exams",
    value: 'my',
  },
  {
    text: "My Teams Exam",
    value: 'team',
  },
  {
    text: "My Favorites",
    value: 'favourite',
  },
];

export const phases = [
  {
    text: "In Progress",
    subtitles: ["Preparatory", "Active", "FieldWork", "Pending Planning", "Response Pending", "Post Closeout", "Suspended"],
    value: 'progress',
  },
  {
    text: "Planned",
    value: 'planned',
  },
  {
    text: "Closed",
    value: 'closed',
  },
];

export const filter = [
  {
    text: "Engagement Start",
  },
];
