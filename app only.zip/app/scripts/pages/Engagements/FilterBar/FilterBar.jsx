import React, {PropTypes, Component} from 'react';
import {connect} from 'react-redux';
import cssModules from 'react-css-modules';
import {setEngagmnetsType, setEngagmnetsCategory, updateEngagmnetsPhases} from 'actions';
import {engagments} from 'reducers';
import styles from './FilterBar.css';
import Filter from 'components/Filter';

import {items, categoties, phases, filter} from './filters.js';

class FilterBar extends Component {

  onPhaseChanged(value) {

  }

  render() {
    const {filters} = this.props;
    const isExams = (filters.type === 'exams') ? 'block' : 'none';
    return (
      <div className={this.props.className}>
        <Filter title="TYPE" checked={filters.type} onClick={this.props.onFilterTypeChanged} items={items} type="radio" name="type" paddingBottom="13px" />
        <Filter title="CATEGORY" onClick={this.props.onCategoryTypeChanged} items={categoties} type="radio" name="category" paddingBottom="3px" />
        <div style={{display: isExams}}>
          <Filter title="PHASE" onClick={this.onPhaseChanged} onSubtitleClick={this.props.onPhaseClicked} items={phases} type="checkbox" name="phase" paddingBottom="15px" />
        </div>
        <Filter title="FILTER" items={filter} type="text" name="filter" paddingBottom="19px" />
      </div>
    );
  }
}

FilterBar.propTypes = {
  className: PropTypes.string,
};

const mapStateToProps = state => ({
  filters: state.engagments,
});

const mapDispatchToProps = dispatch => ({
  onFilterTypeChanged(type) {
    dispatch(setEngagmnetsType(type));
  },
  onCategoryTypeChanged(category) {
    dispatch(setEngagmnetsCategory(category));
  },
  onPhaseClicked(phase) {
    dispatch(updateEngagmnetsPhases(phase));
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(FilterBar);
