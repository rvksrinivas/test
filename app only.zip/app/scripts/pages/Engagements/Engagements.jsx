import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './Engagements.css';

import FilterBar from './FilterBar';
import ExamsList from './ExamsList';

const Engagements = ({className}) => (
  <div className={className} styleName="p-engagements">
    <FilterBar styleName="filterbar"/>
    <ExamsList styleName="examlist"/>
  </div>
);

export default CSSModules(Engagements, styles);
