import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './ExamEnteties.css';
import Ranges from 'components/Ranges';
import {ranges, enteties} from './exam_enteties.js';
import EntetieItem from './EntetieItem';

const ExamEnteties = props => {
  const {status, showAll, defaultCount} = props;
  const showInfo = (status === "edit") ? 'block' : 'none';
  const list = showAll ? enteties : enteties.slice(0, Number(defaultCount));
  return (
    <div className={props.className} styleName="root" style={{display: showInfo}} >
      <Ranges ranges={ranges} />
      {
        list.map((item, i) => {
          return <EntetieItem key={i} item={item} id={`entetie-${i}`}/>;
        })
      }
    </div>
  );
};

ExamEnteties.propTypes = {
  className: PropTypes.string,
};

export default cssModules(ExamEnteties, styles);
