import React, {PropTypes, Component} from 'react';
import {Link} from 'react-router';
import {connect} from 'react-redux';
import CSSModules from 'react-css-modules';
import {browserHistory} from 'react-router';
import styles from './ShortInfo.css';
import {addExam, clearFilledData} from 'actions';

import Button from 'components/Button';

@CSSModules(styles)
class ShortInfo extends Component {
  constructor(props) {
    super(props);
    this.onCreateExamClick = this.onCreateExamClick.bind(this);
  }

  onCreateExamClick() {
    const {basicFilled, primaryFilled, lobsFilled} = this.props;
    if (basicFilled && primaryFilled && lobsFilled) {
      this.props.onAddNewExam();
      this.props.onClearFilledData();
    }
  }

  render() {
    const {name, basicFilled, primaryFilled, lobsFilled} = this.props;
    const isNameFilled = name.length > 0;
    const createActive = (basicFilled && primaryFilled && lobsFilled) ? "true" : "false";
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="info-wrap">
          <div styleName="backButton" onClick={browserHistory.goBack} >Back</div>
          <div styleName="items-wrap">
            <div styleName="item" style={{width: "92px"}}>
              <div styleName="title">ENGAGEMENT ID</div>
              <div styleName="descr">0123456789</div>
            </div>
            <div styleName="item" style={{width: "243px"}}>
              <div styleName="title">ENGAGEMENT NAME</div>
              <div styleName="no-title" style={{display: isNameFilled ? 'none' : 'block'}}>No Title</div>
              <div styleName="descr" style={{display: isNameFilled ? 'block' : 'none', width: '230px'}}>{name}</div>
            </div>
            <div styleName="item" style={{width: "110px", paddingLeft: "8px"}}>
              <div styleName="title">START DATE</div>
              <div styleName="data-wrap">
                <div styleName="descr">02/16/2017</div>
              </div>
            </div>
            <div styleName="item" style={{width: "82px"}}>
              <div styleName="title">PHASE</div>
              <div styleName="descr">Planned</div>
            </div>
            <div styleName="item" style={{width: "79px"}}>
              <div styleName="title">STAGE</div>
              <div styleName="descr">Planned</div>
            </div>
            <div styleName="item" style={{width: "102px", paddingLeft: "9px"}}>
              <div styleName="title">LAST MODIFIED BY</div>
              <div styleName="descr">HALE, PAMELA L</div>
            </div>
            <div styleName="item" style={{width: "92px"}}>
              <div styleName="title">DATE</div>
              <div styleName="descr">02/16/2017</div>
            </div>
          </div>
          <div styleName="controls">
            <Button type={"cancel-exam"} width={"100px"}>Cancel</Button>
            <Link to="/">
              <Button type={"create-exam"} width={"115px"} active={createActive} onClick={this.onCreateExamClick} >Create Exam</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

ShortInfo.propTypes = {
  className: PropTypes.string,
};

const mapStateToProps = state => ({
  name: state.filledData.examName,
  basicFilled: state.filledData.basicInfoFilled,
  primaryFilled: state.filledData.primafyInfoFilled,
  lobsFilled: state.filledData.lobsInfoFilled,
});

const mapDispatchToProps = dispatch => ({
  onAddNewExam() {
    dispatch(addExam());
  },
  onClearFilledData() {
    dispatch(clearFilledData());
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(ShortInfo);
