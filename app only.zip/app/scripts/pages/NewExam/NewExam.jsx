import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './NewExam.css';

import Team from './Team';
import Lobs from './Lobs';
import Legal from './Legal';
import Themes from './Themes';
import SideBar from './SideBar';
import Primary from './Primary';
import ShorInfo from './ShortInfo';
import BasicInfo from './BasicInfo';
import Attachments from './Attachments';
import ExamEnteties from './ExamEnteties';
import CurrentStatus from './CurrentStatus';

import Card from 'components/Card';
import CardForm from 'components/Card/CardForm';
import CardAttach from 'components/Card/CardAttach';

const NewExam = ({className}) => (
  <div className={className} styleName="p-newexam">
    <ShorInfo />
    <main styleName="main">
      <SideBar styleName="sidebar" />
      <div styleName="card-wrap">
        <div styleName="card-fields">
          <div styleName="title">Mandatory Fields</div>
          <div styleName="cards">
            <CardForm title={"Basic Exam Information"} name="basicInfoFilled" >
              {BasicInfo}
            </CardForm>
            <Card title={"Primary and Responsible Location"} name="location" modal="primafyInfoFilled" count="2" category="Locations" type="optional" defaultCount="1">
              {Primary}
            </Card>
            <Card title={"LOBs"} name="lobs" modal="lobsInfoFilled" count="10" category="LOBs" type="optional" defaultCount="1">
              {Lobs}
            </Card>
          </div>
        </div>
        <div styleName="card-fields">
          <div styleName="title">Optional Fields</div>
          <div styleName="cards">
            <Card title={"Legal Entities"} name="legal" modal="legalFilled" count="1" category="Legal Entity" type="optional-gray" defaultCount="1">
              {Legal}
            </Card>
            <Card title={"Examining Entities"} name="examing" modal="examingFilled" count="2" category="Examining Entity" type="optional-gray" defaultCount="3">
              {ExamEnteties}
            </Card>
            <Card title={"Team Roles"} name="team" modal="teamFilled" count="All" category="Team Roles" type="optional-gray">
              {Team}
            </Card>
            <CardForm title={"Current Status"} type="gray">
              {CurrentStatus}
            </CardForm>
            <Card title={"Themes"} name="theme" modal="themeFilled" type="optional-gray">
              {Themes}
            </Card>
            <CardAttach title={"Engagement Attachment"}>
              {Attachments}
            </CardAttach>
          </div>
        </div>
      </div>
    </main>
  </div>
);

export default CSSModules(NewExam, styles);
