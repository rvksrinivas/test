import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './PrimaryItem.css';
import Checkbox from 'components/Checkbox';
import Toggle from 'components/Toggle';

const toggleItems = [
  {
    title: 'RESPONSIBLE',
    value: 'resposible',
    width: '120px',
  },
  {
    title: 'INFORMED',
    value: 'informed',
    width: '120px',
  },
];

class PrimaryItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checked: false,
    };
    this.onClick = this.onClick.bind(this);
  }

  onClick() {
    const {checked} = this.state;
    this.setState({checked: !checked});
  }

  render() {
    const {checked} = this.state;
    const id = this.props.item.country.replace(" ", "");
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="region">{this.props.item.region}</div>
        <div styleName="country">{this.props.item.country}</div>
        <div styleName="primary">
          <Checkbox type="round" id={id} checked={checked} onClick={this.onClick} />
        </div>
        <div styleName="involvement">
          <Toggle items={toggleItems} name={id} category={id}
            size="medium" type="joined" />
        </div>
        <div styleName="delete"><div styleName="delete-icon"></div></div>
      </div>
    );
  }
}

PrimaryItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(PrimaryItem, styles);
