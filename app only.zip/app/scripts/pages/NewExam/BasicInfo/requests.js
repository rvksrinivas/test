export const requests = [
  {
    title: 'FOLLOW-UP',
    value: 'followUp',
    width: '120px',
  },
  {
    title: 'INQUIRY',
    value: 'inqury',
    width: '109px',
  },
  {
    title: 'PHONE CALL',
    value: 'phoneCall',
    width: '109px',
  },
  {
    title: 'REQUEST DOCUMENT',
    value: 'requestDoc',
    width: '132px',
  },
];
