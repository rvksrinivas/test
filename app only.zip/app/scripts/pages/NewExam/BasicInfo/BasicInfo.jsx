import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './BasicInfo.css';
import {connect} from 'react-redux';
import {setExamName} from 'actions';

import Field from 'components/Field';
import Toggle from 'components/Toggle';
import Tooltip from 'components/Tooltip';
import {requests} from './requests.js';

@CSSModules(styles)
class BasicInfo extends Component {

  constructor(props) {
    super(props);

    this.state = {
      name: '',
      scope: '',
    };
    this.isFilled = false;
    this.oldState = 'add';
  }

  onInputChanged(type, text) {
    this.setState({[type]: text});
    this.isFilled = (this.state.name.length > 0 || this.state.scope.length > 0);
    this.props.onChange(this.isFilled);

    if (type === 'name') {
      this.props.onSetExamName(text);
    }
  }

  componentWillReceiveProps(newProps) {
    this.oldState = this.props.status;
  }

  render() {
    const status = this.props.status;
    const showForm = (status === "collapse") ? 'block' : 'none';
    const showInfo = (status === "edit") ? 'block' : 'none';
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="edit-wrap" style={{display: showForm}}>
          <div>
            <Field type="textarea-autosize" name="name" title="Engagement Name" height={40} minRow={1} paddingTop="10px" paddingBottom="10px" onChange={this.onInputChanged.bind(this)} placeholder="Type here"/>
            <Field type="textarea-autosize" name="scope" title="Engagement Scope" height={80} minRow={3} paddingTop="14px" paddingBottom="10px" onChange={this.onInputChanged.bind(this)} placeholder="Type here"/>
            <div styleName="half-size" style={{width: "481px"}}>
              <Field type="text" title="Keywords" descr="Optional" />
            </div>
            <div styleName="half-size">
              <Field type="toggle" title="Request Medium" descr="Optional" paddRight="13px" paddLeft="13px">
                <Toggle items={requests} name="request" type="joined" />
              </Field>
            </div>
          </div>
        </div>
        <div styleName="short-info-wrap" style={{display: showInfo}}>
          <div>
            <div styleName="title">Engagement Name</div>
            <div styleName="descr">
              <div styleName="text-container"><span>{this.state.name}</span></div>
            </div>
          </div>
          <div>
            <div styleName="title">Engagement Scope</div>
            <div styleName="descr">
              <div styleName="text-container"><span>{this.state.scope}</span></div>
              <Tooltip title="Engagement Scope" descr={this.state.scope} style={{paddingLeft: "9px", top: "-2px"}}/>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => ({
  onSetExamName(type) {
    dispatch(setExamName(type));
  },
});

BasicInfo.propTypes = {
  className: PropTypes.string,
};

export default connect(null, mapDispatchToProps)(BasicInfo);
