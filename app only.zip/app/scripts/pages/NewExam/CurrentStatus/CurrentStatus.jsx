import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './CurrentStatus.css';
import Field from 'components/Field';
import Toggle from 'components/Toggle';
import 'react-select/dist/react-select.css';
import Ranges from 'components/Ranges';
import StatusItem from './StatusItem';
import {trends, options, ranges, statuses} from './currentStatus.js';

class CurrentStatus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: '',
      status: '',
      notes: '',
      messageHeight: '40',
      statusHeight: '80',
      notesHeight: '40',
    };
    this.isFilled = false;
    this.onInputChanged = this.onInputChanged.bind(this);
  }

  onInputChanged(name, val, e) {
    this.isFilled = (this.state.message.length > 0 || this.state.status.length > 0);
    this.props.onChange(this.isFilled);
    if (name === 'status') {
      this.setState({status: val});
    }
  }

  render() {
    const {status} = this.props;
    const {messageHeight, statusHeight, notesHeight} = this.state;
    const statusText = this.state.status;
    const showForm = (status === "collapse") ? 'block' : 'none';
    const showInfo = (status === "edit") ? 'block' : 'none';
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="edit-wrap" style={{display: showForm}}>
          <div>
            <div style={{marginBottom: "27px"}} >
              <Field type="textarea-autosize" name="message" title="Key message" textSize="12px" height={`${messageHeight}px`} minRow={1} paddingTop="10px" paddingBottom="10px" placeholder="Type here" onChange={this.onInputChanged}/>
            </div>
            <div style={{marginBottom: "23px", position: "relative"}} >
              <Field type="textarea-autosize" name="status" title="Engagement Current Status" minRow={3} height={`${statusHeight}px`} textSize="12px" placeholder="Type here" onChange={this.onInputChanged}/>
              <span styleName="characters" style={{display: statusText.length > 0 ? "block" : "none"}}>{`${statusText.length} characters`}</span>
            </div>
            <div styleName="half-size" style={{marginRight: "19px"}}>
              <Field type="select" title="Update Frequency" textSize="12px" placeholder="Select" rows="3" height="80px" options={options} />
            </div>
            <div styleName="half-size">
              <Field type="toggle" title="Trend Rating" textSize="12px">
               <Toggle items={trends} name="trends" type="colored" category="lowerCase" />
              </Field>
            </div>
            <Field type="textarea-autosize" name="notes" minRow={1} title="Engagement Status Notes" textSize="12px" paddingTop="10px" paddingBottom="10px" height={`${notesHeight}px`} placeholder="Type here" onChange={this.onInputChanged}/>
          </div>
        </div>
        <div styleName="short-info-wrap" style={{display: showInfo}}>
          <Ranges ranges={ranges} />
          <div>
            {
              statuses.map((item, i) => {
                return <StatusItem key={i} item={item} id={`status-${i}`}/>;
              })
            }
          </div>
        </div>
      </div>
    );
  }
}

CurrentStatus.propTypes = {
  className: PropTypes.string,
};

export default cssModules(CurrentStatus, styles);
