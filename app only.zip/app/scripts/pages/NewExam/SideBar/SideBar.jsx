import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './SideBar.css';

import recordImg from 'images/svg/icons/ex-record-icon.svg';
import milestonesImg from 'images/svg/icons/milestione-icon.svg';
import deliverablesImg from 'images/svg/icons/deliverables-icon.svg';
import meetingsImg from 'images/svg/icons/meetings-icon.svg';
import areaImg from 'images/svg/icons/areafocus-icon.svg';
import recordLinkImg from 'images/svg/icons/recordlinkage-icon.svg';
import historyImg from 'images/svg/icons/history-icon.svg';

const SideBar = props => {
  return (
    <div className={props.className} styleName="root">
      <div styleName="item" style={{fontWeight: 700}}>
        <div styleName="image-wrap"><img src={recordImg} /></div>
        Exam Record
      </div>
      <div styleName="item">
        <div styleName="image-wrap"><img src={milestonesImg} style={{top: "-2px", left: '2px'}}/></div>
        Milestones
      </div>
      <div styleName="item">
        <div styleName="image-wrap"><img src={deliverablesImg} style={{top: "-2px", left: '1px'}} /></div>
        Deliverables
      </div>
      <div styleName="item">
        <div styleName="image-wrap"><img src={meetingsImg} style={{top: "-2px"}} /></div>
        Meetings
      </div>
      <div styleName="item">
        <div styleName="image-wrap"><img src={areaImg} style={{top: "-1px", left: '-1px'}} /></div>
        Area of Focus
      </div>
      <div styleName="item">
        <div styleName="image-wrap"><img src={recordLinkImg} style={{top: "-1px", left: '-1px'}} /></div>
        Record Linkage
      </div>
      <div styleName="item">
        <div styleName="image-wrap"><img src={historyImg} style={{top: "-2px", left: '1px'}} /></div>
        History
      </div>
    </div>
  );
};

SideBar.propTypes = {
  className: PropTypes.string,
};

export default cssModules(SideBar, styles);
