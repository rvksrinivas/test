import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './Themes.css';
import Ranges from 'components/Ranges';
import ThemeItem from './ThemeItem';

const ranges = [
  {
    title: 'Theme Name',
    width: '201px',
  },
  {
    title: 'Description',
    width: '326px',
  },
  {
    title: 'Theme Type L1',
    width: '181px',
  },
  {
    title: 'Theme Type L2',
    width: '181px',
  },
  {
    title: 'Delete',
    width: '109px',
    centered: true,
  },
];

const items = [
  {
    name: 'Customer Authentication',
    descr: 'Description goes here Lorem ipsum dolor…',
    l1: 'Approval',
    l2: 'Authorization-Approval',
  },
];

const Themes = props => {
  const {status, showAll, defaultCount, toogleFooter} = props;
  const showInfo = (status === "edit") ? 'block' : 'none';
  return (
    <div className={props.className} styleName="root" style={{display: showInfo}} >
      <Ranges ranges={ranges} />
      {
        items.map((item, i) => {
          toogleFooter();
          return <ThemeItem key={i} item={item} id={`theme-${i}`}/>;
        })
      }
    </div>
  );
};

Themes.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Themes, styles);
