import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import {connect} from 'react-redux';
import styles from './Legal.css';
import Ranges from 'components/Ranges';
import LegalItem from './LegalItem';

export const ranges = [
  {
    title: 'Added Legal Entity',
    width: '629px',
  },
  {
    title: 'Involvement',
    width: '270px',
  },
  {
    title: 'Delete',
    width: '99px',
    centered: true,
  },
];

export const rangesEmpty = [
  {
    title: 'Added Legal Entity',
    width: '1000px',
  },
];

export const legals = [
  {
    title: 'CHASE BANKCARD SERVICES, INC.',
  },
  {
    title: 'CHASE BANKCARD SERVICES, INC.',
  },
];

@CSSModules(styles)
class Legal extends Component {
  render() {
    const props = this.props;
    const {status, showAll, defaultCount, toogleFooter, filledData} = props;
    const showInfo = (status === "edit") ? 'block' : 'none';
    const hasNoPriority = filledData.legalNoPriorize;
    let list = showAll ? legals : legals.slice(0, Number(defaultCount));
    if (hasNoPriority) {
      list = [];
    }
    // toogleFooter(!hasNoPriority);
    return (
      <div className={props.className} styleName="root" style={{display: showInfo}} >
        <Ranges ranges={(list.length === 0) ? rangesEmpty : ranges} />
        {
          list.map((item, i) => {
            return <LegalItem key={i} title={item.title} id={`legals-${i}`}/>;
          })
        }
        {
          list.length === 0 &&
            <LegalItem title="No Prioritized Legal Entities" type="no-priorize"/>
        }
      </div>
    );
  }
}

const mapStateToProps = state => ({
  filledData: state.filledData,
});

Legal.propTypes = {
  className: PropTypes.string,
};

export default connect(mapStateToProps, null)(Legal);
