export const ranges = [
  {
    title: 'LOB 1',
    width: '169px',
  },
  {
    title: 'LOB 2',
    width: '170px',
  },
  {
    title: 'LOB 3',
    width: '171px',
  },
  {
    title: 'LOB 4',
    width: '169px',
  },
  {
    title: 'Involvement',
    width: '270px',
  },
  {
    title: '',
    width: '49px',
  },
];

export const lobs = [
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
  {
    lob1: 'Asset Management A',
    lob2: 'AM Center',
    lob3: 'Global Wealth Manage…',
    lob4: 'Investment Management',
  },
];
