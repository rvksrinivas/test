import React, {PropTypes} from 'react';
import cssModules from 'react-css-modules';
import styles from './LobItem.css';
import Toggle from 'components/Toggle';

const toggleItems = [
  {
    title: 'RESPONSIBLE',
    value: 'resposible',
    width: '120px',
  },
  {
    title: 'INFORMED',
    value: 'informed',
    width: '120px',
  },
];

const LobItem = props => {
  return (
    <div className={props.className} styleName="root">
      <div styleName="lob1">{props.item.lob1}</div>
      <div styleName="lob2">{props.item.lob2}</div>
      <div styleName="lob3">{props.item.lob3}</div>
      <div styleName="lob4">{props.item.lob4}</div>
      <div styleName="involvment">
        <Toggle items={toggleItems} name={props.id} category={props.id} size="medium" type="joined" />
      </div>
      <div styleName="delete"><div styleName="delete-icon"></div></div>
    </div>
  );
};

LobItem.propTypes = {
  className: PropTypes.string,
};

export default cssModules(LobItem, styles);
