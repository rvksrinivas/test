import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import {connect} from 'react-redux';
import styles from './AttachmentItem.css';
import SelectField from 'components/SelectField';
import DateField from 'components/DateField';
import Button from 'components/Button';
import {setModal, toggleModal} from 'actions';

import attachImg from 'images/svg/icons/attach.svg';

export const options = [
  {
    value: 'request',
    label: 'Request Document',
  },
  {
    value: 'request2',
    label: 'Request Document2',
  },
];

@CSSModules(styles)
class AttachmentItem extends Component {
  render() {
    const {item, metadataFilled, onSetExamName} = this.props;
    const isAddable = metadataFilled;
    const dateText = metadataFilled ? '02/13/2017' : null;
    const docType = metadataFilled ? 'request' : '2';
    return (
      <div className={this.props.className} styleName="root">
        <div styleName="name">
          <img styleName="name-icon" src={attachImg} />
          {item.name}
        </div>
        <div styleName="type">
          <div styleName="select-wrap">
            <SelectField placeholder="Select" type="middle" options={options} value={docType} />
          </div>
        </div>
        <div styleName="dataRecieved">
          <div styleName="date-wrap">
            <DateField text={dateText}/>
          </div>
        </div>
        <div styleName="modifiedBy">{item.modifiedBy}</div>
        <div styleName="lastModified">{item.lastModified}</div>
        <div styleName="metadata">
          <div style={{display: isAddable ? "block" : "none"}}>
            <Button type="edit" width="70px" onClick={onSetExamName}>Edit</Button>
          </div>
          <div style={{display: isAddable ? "none" : "block"}}>
            <Button type="add-optional" width="70px" onClick={onSetExamName} >Add</Button>
          </div>
        </div>
        <div styleName="delete"><div styleName="delete-icon"></div></div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => ({
  onSetExamName() {
    dispatch(setModal('metadata'));
    dispatch(toggleModal());
  },
});

const mapStateToProps = state => ({
  metadataFilled: state.filledData.metadaFilled,
});

AttachmentItem.propTypes = {
  className: PropTypes.string,
};

export default connect(mapStateToProps, mapDispatchToProps)(AttachmentItem);
