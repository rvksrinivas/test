export const ranges = [
  {
    title: 'Doc. Name',
    width: '231px',
  },
  {
    title: 'Doc. Type',
    width: '178px',
    paddingLeft: '16px',
  },
  {
    title: 'Date Received',
    width: '151px',
  },
  {
    title: 'Modified by',
    width: '120px',
    paddingLeft: '17px',
  },
  {
    title: 'Last Modified',
    width: '160px',
  },
  {
    title: 'Metadata',
    width: '90px',
    paddingLeft: '15px',
  },
  {
    title: 'Delete',
    width: '68px',
    centered: true,
  },
];

export const items = [
  {
    name: 'JPM_Request_Document',
    type: '',
    recievedData: '',
    modifiedBy: 'Mona Sachs',
    lastModified: '02/13/2017 12:23 PM',
    status: "add",
  },
  {
    name: 'JPM_Request_Document',
    type: '',
    recievedData: '',
    modifiedBy: 'Mona Sachs',
    lastModified: '02/13/2017 12:23 PM',
    status: "add",
  },
];
