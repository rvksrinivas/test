export const ranges = [
  {
    title: 'Engagement Manager',
    width: '201px',
  },
  {
    title: 'Record Owner',
    width: '201px',
  },
  {
    title: 'Accountable Owner',
    width: '201px',
    paddingLeft: '20px',
  },
  {
    title: 'Executive Owner',
    width: '201px',
    paddingLeft: '20px',
  },
  {
    title: 'Role E',
    width: '194px',
    paddingLeft: '20px',
  },
];

export const roles = [
  {
    width: "201px",
    right: '13px',
    items: ['Alexan Roman Lozano'],
  },
  {
    width: "203px",
    right: '57px',
    items: ['Person Name A', 'Person Name E', 'Person Name I'],
  },
  {
    width: "203px",
    right: '49px',
    items: ['Person Name B', 'Person Name F', 'Person Name J'],
  },
  {
    width: "201px",
    right: '50px',
    items: ['Person Name C', 'Person Name G', 'Person Name K'],
  },
  {
    width: "190px",
    right: '40px',
    items: ['Person Name D', 'Person Name H', 'Person Name L'],
  },
];
