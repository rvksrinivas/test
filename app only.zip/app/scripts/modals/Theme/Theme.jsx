import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './Theme.css';
import {theme, search} from './theme.js';
import {indexOf, remove, forEach} from 'lodash';

import Popup from 'components/Popup';
import Column from 'components/Column';

import downIcon from 'images/svg/icons/theme-download.svg';

export const header = {
  title: "Add Themes",
  titleLeft: '11px',
  paddingTop: '30px',
  height: '121px',
  hasSearch: true,
  marginTop: '15px',
  searchLeft: '10px',
  searchWidth: '580px',
  placeholder: 'Theme Name',
};

class Theme extends Component {
  constructor(props) {
    super(props);
    this.state = {
      theme: {...theme},
      currentType1: null,
      currentType2: null,
      currentName: null,
      addedType1: [],
      addedType2: [],
      addedName: [],
    };
    this.onClick = this.onClick.bind(this);
    this.onDeleteClick = this.onDeleteClick.bind(this);
  }

  onDeleteClick(val) {
    if (val.length === 1) {
      this.onClick(val, 'Type1');
    } else if (val.length === 2) {
      this.onClick(val, 'Type2');
    } else if (val.length === 3) {
      this.onClick(val, 'Name');
    }
  }

  onClick(val, type) {
    const list = this.state[`added${type}`];
    const oldVal = this.inList(val, list);
    const newList = list.slice();
    const newVal = val;
    if (oldVal) {
      this.clearInfo(val, type);
    } else {
      newList.push(val);
      if (type === 'Type1') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
          currentType2: null,
          currentName: null,
        });
      } else if (type === 'Type2') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
          currentName: null,
        });
      } else if (type === 'Name') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
        });
      }
    }
  }

  clearInfo(val, type) {
    const {addedType1, addedType2, addedName} = this.state;
    if (type === 'Type1') {
      this.setState({
        currentType1: null,
        currentType2: null,
        currentName: null,
        addedType1: this.clearInList(addedType1, val),
        addedType2: this.clearInList(addedType2, val),
        addedName: this.clearInList(addedName, val),
      });
    } else if (type === 'Type2') {
      this.setState({
        currentType2: null,
        currentName: null,
        addedType2: this.clearInList(addedType2, val),
        addedName: this.clearInList(addedName, val),
      });
    } else if (type === 'Name') {
      this.setState({
        currentName: null,
        addedName: this.clearInList(addedName, val),
      });
    }
  }

  clearInList(list, val) {
    const newList = list.slice();
    remove(newList, item => {
      return item.substr(0, val.length) === val;
    });
    return newList;
  }

  inList(val, list) {
    const inList = indexOf(list, val);
    return (inList !== -1);
  }

  getFooterData(breadCrums) {
    const count = breadCrums.length;
    return {
      card: 'themeFilled',
      onDeleteClick: this.onDeleteClick,
      title: `Show All Themes selected (${count})`,
      breadCrums,
      crumsType: 'line',
      checker: true,
      listTitle: 'SELECTED THEMES',
    };
  }

  getType2() {
    const {currentType1, theme} = this.state;
    let list = [];
    if (currentType1) {
      const newList = theme.type1[currentType1].type2;
      if (newList) {
        list = newList;
      }
    }
    console.log(list);
    return list;
  }

  getNames() {
    const {currentType1, currentType2, theme} = this.state;
    let list = [];
    if (currentType1) {
      const type1 = theme.type1[currentType1].type2;
      if (type1 && currentType2) {
        const type2 = Number(currentType2.charAt(1));
        const newList = theme.type1[currentType1].type2[type2].names;
        if (newList) {
          list = newList;
        }
      }
    }
    return list;
  }

  getList(list1, list2, list3, list4) {
    const all1 = list1.concat(list2);
    const all2 = list3.concat(list4);
    const all = all1.concat(all2);
    const newList1 = [];
    const newList2 = [];
    const newList3 = [];
    const newList4 = [];
    forEach(all, item => {
      if (item.length === 1) {
        newList1.push(item);
      } else if (item.length === 2) {
        newList2.push(item);
      } else if (item.length === 3) {
        newList3.push(item);
      } else if (item.length === 4) {
        newList4.push(item);
      }
    });
    forEach(newList2, target => {
      remove(newList1, item => {
        return item === target.substr(0, item.length);
      });
    });
    forEach(newList3, target => {
      remove(newList2, item => {
        return item === target.substr(0, item.length);
      });
    });
    forEach(newList4, target => {
      remove(newList3, item => {
        return item === target.substr(0, item.length);
      });
    });
    const newAll1 = newList1.concat(newList2);
    const newAll2 = newList3.concat(newList4);
    return newAll1.concat(newAll2);
  }

  createBreadCrumbs(list) {
    const {theme} = this.state;
    const array = [];
    forEach(list, item => {
      const path = item.split('');
      const newArray = [];
      let first;
      if (item.length > 0) {
        first = Number(path[0]);
        newArray.push(item);
        newArray.push(theme.type1[first].title);
      }
      if (item.length > 1) {
        const sec = Number(path[1]);
        newArray.push(theme.type1[first].type2[sec].title);
      }
      if (item.length > 2) {
        const sec = Number(path[1]);
        const third = Number(path[2]);
        newArray.push(theme.type1[first].type2[sec].names[third].title);
      }
      array.push(newArray);
    });
    return array;
  }

  render() {
    const {className} = this.props;
    const {theme, currentType1, currentType2, currentName, addedType1, addedType2, addedName} = this.state;
    const type2 = this.getType2();
    const names = this.getNames();
    const wholeList = this.getList(addedType1, addedType2, addedName, []);
    const breadCrumbs = this.createBreadCrumbs(wholeList);
    const footer = this.getFooterData(breadCrumbs);
    return (
      <div className={className} styleName="root">
        <Popup header={header} footer={footer} search={search}>
          <Column title="THEME TYPE L1" items={theme.type1} activeItems={addedType1} activeId={currentType1} width="25%" onClick={val => {
            this.onClick(val, 'Type1');
          }}/>
          <Column title="THEME TYPE L2" items={type2} activeItems={addedType2} activeId={currentType2} currentId={currentType1} complex="true" width="25%" onClick={val => {
            this.onClick(val, 'Type2');
          }}/>
          <Column title="THEME NAME" subtitle="DESCRIPTION" activeItems={addedName} titleLeft="21px" items={names} activeId={currentName} currentId={`${currentType2}`} complex="true" size="full" type="last" width="50%" onClick={val => {
            this.onClick(val, 'Name');
          }}/>
        </Popup>
        <div styleName="download">
          <img src={downIcon} />
          <span>Download All Themes PDF</span>
        </div>
      </div>
    );
  }
}

Theme.propTypes = {
  className: PropTypes.string,
};

export default CSSModules(Theme, styles);
