export const search = {
  title: 'Invoice',
  loadLeft: '518px',
  height: '431px',
  width: '1160px',
  items: [
    {
      title: 'Suggested Results',
      items: [
        {
          title: ['Approval', 'Authorization - Approval', '<b>Invoice</b> Processing A'],
          type: 'search-name',
        },
        {
          title: ['Approval', 'Authorization - Approval', '<b>Invoice</b> Processing B'],
          type: 'search-name',
        },
        {
          title: ['Approval', 'Authorization - Approval', '<b>Invoice</b> Processing C'],
          type: 'search-name',
        },
      ],
    },
    {
      title: 'Frequently Used',
      items: [
        {
          title: ['Approval', 'Authorization - Approval', '<b>Invoice</b> Processing C'],
          type: 'search-name',
          isTime: true,
        },
        {
          title: ['Approval', 'Authorization - Approval', '<b>Invoice</b> Processing C'],
          type: 'search-name',
          isTime: true,
        },
        {
          title: ['Approval', 'Authorization - Approval', '<b>Invoice</b> Processing C'],
          type: 'search-name',
          isTime: true,
        },
      ],
    },
  ],
};

export const theme = {
  type1: [
    {
      title: 'Approval',
      type2: [
        {
          title: `Dual Review / Seg of Duties / Dual Contro`,
        },
        {
          title: 'Authorization - Approval',
          names: [
            {
              title: 'Approval',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
            {
              title: 'Customer',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
            {
              title: 'Invoice Processing',
              description: 'Invoices are verified for accuracy against actual services rendered  approved with…',
            },
            {
              title: 'Pricing of Prodcts and Services',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
            {
              title: 'Social Media-Pre-Publication Approve & Post Valid',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
          ],
        },
      ],
    },
    {
      title: 'Client',
    },
    {
      title: 'Data',
      type2: [
        {
          title: `Dual Review / Seg of Duties / Dual Contro`,
        },
        {
          title: 'Authorization - Approval',
          names: [
            {
              title: 'Approval',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
            {
              title: 'Customer',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
            {
              title: 'Invoice Processing',
              description: 'Invoices are verified for accuracy against actual services rendered  approved with…',
            },
            {
              title: 'Pricing of Prodcts and Services',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
            {
              title: 'Social Media-Pre-Publication Approve & Post Valid',
              description: 'Approval is provided by the appropriate party and documented according to policy.',
            },
          ],
        },
      ],
    },
    {
      title: 'Documentation',
    },
  ],
};
