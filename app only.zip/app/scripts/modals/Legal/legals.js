export const search = {
  title: 'JP Morgan',
  loadLeft: '233px',
  height: '450px',
  items: [
    {
      title: 'Suggested Results',
      items: [
        {
          title: ['LOB Material Legal Entities', '<b>JP Morgan</b> Service India Private Limited A'],
          type: 'search-name',
        },
        {
          size: 'big',
          title: ['LOB Material Legal Entities', 'Pusat pelaporan dan <b>JP Morgan</b> Transaksi Keuangan (Financial Transaction Reports and Analysis Centre)'],
          type: 'search-name',
        },
        {
          title: ['LOB Material Legal Entities', '<b>JP Morgan</b> Service India Private Limited C'],
          type: 'search-name',
        },
      ],
    },
    {
      title: 'Frequently Used',
      items: [
        {
          title: 'Exam NameTest #2 OCC ROSE',
          index: '15684',
          type: 'time',
        },
        {
          title: 'Exam NameTest #2 OCC ROSE',
          type: 'time',
          index: '15684',
        },
        {
          title: 'Exam NameTest #2 OCC ROSE',
          type: 'time',
          index: '15684',
        },
      ],
    },
  ],
};

export const legals = {
  0: [
    {
      title: 'CHASE BANKCARD SERVICES, INC.',
    },
    {
      title: 'Chase Paymentech Solutions',
    },
    {
      title: 'Paymentech, LLC',
    },
    {
      title: 'JP Morgan Service India Private Limited',
    },
    {
      title: 'Chase Paymentech Europe Limited',
    },
    {
      title: 'Legal Entity 2',
    },
    {
      title: 'Legal Entity 3',
    },
    {
      title: 'Legal Entity 4',
    },
    {
      title: 'Legal Entity 5',
    },
    {
      title: 'Legal Entity 6',
    },
    {
      title: 'Legal Entity 7',
    },
  ],
  1: [
    {
      title: 'All Prioritized Legal Entities 1',
    },
    {
      title: 'All Prioritized Legal Entities 2',
    },
    {
      title: 'All Prioritized Legal Entities 3',
    },
    {
      title: 'All Prioritized Legal Entities 4',
    },
    {
      title: 'All Prioritized Legal Entities 5',
    },
    {
      title: 'All Prioritized Legal Entities 6',
    },
    {
      title: 'All Prioritized Legal Entities 7',
    },
    {
      title: 'All Prioritized Legal Entities 8',
    },
    {
      title: 'All Prioritized Legal Entities 9',
    },
    {
      title: 'All Prioritized Legal Entities 10',
    },
    {
      title: 'All Prioritized Legal Entities 11',
    },
  ],
};
