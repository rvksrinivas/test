import React, {PropTypes, Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './Metadata.css';
import {ranges} from './metadata.js';

import Field from 'components/Field';
import Popup from 'components/Popup';
import DateField from 'components/DateField';
import Ranges from 'components/Ranges';
import Toggle from 'components/Toggle';

export const header = {
  title: "Add Metadata",
  titleLeft: '10px',
  height: '90px',
};

export const requests = [
  {
    title: 'YES',
    value: 'yes',
    width: '235px',
  },
  {
    title: 'NO',
    value: 'no',
    width: '235px',
  },
];

class Metadata extends Component {
  constructor(props) {
    super(props);
    this.onToggleClick = this.onToggleClick.bind(this);
  }

  onToggleClick() {

  }

  getFooterData() {
    return {
      card: 'metadaFilled',
    };
  }

  render() {
    const {className} = this.props;
    const footer = this.getFooterData();
    return (
      <div className={className} styleName="root">
        <Popup title="Add Metadata" header={header} footer={footer}>
          <Ranges ranges={ranges} borderTop="none"/>
          <div styleName="data">
            <div styleName="id">01234567</div>
            <div styleName="name">TBD_1_17_XMl</div>
            <div styleName="upload">Pamela Hale</div>
            <div styleName="attach">02/13/2017  5:30:22 PM</div>
            <div styleName="modif">Mona Sachs</div>
            <div styleName="modif-date">02/13/2017</div>
          </div>
          <div styleName="column-wrap">
            <div styleName="column">
              <div styleName="field">
                <span>
                  Date Received
                </span>
                <DateField size="big" />
              </div>
              <div styleName="field">
                <span>
                  Document Type
                </span>
                <Field type="select" placeholder="Select" borderColor="#D7D7D7" paddingLeft="19px" color="request"/>
              </div>
              <div styleName="field">
                <span>
                  Attachment Name
                </span>
                <Field type="text" placeholder="Type here …" borderColor="#D7D7D7" paddingLeft="19px"/>
              </div>
            </div>
            <div styleName="column">
              <div styleName="field-search">
                <span>
                  Examining Entity Author
                </span>
                <Field type="text" placeholder="Search for Author" borderColor="#D7D7D7" paddingLeft="39px"/>
              </div>
              <div styleName="field">
                <span>
                  JPMC Recipient
                </span>
                <Field type="text" placeholder="Add Recipients" borderColor="#D7D7D7" paddingLeft="19px"/>
              </div>
              <div styleName="field">
                <span>
                  Keywords
                </span>
                <Field type="text" placeholder="Type here" borderColor="#D7D7D7" paddingLeft="19px"/>
              </div>
            </div>
            <div styleName="textarea">
              <div styleName="field">
                <span>
                  Attachment Summary
                </span>
                <Field type="textarea" placeholder="Type here" borderColor="#D7D7D7" paddingLeft="14px"/>
              </div>
            </div>
          </div>
          <div styleName="translated-wrap">
            <span>Translated Version</span>
            <div styleName="translate-toggle">
              <Toggle size="big" items={requests} name="translate" type="joined" onClick={this.onToggleClick} />
            </div>
          </div>
        </Popup>
      </div>
    );
  }
}

Metadata.propTypes = {
  className: PropTypes.string,
};

export default CSSModules(Metadata, styles);
