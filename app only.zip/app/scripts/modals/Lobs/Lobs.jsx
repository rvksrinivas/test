import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Lobs.css';
import {header, lob, search} from './lobs.js';
import {indexOf, remove, forEach} from 'lodash';

import Popup from 'components/Popup';
import Column from 'components/Column';

class Lobs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      lob: [...lob],
      currentLob1: null,
      currentLob2: null,
      currentLob3: null,
      currentLob4: null,
      addedLob1: [],
      addedLob2: [],
      addedLob3: [],
      addedLob4: [],
    };
    this.onClick = this.onClick.bind(this);
    this.onDeleteClick = this.onDeleteClick.bind(this);
    this.onSearchCallback = this.onSearchCallback.bind(this);
  }

  onClick(val, type) {
    const list = this.state[`added${type}`];
    const oldVal = this.inList(val, list);
    const newList = list.slice();
    const newVal = val;
    if (oldVal) {
      this.clearInfo(val, type);
    } else {
      newList.push(val);
      if (type === 'Lob1') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
          currentLob2: null,
          currentLob3: null,
          currentLob4: null,
        });
      } else if (type === 'Lob2') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
          currentLob3: null,
          currentLob4: null,
        });
      } else if (type === 'Lob3') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
          currentLob4: null,
        });
      } else if (type === 'Lob4') {
        this.setState({
          [`current${type}`]: newVal,
          [`added${type}`]: newList,
        });
      }
    }
  }

  onSearchCallback() {
    const {addedLob1, addedLob2, addedLob3, addedLob4} = this.state;
    const newList1 = addedLob1.slice();
    const newList2 = addedLob2.slice();
    const newList3 = addedLob3.slice();
    const newList4 = addedLob4.slice();
    newList1.push('0');
    newList2.push('01');
    newList3.push('012');
    newList4.push('0122');
    this.setState({
      currentLob1: '0',
      currentLob2: '01',
      currentLob3: '012',
      currentLob4: '0122',
      addedLob1: newList1,
      addedLob2: newList2,
      addedLob3: newList3,
      addedLob4: newList4,
    });
  }

  clearInfo(val, type) {
    const {addedLob1, addedLob2, addedLob3, addedLob4} = this.state;
    if (type === 'Lob1') {
      this.setState({
        currentLob1: null,
        currentLob2: null,
        currentLob3: null,
        currentLob4: null,
        addedLob1: this.clearInList(addedLob1, val),
        addedLob2: this.clearInList(addedLob2, val),
        addedLob3: this.clearInList(addedLob3, val),
        addedLob4: this.clearInList(addedLob4, val),
      });
    } else if (type === 'Lob2') {
      this.setState({
        currentLob2: null,
        currentLob3: null,
        currentLob4: null,
        addedLob2: this.clearInList(addedLob2, val),
        addedLob3: this.clearInList(addedLob3, val),
        addedLob4: this.clearInList(addedLob4, val),
      });
    } else if (type === 'Lob3') {
      this.setState({
        currentLob3: null,
        currentLob4: null,
        addedLob3: this.clearInList(addedLob3, val),
        addedLob4: this.clearInList(addedLob4, val),
      });
    } else if (type === 'Lob4') {
      this.setState({
        currentLob4: null,
        addedLob4: this.clearInList(addedLob4, val),
      });
    }
  }

  clearInList(list, val) {
    const newList = list.slice();
    remove(newList, item => {
      return item.substr(0, val.length) === val;
    });
    return newList;
  }

  inList(val, list) {
    const inList = indexOf(list, val);
    return (inList !== -1);
  }

  onDeleteClick(val) {
    if (val.length === 1) {
      this.onClick(val, 'Lob1');
    } else if (val.length === 2) {
      this.onClick(val, 'Lob2');
    } else if (val.length === 3) {
      this.onClick(val, 'Lob3');
    } else if (val.length === 4) {
      this.onClick(val, 'Lob4');
    }
  }

  getFooterData(breadCrums) {
    const count = breadCrums.length;
    return {
      card: 'lobsInfoFilled',
      onDeleteClick: this.onDeleteClick,
      title: `Show All LOBs selected (${count})`,
      listTitle: 'SELECTED LOB(S)',
      breadCrums,
    };
  }

  getLob2() {
    const {currentLob1, lob} = this.state;
    let list = [];
    if (currentLob1) {
      const newList = lob[currentLob1].lob2;
      if (newList) {
        list = newList;
      }
    }
    return list;
  }

  getLob3() {
    const {currentLob2, lob} = this.state;
    const lob2 = this.getLob2();
    let list = [];
    if (lob2 && currentLob2) {
      const lob3 = Number(currentLob2.charAt(1));
      if (lob2[lob3]) {
        const newList = lob2[lob3].lob3;
        if (newList) {
          list = newList;
        }
      }
    }
    return list;
  }

  getLob4() {
    const {currentLob3, lob} = this.state;
    const lob3 = this.getLob3();
    let list = [];
    if (lob3 && currentLob3) {
      const lob4 = Number(currentLob3.charAt(2));
      if (lob3[lob4]) {
        const newList = lob3[lob4].lob4;
        if (newList) {
          list = newList;
        }
      }
    }
    return list;
  }

  getList(list1, list2, list3, list4) {
    const all1 = list1.concat(list2);
    const all2 = list3.concat(list4);
    const all = all1.concat(all2);
    const newList1 = [];
    const newList2 = [];
    const newList3 = [];
    const newList4 = [];
    forEach(all, item => {
      if (item.length === 1) {
        newList1.push(item);
      } else if (item.length === 2) {
        newList2.push(item);
      } else if (item.length === 3) {
        newList3.push(item);
      } else if (item.length === 4) {
        newList4.push(item);
      }
    });
    forEach(newList2, target => {
      remove(newList1, item => {
        return item === target.substr(0, item.length);
      });
    });
    forEach(newList3, target => {
      remove(newList2, item => {
        return item === target.substr(0, item.length);
      });
    });
    forEach(newList4, target => {
      remove(newList3, item => {
        return item === target.substr(0, item.length);
      });
    });
    const newAll1 = newList1.concat(newList2);
    const newAll2 = newList3.concat(newList4);
    return newAll1.concat(newAll2);
  }

  createBreadCrumbs(list) {
    const {lob} = this.state;
    const array = [];
    forEach(list, item => {
      const path = item.split('');
      const newArray = [];
      let first;
      if (item.length > 0) {
        first = Number(path[0]);
        newArray.push(item);
        newArray.push(lob[first].title);
      }
      if (item.length > 1) {
        const sec = Number(path[1]);
        newArray.push(lob[first].lob2[sec].title);
      }
      if (item.length > 2) {
        const sec = Number(path[1]);
        const third = Number(path[2]);
        newArray.push(lob[first].lob2[sec].lob3[third].title);
      }
      if (item.length > 3) {
        const sec = Number(path[1]);
        const third = Number(path[2]);
        const fourth = Number(path[3]);
        newArray.push(lob[first].lob2[sec].lob3[third].lob4[fourth].title);
      }
      array.push(newArray);
    });
    return array;
  }

  render() {
    const {lob, addedLob1, addedLob2, addedLob3, addedLob4, currentLob1, currentLob2, currentLob3, currentLob4} = this.state;
    const lob2 = this.getLob2();
    const lob3 = this.getLob3();
    const lob4 = this.getLob4();
    const wholeList = this.getList(addedLob1, addedLob2, addedLob3, addedLob4);
    const breadCrumbs = this.createBreadCrumbs(wholeList);
    const footer = this.getFooterData(breadCrumbs);
    return (
      <div className={this.props.className} styleName="root">
        <Popup title="Add LOBs" header={header} footer={footer} search={search} onSearchClick={this.onSearchCallback}>
          <Column title="LOB 1" items={lob} activeItems={addedLob1} activeId={currentLob1} width="25%" onClick={val => {
            this.onClick(val, 'Lob1');
          }}/>
          <Column title="LOB 2" items={lob2} activeItems={addedLob2} activeId={currentLob2} currentId={currentLob1} width="25%" onClick={val => {
            this.onClick(val, 'Lob2');
          }}/>
          <Column title="LOB 3" items={lob3} activeItems={addedLob3} activeId={currentLob3} currentId={currentLob2} width="25%" onClick={val => {
            this.onClick(val, 'Lob3');
          }}/>
          <Column title="LOB 4" items={lob4} activeItems={addedLob4} activeId={currentLob4} currentId={currentLob3} width="25%" type="last" onClick={val => {
            this.onClick(val, 'Lob4');
          }}/>
        </Popup>
      </div>
    );
  }
}

Lobs.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Lobs, styles);
