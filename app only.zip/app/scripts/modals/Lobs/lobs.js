export const header = {
  title: "Add LOBs",
  titleLeft: '0',
  titlePosLeft: '-10px',
  height: '121px',
  paddingLeft: '30px',
  paddingTop: '30px',
  hasSearch: true,
  placeholder: 'LOB Name',
};

export const search = {
  title: 'Investment Management',
  loadLeft: '518px',
  items: [
    {
      title: 'Suggested Results',
      items: [
        {
          title: ['Asset Management A', 'Investment Management'],
          type: 'search-place',
        },
        {
          title: ['Asset Management A', 'Mortgage Banking', 'Investment Management'],
          type: 'search-place',
        },
        {
          title: ['Asset Management C', 'Mortgage Banking', 'CBS', 'Investment Management'],
          type: 'search-place',
        },
      ],
    },
    {
      title: 'Frequently Used',
      items: [
        {
          title: 'Exam NameTest #2 OCC ROSE',
          index: '15684',
          type: 'time',
        },
        {
          title: 'Exam NameTest #2 OCC ROSE',
          type: 'time',
          index: '15684',
        },
        {
          title: 'Exam NameTest #2 OCC ROSE',
          type: 'time',
          index: '15684',
        },
      ],
    },
  ],
};

export const lob = [
  {
    title: 'Asset Management A',
    lob2: [
      {
        title: 'LobName 1',
      },
      {
        title: 'AM Center',
        lob3: [
          {
            title: 'LobName 1',
          },
          {
            title: 'LobName 2',
          },
          {
            title: 'Approval',
            lob4: [
              {
                title: 'LobName 1',
              },
              {
                title: 'LobName 2',
              },
              {
                title: 'Investment Management',
              },
              {
                title: 'LobName 4',
              },
              {
                title: 'LobName 5',
              },
              {
                title: 'LobName 6',
              },
            ],
          },
          {
            title: 'LobName 4',
          },
          {
            title: 'LobName 5',
          },
          {
            title: 'LobName 6',
          },
          {
            title: 'LobName 7',
          },
          {
            title: 'LobName 8',
          },
          {
            title: 'LobName 9',
          },
        ],
      },
      {
        title: 'LobName 3',
      },
      {
        title: 'LobName 4',
      },
      {
        title: 'Approval',
        lob3: [
          {
            title: 'LobName 1',
            end: true,
          },
          {
            title: 'LobName 2',
            end: true,
          },
          {
            title: 'All Other AM Center Active',
            end: true,
          },
          {
            title: 'LobName 4',
            end: true,
          },
          {
            title: 'LobName 5',
            end: true,
          },
          {
            title: 'LobName 6',
            end: true,
          },
          {
            title: 'LobName 7',
            end: true,
          },
          {
            title: 'LobName 8',
            end: true,
          },
          {
            title: 'LobName 9',
            end: true,
          },
        ],
      },
      {
        title: 'LobName 6',
      },
      {
        title: 'LobName 7',
      },
      {
        title: 'LobName 8',
      },
      {
        title: 'LobName 9',
      },
    ],
  },
  {
    title: 'Asset Management B',
  },
  {
    title: 'Asset Management C',
  },
  {
    title: 'Asset Management D',
  },
  {
    title: 'Asset Management E',
  },
];
