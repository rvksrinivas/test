export const search = {
  title: 'Roman',
  loadLeft: '238px',
  height: '431px',
  items: [
    {
      title: 'Suggested Results',
      items: [
        {
          title: ['012345', 'Alexan <b>Roman</b> Lozano Oliveros'],
          type: 'search-name',
          contact: 'alexanromanlozano@jpmc.com',
        },
        {
          title: ['012345', 'Alexan <b>Roman</b> Lozano Garcia'],
          type: 'search-name',
          contact: 'alexanromanlozano@jpmc.com',
        },
        {
          title: ['012345', 'Alexan <b>Roman</b>  Lozano Fu'],
          type: 'search-name',
          contact: 'alexanromanlozano@jpmc.com',
        },
      ],
    },
    {
      title: 'Frequently Used',
      items: [
        {
          title: 'Alexan Roman  Lozano Oliveros',
          index: '012345',
          type: 'time',
          contact: 'alexanromanlozano@jpmc.com',
          separate: true,
        },
        {
          title: 'Alexan Roman  Lozano Garcia',
          type: 'time',
          index: '012345',
          contact: 'alexanromanlozano@jpmc.com',
          separate: true,
        },
        {
          title: 'Alexan Roman  Lozano Fu',
          type: 'time',
          index: '012345',
          contact: 'alexanromanlozano@jpmc.com',
          separate: true,
        },
      ],
    },
  ],
};

export const team = {
  members: [
    {
      title: 'Alexan Roman Lozano Oliveros',
      descr: '123456',
      roles: [
        {
          title: 'Engagement Manager',
        },
        {
          title: 'Executive Owner',
        },
        {
          title: 'Record Owner',
        },
        {
          title: 'Accountable Owner',
        },
        {
          title: 'Role 5',
        },
        {
          title: 'Role 6',
        },
        {
          title: 'Role 7',
        },
        {
          title: 'Role 8',
        },
        {
          title: 'Role 9',
        },
      ],
    },
  ],
};
