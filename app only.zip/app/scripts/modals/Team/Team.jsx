import React, {PropTypes, Component} from 'react';
import cssModules from 'react-css-modules';
import styles from './Team.css';
import {team, search} from './team.js';
import {indexOf, remove, forEach} from 'lodash';

import Popup from 'components/Popup';
import Column from 'components/Column';

export const header = {
  title: "Add Team Roles",
  titleLeft: '10px',
  height: '120px',
  marginTop: '15px',
  hasSearch: true,
  isSearch: true,
  paddingTop: '30px',
  placeholder: 'Name, Email or SID',
};

class Team extends Component {

  constructor(props) {
    super(props);
    this.state = {
      team: {...team},
      currentMember: null,
      currentRole: null,
      addedMember: [],
      addedRole: [],
      activated: false,
    };
    this.onClick = this.onClick.bind(this);
    this.onMemberClick = this.onMemberClick.bind(this);
    this.onDeleteClick = this.onDeleteClick.bind(this);
    this.onSearchCallback = this.onSearchCallback.bind(this);
  }

  onMemberClick(val) {
    this.setState({currentMember: val});
  }

  onDeleteClick(val) {
    if (val.length > 1) {
      this.onClick(val, 'Role');
    } else {
      this.onClick(val, 'Member');
    }
  }

  inList(val, list) {
    const inList = indexOf(list, val);
    return (inList !== -1);
  }

  clearInfo(val, type) {
    const {addedMember, addedRole} = this.state;
    if (type === 'Member') {
      this.setState({
        currentMember: null,
        currentRole: null,
        addedMember: this.clearInList(addedMember, val),
        addedRole: this.clearInList(addedRole, val),
      });
    } else if (type === 'Role') {
      this.setState({
        currentRole: null,
        addedRole: this.clearInList(addedRole, val),
      });
    }
  }

  clearInList(list, val) {
    const newList = list.slice();
    remove(newList, item => {
      return item.substr(0, val.length) === val;
    });
    return newList;
  }

  onClick(val, type) {
    const list = this.state[`added${type}`];
    const oldVal = this.inList(val, list);
    const newList = list.slice();
    const newVal = val;
    if (oldVal) {
      this.clearInfo(val, type);
    } else {
      newList.push(val);
      this.setState({[`current${type}`]: newVal, [`added${type}`]: newList});
    }
  }

  getFooterData(breadCrums) {
    const count = breadCrums.length;
    return {
      card: 'teamFilled',
      onDeleteClick: this.onDeleteClick,
      title: `Show All Team Roles selected (${count})`,
      breadCrums,
      crumsType: 'role',
      listTitle: 'SELECTED TEAM ROLES',
    };
  }

  getList(list1, list2) {
    const all = list1.concat(list2);
    const newList1 = [];
    const newList2 = [];
    forEach(all, item => {
      if (item.length === 1) {
        newList1.push(item);
      } else {
        newList2.push(item);
      }
    });
    forEach(newList2, target => {
      remove(newList1, item => {
        return item === target.substr(0, item.length);
      });
    });
    return newList1.concat(newList2);
  }

  createBreadCrumbs(list) {
    const {team} = this.state;
    const array = [];
    forEach(list, item => {
      const path = item.split('');
      const newArray = [];
      let first;
      if (item.length > 0) {
        first = Number(path[0]);
        newArray.push(item);
        newArray.push(team.members[first].title);
      }
      if (item.length > 1) {
        const sec = Number(path[1]);
        newArray.push(team.members[first].roles[sec].title);
      }
      array.push(newArray);
    });
    return array;
  }

  onSearchCallback() {
    this.setState({activated: true});
  }

  render() {
    const {team, currentMember, currentRole, addedMember, addedRole, activated} = this.state;
    const getRoles = team.members[currentMember] ? team.members[currentMember].roles : [];
    const wholeList = this.getList(addedRole, addedMember);
    const breadCrumbs = this.createBreadCrumbs(wholeList);
    const footer = this.getFooterData(breadCrumbs);
    return (
      <div className={this.props.className} styleName="root">
        <Popup title="Add LOBs" header={header} footer={footer} search={search} onSearchClick={this.onSearchCallback}>
          <Column title="INDIVIDUAL NAME" items={activated ? team.members : []} width="50%" activeItems={addedMember} activeId={currentMember} onClick={val => {
            this.onClick(val, 'Member');
          }} />
          <Column title="ROLE" items={getRoles} width="50%" type="last" currentId={currentMember} activeItems={addedRole} onClick={val => {
            this.onClick(val, 'Role');
          }} />
        </Popup>
      </div>
    );
  }
}

Team.propTypes = {
  className: PropTypes.string,
};

export default cssModules(Team, styles);
