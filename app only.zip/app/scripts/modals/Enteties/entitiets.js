export const search = {
  title: 'TH.SEC',
  loadLeft: '517px',
  height: '430px',
  items: [
    {
      title: 'Suggested Results',
      items: [
        {
          decorate: 'differ',
          title: ['APAC', 'Thailand', 'Securities and Exchange Commision (Thailand)', '<b>TH.SEC</b>'],
          type: 'search-name',
        },
        {
          decorate: 'differ',
          title: ['APAC', 'Indonesia', 'Pusat pelaporan dan <b>th.sec</b> Transaksi Keuangan (Financial Transaction Reports and Analysis Centre)'],
          type: 'search-name',
        },
        {
          decorate: 'differ',
          title: ['APAC', 'Australia', 'Australian Financial <b>TH.SEC</b> Security Authority'],
          type: 'search-name',
        },
      ],
    },
    {
      title: 'Frequently Used',
      items: [
        {
          title: 'Exam NameTest #2 OCC ROSE',
          index: '15684',
          type: 'time',
        },
        {
          title: 'Exam NameTest #2 OCC ROSE',
          type: 'time',
          index: '15684',
        },
        {
          title: 'Exam NameTest #2 OCC ROSE',
          type: 'time',
          index: '15684',
        },
      ],
    },
  ],
};

export const entetiets = {
  regions: [
    {
      title: 'APAC',
      countries: [
        {
          title: 'Country 1',
        },
        {
          title: 'Australia',
          entetities: [
            {
              descr: 'AU.AFSA',
              title: 'Australian Financial Security Authority',
            },
            {
              descr: 'AU.APRA',
              title: 'Australian Prudential Regulation Authority',
              leaders: [
                {
                  title: 'Atkins, Glenn',
                },
                {
                  title: 'Berry, Heather',
                },
                {
                  title: 'Chirola, Peter',
                },
                {
                  title: 'Dail, Richard',
                },
                {
                  title: 'Etkins, Glenn',
                },
                {
                  title: 'Ferry, Heather',
                },
                {
                  title: 'Gerry, Heather',
                },
                {
                  title: 'Herry, Heather',
                },
                {
                  title: 'Ierry, Heather',
                },
                {
                  title: 'Marry, Heather',
                },
              ],
            },
            {
              descr: 'AU.ASIC',
              title: 'Australian Securities and Investments Commission',
            },
            {
              descr: 'AU.AUSTRAC',
              title: 'Australian Transaction Reports and Analysis Centre',
            },
            {
              descr: 'AU.AUSTRAC',
              title: 'Reserve Bank of Australia',
            },
          ],
        },
        {
          title: 'Country 3',
        },
        {
          title: 'Country 4',
        },
        {
          title: 'Country 5',
        },
        {
          title: 'Country 6',
        },
        {
          title: 'Country 7',
        },
        {
          title: 'Country 8',
        },
        {
          title: 'Country 9',
        },
        {
          title: 'Country 10',
        },
      ],
    },
    {
      title: 'Region 2',
    },
    {
      title: 'Region 3',
    },
    {
      title: 'Region 4',
    },
    {
      title: 'Region 5',
    },
  ],
};
