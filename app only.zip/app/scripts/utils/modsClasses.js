import classnames from 'classnames';

const modsClasses = (mods, props, styles) => {
  const modsClasses = mods.map(key => {
    const value = props[key];
    return styles[`${key}-${value}`];
  });
  const classes = classnames(props.className, ...modsClasses);
  return classes;
};

export default modsClasses;
