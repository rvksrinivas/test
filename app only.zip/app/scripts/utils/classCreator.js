const classCreator = style => {
  style = style.split(' ');
  style = style.join('-');
  style = style.toLowerCase();
  return style;
};

export default classCreator;
